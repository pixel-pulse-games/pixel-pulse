PyCity — EMERGENCY README (v0.0.6 patcher fix)
================================================

If you installed PyCity v0.0.5, please read this. It only applies to
that version.

This release contains no game changes — same v0.0.5 game, same
features, same balance. It's being released together with a fresh
copy of the game zip so both are on the v0.0.6 release page as a
matched set, but the only thing actually different from v0.0.5 is
the fix to Patcher.exe itself, described below.


WHAT HAPPENED
--------------
The auto-updater (Patcher.exe) that shipped with v0.0.5 downloads
updates but never verified them against anything before installing.
If a download got corrupted partway through, or was tampered with in
transit, the patcher had no way to notice and would install it
anyway. v0.0.6 fixes this: every download is now checked against a
published SHA256 checksum before it's installed, and the update is
cancelled if it doesn't match.

This isn't a report of anyone actually being affected — it's a real
gap that existed and is now closed. Worth fixing properly rather than
leaving it.

v0.0.6 also fixes an unrelated issue where Patcher.exe would trigger
a Windows admin (UAC) prompt on launch. It now runs as a normal user.


WHAT TO DO
----------
Your existing (v0.0.5) Patcher.exe still works fine for pulling down
the v0.0.6 game files — running it like you normally would is fine,
and expected. What it can't do is fix itself, since the checksum
verification is code inside the patcher, not something it can
download and apply to itself while running.

So the full picture looks like this:

1. Run your existing Patcher.exe as usual. It'll detect v0.0.6,
   download and install the (unchanged) game files, and relaunch the
   game — this part just works, nothing to do differently here.
2. Whenever it's convenient, separately: close PyCity, download
   Patcher.zip from the v0.0.6 release page, and unzip it into your
   PyCity folder.
3. You'll see a file called Patcher.new. Delete your old Patcher.exe.
4. Rename Patcher.new to Patcher.exe.

That's the whole one-time fix — steps 2 to 4 are the only manual
part, and they only need doing once. After that, everything (game
updates and the patcher itself) is on the checksum-verified path.


HOW TO CHECK YOU'RE DOING THIS SAFELY
----------------------------------------
- Get Patcher.zip only from the official GitHub releases page:
  https://github.com/pixel-pulse-games/pycity/releases
- Note that step 1 above (your old Patcher.exe fetching the v0.0.6
  game files) is NOT checksum-verified — that's the exact gap this
  fix closes, so the old patcher still doesn't have it. Checksum
  verification only kicks in once you're running the new Patcher.exe
  from step 4 onward, for every update after this one.
- Once you're on the new Patcher.exe, it'll refuse to install an
  update that doesn't match the published checksum — you'll see a
  message in its console window if that ever happens. If it does,
  don't rename anything; just re-download.
- Your save file and settings are never touched by this process.
- If anything looks off or you're unsure, don't run it — ask on the
  GitHub repo instead.


IF YOU'RE ON v0.0.4 OR EARLIER
--------------------------------
This doesn't apply to you — those versions never had an auto-updater
in the first place.