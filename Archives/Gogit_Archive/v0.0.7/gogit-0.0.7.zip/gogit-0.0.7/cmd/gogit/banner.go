package main

import "fmt"

// PrintLogo outputs only the retro ASCII art block for GO GIT
func PrintLogo() {
	fmt.Println(`
   ____   ___      ____  ___ _____ 
  / ___| / _ \    / ___|/ _ \_   _|
 | |  _ | | | |  | |  _|_| |_| | |  
 | |_| || |_| |  | |_| | |_| | | |  
  \____| \___/    \____|___|___|_|  
                                   `)
}
