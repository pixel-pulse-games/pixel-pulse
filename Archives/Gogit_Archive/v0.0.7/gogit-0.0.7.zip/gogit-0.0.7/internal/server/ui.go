package server

// Milestone 7: repo list. Milestone 8: file browser (tree + blob
// view). Milestone 9: commit log. Milestone 9.5: account creation
// menu (gated behind existing auth - see requireAuth). All read-side
// features shell out to `git` (`ls-tree`, `show`, `log`) same as the
// protocol handlers - consistent with the project's Path A approach.

import (
	"embed"
	"html/template"
	"log"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strings"

	"gogit/internal/auth"
)

//go:embed static/*.css
var staticFS embed.FS

// pathSegmentPattern guards individual path segments used in file
// browser URLs. Not a filesystem path this time (these become
// arguments to `git ls-tree`/`git show`, not raw file paths), but
// still worth restricting: git object paths aren't filesystem paths,
// so a ".." component can't actually escape anything the way it could
// in milestone 5 - but a segment starting with "-" could be
// misinterpreted as a git command-line flag ("argument injection"),
// which is its own real category of bug. Rejecting anything that
// doesn't look like an ordinary path segment sidesteps that entirely.
var pathSegmentPattern = regexp.MustCompile(`^[A-Za-z0-9._ -]+$`)

func validateBrowsePath(path string) bool {
	if path == "" {
		return true // root
	}
	for _, seg := range strings.Split(path, "/") {
		if seg == "" || seg == "." || seg == ".." {
			return false
		}
		if strings.HasPrefix(seg, "-") {
			return false // could be read as a git flag
		}
		if !pathSegmentPattern.MatchString(seg) {
			return false
		}
	}
	return true
}

var repoListTmpl = template.Must(template.New("repos").Parse(`<!DOCTYPE html>
<html><head><title>gogit</title><link rel="stylesheet" href="/static/style.css"></head>
<body><div class="container">
<div class="dashboard-header">
<h1>gogit</h1>
{{if .Authed}}<a class="btn" href="/admin/users/new">+ Add user</a>{{end}}
</div>
<h2>Repositories</h2>
<ul class="repo-list">
{{range .Repos}}<li><a href="/{{.Name}}/tree/">{{.Name}}</a> {{if .Private}}<span class="badge badge-private">private</span>{{else}}<span class="badge badge-public">public</span>{{end}}</li>{{else}}<li>No repos found.</li>{{end}}
</ul>
</div></body></html>`))

var treeTmpl = template.Must(template.New("tree").Parse(`<!DOCTYPE html>
<html><head><title>{{.Repo}} - gogit</title><link rel="stylesheet" href="/static/style.css"></head>
<body><div class="container">
<h1><a href="/">gogit</a> / {{.Repo}}</h1>
<div class="breadcrumb">/{{.Path}}</div>
<table class="file-tree">
{{if .Path}}<tr><td class="icon">..</td><td><a href="/{{.Repo}}/tree/{{.ParentPath}}">..</a></td></tr>{{end}}
{{range .Entries}}<tr><td class="icon">{{if eq .Type "tree"}}dir{{else}}file{{end}}</td><td><a href="/{{$.Repo}}/{{if eq .Type "tree"}}tree{{else}}blob{{end}}/{{.LinkPath}}">{{.Name}}</a></td></tr>{{end}}
</table>
</div></body></html>`))

var blobTmpl = template.Must(template.New("blob").Parse(`<!DOCTYPE html>
<html><head><title>{{.Path}} - {{.Repo}} - gogit</title><link rel="stylesheet" href="/static/style.css"></head>
<body><div class="container">
<h1><a href="/">gogit</a> / <a href="/{{.Repo}}/tree/">{{.Repo}}</a></h1>
<div class="breadcrumb">/{{.Path}}</div>
<pre class="file-content">{{.Content}}</pre>
</div></body></html>`))

var commitsTmpl = template.Must(template.New("commits").Parse(`<!DOCTYPE html>
<html><head><title>Commits - {{.Repo}} - gogit</title><link rel="stylesheet" href="/static/style.css"></head>
<body><div class="container">
<h1><a href="/">gogit</a> / <a href="/{{.Repo}}/tree/">{{.Repo}}</a></h1>
<h2>Commits</h2>
<table class="file-tree">
{{range .Commits}}<tr><td class="icon">{{.ShortHash}}</td><td>{{.Message}} <span class="breadcrumb">— {{.Author}}, {{.Date}}</span></td></tr>{{else}}<tr><td colspan="2">No commits.</td></tr>{{end}}
</table>
</div></body></html>`))

var newUserFormTmpl = template.Must(template.New("newuser").Parse(`<!DOCTYPE html>
<html><head><title>Add user - gogit</title><link rel="stylesheet" href="/static/style.css"></head>
<body><div class="container">
<h1><a href="/">gogit</a> / Add user</h1>
{{if .Error}}<p style="color:#f85149">{{.Error}}</p>{{end}}
{{if .Success}}<p style="color:#3fb950">User {{.Success}} created.</p>{{end}}
<form method="POST" action="/admin/users/new">
<p><label>Username<br><input type="text" name="username" required></label></p>
<p><label>Password<br><input type="password" name="password" required></label></p>
<p><button type="submit">Create user</button></p>
</form>
</div></body></html>`))

type repoListEntry struct {
	Name    string
	Private bool
}

type repoListData struct {
	Repos  []repoListEntry
	Authed bool
}

// handleRepoList serves GET / - lists bare repos (any directory
// ending in .git) found directly under reposRoot. Private repos are
// only shown to a visitor who supplies valid credentials; anonymous
// visitors see public repos only. This check is a peek at whatever
// credentials happen to be on the request - it does not itself
// require auth, since the page as a whole is still open to everyone
// (it just shows less to people who aren't logged in).
func (s *server) handleRepoList(w http.ResponseWriter, r *http.Request) {
	entries, err := os.ReadDir(s.reposRoot)
	if err != nil {
		log.Printf("reading reposRoot: %v", err)
		http.Error(w, "internal error", http.StatusInternalServerError)
		return
	}

	authed := false
	if username, password, ok := r.BasicAuth(); ok {
		authed = s.authStore.Verify(username, password)
	}

	var repos []repoListEntry
	for _, e := range entries {
		if !e.IsDir() || !strings.HasSuffix(e.Name(), ".git") {
			continue
		}
		priv := isRepoPrivate(filepath.Join(s.reposRoot, e.Name()))
		if priv && !authed {
			continue
		}
		repos = append(repos, repoListEntry{Name: e.Name(), Private: priv})
	}

	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	if err := repoListTmpl.Execute(w, repoListData{Repos: repos, Authed: authed}); err != nil {
		log.Printf("rendering repo list: %v", err)
	}
}

type treeEntry struct {
	Type     string // "tree" or "blob"
	Name     string
	LinkPath string
}

type treeViewData struct {
	Repo       string
	Path       string
	ParentPath string
	Entries    []treeEntry
}

// handleTree serves GET /{repo}/tree/{path...} - lists the contents
// of a directory at the given path (empty path = repo root) as of
// HEAD (the default branch). Shells out to `git ls-tree`.
func (s *server) handleTree(w http.ResponseWriter, r *http.Request) {
	repoPath, ok := s.resolveRepoPath(r.PathValue("repo"))
	if !ok {
		http.Error(w, "invalid repo name", http.StatusBadRequest)
		return
	}
	if !s.requireAuthIfPrivate(w, r, repoPath) {
		return
	}
	browsePath := strings.Trim(r.PathValue("path"), "/")
	if !validateBrowsePath(browsePath) {
		http.Error(w, "invalid path", http.StatusBadRequest)
		return
	}

	ref := "HEAD"
	if browsePath != "" {
		ref = "HEAD:" + browsePath
	}

	out, err := exec.Command("git", "--git-dir="+repoPath, "ls-tree", ref).Output()
	if err != nil {
		http.Error(w, "path not found", http.StatusNotFound)
		return
	}

	var entries []treeEntry
	for _, line := range strings.Split(strings.TrimRight(string(out), "\n"), "\n") {
		if line == "" {
			continue
		}
		// Format: "<mode> <type> <sha>\t<name>"
		tabIdx := strings.IndexByte(line, '\t')
		if tabIdx == -1 {
			continue
		}
		meta := strings.Fields(line[:tabIdx])
		name := line[tabIdx+1:]
		if len(meta) < 2 {
			continue
		}
		typ := meta[1] // "tree" or "blob"
		linkPath := name
		if browsePath != "" {
			linkPath = browsePath + "/" + name
		}
		entries = append(entries, treeEntry{Type: typ, Name: name, LinkPath: linkPath})
	}

	parent := ""
	if idx := strings.LastIndex(browsePath, "/"); idx != -1 {
		parent = browsePath[:idx]
	}

	data := treeViewData{
		Repo:       r.PathValue("repo"),
		Path:       browsePath,
		ParentPath: parent,
		Entries:    entries,
	}

	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	if err := treeTmpl.Execute(w, data); err != nil {
		log.Printf("rendering tree view: %v", err)
	}
}

type blobViewData struct {
	Repo    string
	Path    string
	Content string
}

// handleBlob serves GET /{repo}/blob/{path...} - shows a file's
// contents as of HEAD. Shells out to `git show`.
func (s *server) handleBlob(w http.ResponseWriter, r *http.Request) {
	repoPath, ok := s.resolveRepoPath(r.PathValue("repo"))
	if !ok {
		http.Error(w, "invalid repo name", http.StatusBadRequest)
		return
	}
	if !s.requireAuthIfPrivate(w, r, repoPath) {
		return
	}
	browsePath := strings.Trim(r.PathValue("path"), "/")
	if browsePath == "" || !validateBrowsePath(browsePath) {
		http.Error(w, "invalid path", http.StatusBadRequest)
		return
	}

	out, err := exec.Command("git", "--git-dir="+repoPath, "show", "HEAD:"+browsePath).Output()
	if err != nil {
		http.Error(w, "file not found", http.StatusNotFound)
		return
	}

	data := blobViewData{
		Repo:    r.PathValue("repo"),
		Path:    browsePath,
		Content: string(out),
	}

	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	if err := blobTmpl.Execute(w, data); err != nil {
		log.Printf("rendering blob view: %v", err)
	}
}

type commitEntry struct {
	ShortHash string
	Author    string
	Date      string
	Message   string
}

type commitsViewData struct {
	Repo    string
	Commits []commitEntry
}

// handleCommits serves GET /{repo}/commits - a log of commits on
// HEAD (the default branch): hash, author, date, message. Shells out
// to `git log`. Milestone 9.
func (s *server) handleCommits(w http.ResponseWriter, r *http.Request) {
	repoPath, ok := s.resolveRepoPath(r.PathValue("repo"))
	if !ok {
		http.Error(w, "invalid repo name", http.StatusBadRequest)
		return
	}
	if !s.requireAuthIfPrivate(w, r, repoPath) {
		return
	}
	if _, err := os.Stat(repoPath); err != nil {
		http.Error(w, "repo not found", http.StatusNotFound)
		return
	}

	// \x1f (unit separator) as the field delimiter, not something
	// printable like "|" - a commit message could easily contain a
	// pipe character and silently corrupt the parsing.
	const format = "%h\x1f%an\x1f%ad\x1f%s"
	out, err := exec.Command("git", "--git-dir="+repoPath, "log", "--date=short", "--pretty=format:"+format).Output()
	if err != nil {
		// Empty repo (no commits yet) - not an error, just nothing to show.
		out = nil
	}

	var commits []commitEntry
	if len(out) > 0 {
		for _, line := range strings.Split(string(out), "\n") {
			parts := strings.SplitN(line, "\x1f", 4)
			if len(parts) != 4 {
				continue
			}
			commits = append(commits, commitEntry{
				ShortHash: parts[0],
				Author:    parts[1],
				Date:      parts[2],
				Message:   parts[3],
			})
		}
	}

	data := commitsViewData{Repo: r.PathValue("repo"), Commits: commits}

	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	if err := commitsTmpl.Execute(w, data); err != nil {
		log.Printf("rendering commits view: %v", err)
	}
}

type newUserFormData struct {
	Error   string
	Success string
}

// handleNewUserForm serves GET /admin/users/new - the account
// creation form. Gated behind requireAuth (milestone 9.5): only
// someone with existing valid credentials can even see this page.
// The very first account is still bootstrapped via the -create-user
// CLI flag; this page is for adding more after that.
func (s *server) handleNewUserForm(w http.ResponseWriter, r *http.Request) {
	if !s.requireAuth(w, r) {
		return
	}
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	if err := newUserFormTmpl.Execute(w, newUserFormData{}); err != nil {
		log.Printf("rendering new user form: %v", err)
	}
}

// handleCreateUser serves POST /admin/users/new - creates the user
// submitted by the form above. Also gated behind requireAuth: this
// endpoint being reachable at all already implies valid credentials
// were supplied (checked again here since a POST can arrive without
// ever loading the GET form first).
func (s *server) handleCreateUser(w http.ResponseWriter, r *http.Request) {
	if !s.requireAuth(w, r) {
		return
	}

	if err := r.ParseForm(); err != nil {
		http.Error(w, "malformed form", http.StatusBadRequest)
		return
	}
	username := strings.TrimSpace(r.FormValue("username"))
	password := r.FormValue("password")

	data := newUserFormData{}
	if username == "" || password == "" {
		data.Error = "username and password are both required"
	} else if err := auth.AddUser(s.userFile, username, password); err != nil {
		log.Printf("creating user %q: %v", username, err)
		data.Error = "failed to create user"
	} else {
		data.Success = username
		// Reload so the new user is usable immediately without
		// restarting the server.
		if store, err := auth.LoadStore(s.userFile); err == nil {
			s.authStore = store
		}
	}

	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	if err := newUserFormTmpl.Execute(w, data); err != nil {
		log.Printf("rendering new user form: %v", err)
	}
}

// handleStaticCSS serves the one embedded CSS file at an exact path
// (not a wildcard subtree) specifically to avoid ambiguity with the
// {repo} wildcard routes - see server.go's route registration for why
// a subtree route here caused a startup panic.
func handleStaticCSS(w http.ResponseWriter, r *http.Request) {
	data, err := staticFS.ReadFile("static/style.css")
	if err != nil {
		http.Error(w, "not found", http.StatusNotFound)
		return
	}
	w.Header().Set("Content-Type", "text/css; charset=utf-8")
	w.Write(data)
}