// Package auth implements a minimal flat-file user store for HTTP
// Basic Auth, used to gate pushes (milestone 6).
//
// Tradeoff: flat file vs SQLite. Flat file was chosen for simplicity
// and zero extra dependencies - fine at the scale of "one server
// process, a handful of users." SQLite would give real concurrent
// write safety and query flexibility, worth revisiting if gogit ever
// needs many users or concurrent writes to the user store.
//
// Tradeoff: password hashing uses salted SHA-256 (stdlib only), not
// bcrypt. bcrypt (golang.org/x/crypto/bcrypt) is the normal choice
// for password storage, but it's an external module this environment
// couldn't fetch and build-test against. Treat this as a known
// simplification to upgrade later, not a long-term recommendation.
package auth

import (
	"bufio"
	"crypto/rand"
	"crypto/sha256"
	"crypto/subtle"
	"encoding/hex"
	"fmt"
	"os"
	"strings"
)

// Store holds loaded username -> credential entries.
type Store struct {
	users map[string]credential
}

type credential struct {
	salt []byte
	hash []byte
}

// LoadStore reads a flat file of "username:hexsalt:hexhash" lines.
// A missing file is not an error - it just means no users are
// configured yet, which Verify treats as "deny everyone" (secure
// default: no users means nothing can authenticate, not everything
// can).
func LoadStore(path string) (*Store, error) {
	s := &Store{users: map[string]credential{}}

	f, err := os.Open(path)
	if err != nil {
		if os.IsNotExist(err) {
			return s, nil
		}
		return nil, err
	}
	defer f.Close()

	scanner := bufio.NewScanner(f)
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		parts := strings.SplitN(line, ":", 3)
		if len(parts) != 3 {
			continue
		}
		salt, err1 := hex.DecodeString(parts[1])
		hash, err2 := hex.DecodeString(parts[2])
		if err1 != nil || err2 != nil {
			continue
		}
		s.users[parts[0]] = credential{salt: salt, hash: hash}
	}
	return s, scanner.Err()
}

// hashPassword combines a salt and password with SHA-256. See the
// package doc comment for why this is SHA-256 and not bcrypt.
func hashPassword(password string, salt []byte) []byte {
	h := sha256.New()
	h.Write(salt)
	h.Write([]byte(password))
	return h.Sum(nil)
}

// Verify reports whether username/password match a stored credential.
// Uses a constant-time comparison so response timing doesn't leak
// whether the hash was close to correct.
func (s *Store) Verify(username, password string) bool {
	cred, ok := s.users[username]
	if !ok {
		return false
	}
	computed := hashPassword(password, cred.salt)
	return subtle.ConstantTimeCompare(computed, cred.hash) == 1
}

// Empty reports whether no users are configured at all.
func (s *Store) Empty() bool {
	return len(s.users) == 0
}

// AddUser hashes password with a fresh random salt and appends a new
// line to the flat file store at path, creating it if needed.
func AddUser(path, username, password string) error {
	salt := make([]byte, 16)
	if _, err := rand.Read(salt); err != nil {
		return err
	}
	hash := hashPassword(password, salt)
	line := fmt.Sprintf("%s:%s:%s\n", username, hex.EncodeToString(salt), hex.EncodeToString(hash))

	f, err := os.OpenFile(path, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0600)
	if err != nil {
		return err
	}
	defer f.Close()

	_, err = f.WriteString(line)
	return err
}