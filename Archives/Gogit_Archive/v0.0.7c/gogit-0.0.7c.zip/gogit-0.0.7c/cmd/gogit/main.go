package main

import (
	"crypto/rand"
	"encoding/hex"
	"flag"
	"fmt"
	"log"
	"net/http"
	"sync"

	"gogit/internal/auth"
	"gogit/internal/server"
)

type SessionStore struct {
	mu       sync.RWMutex
	sessions map[string]string // sessionID -> username
}

var sessionStore = &SessionStore{
	sessions: make(map[string]string),
}

// authStore is the single source of truth for credentials, shared by
// this file's session-based login/register handlers AND
// internal/server's push/private-repo auth checks (via
// server.RegisterGitAndBrowseRoutes). Previously main.go had its own
// separate UserStore that stored passwords in plain text - that's
// gone; this is the same bcrypt-backed store internal/server always
// used.
var authStore *auth.Store
var userFilePath string

type PageData struct {
	Authed   bool
	Username string
	Error    string
	Success  string
	Repos    []RepoInfo
}

type RepoInfo struct {
	Name    string
	Private bool
}

func main() {
	PrintLogo()

	addr := flag.String("addr", ":8080", "HTTP service address")
	reposDir := flag.String("repos", "./data", "Directory containing git repos")
	userFile := flag.String("userfile", "./users.txt", "Path to user authentication store")
	createUser := flag.String("create-user", "", "CLI helper to create an initial user")
	password := flag.String("password", "", "Password for CLI user creation")
	initRepo := flag.String("init-repo", "", "create a new bare repo under -repos and exit, e.g. -init-repo myproject")
	private := flag.Bool("private", false, "with -init-repo, mark the new repo private")
	owner := flag.String("owner", "", "with -init-repo, restrict push access to this username (unowned repos allow any authenticated user to push)")
	addCollaborator := flag.String("add-collaborator", "", "grant push access on -repo-name to this username, in addition to its owner")
	repoName := flag.String("repo-name", "", "repo name to use with -add-collaborator")
	flag.Parse()

	userFilePath = *userFile

	if *initRepo != "" {
		runInitRepo(*reposDir, *initRepo, *private, *owner)
		return
	}

	if *addCollaborator != "" {
		if *repoName == "" {
			log.Fatal("-repo-name is required when using -add-collaborator")
		}
		runAddCollaborator(*reposDir, *repoName, *addCollaborator)
		return
	}

	if *createUser != "" {
		if *password == "" {
			log.Fatal("Password required when creating a user via CLI flag -password")
		}
		if err := auth.AddUser(userFilePath, *createUser, *password); err != nil {
			log.Fatalf("Failed to create user: %v", err)
		}
		fmt.Printf("User %q created successfully.\n", *createUser)
		return
	}

	store, err := auth.LoadStore(userFilePath)
	if err != nil {
		log.Fatalf("failed to load user store %q: %v", userFilePath, err)
	}
	authStore = store
	if authStore.Empty() {
		log.Printf("no users configured in %q - bootstrap one with -create-user before pushing or logging in", userFilePath)
	}

	mux := http.NewServeMux()

	// cmd/gogit's own routes: the session-based web UI (login,
	// register, repo list, admin) built on top of the shared
	// authStore above.
	mux.HandleFunc("/", handleHome(*reposDir))
	mux.HandleFunc("/login", handleLogin)
	mux.HandleFunc("/register", handleRegister)
	mux.HandleFunc("/logout", handleLogout)
	mux.HandleFunc("/admin/users/new", handleAdminNewUser)

	// internal/server's routes: the actual git protocol (clone/push),
	// file browser, and commit log - previously wired up to nothing,
	// meaning `git clone` didn't work against this binary at all.
	// Restored here on the same mux and the same authStore, so a
	// private repo is gated consistently whether it's reached through
	// the browser or a `git` client.
	server.RegisterGitAndBrowseRoutes(mux, *reposDir, userFilePath)

	fmt.Printf("gogit server starting at http://localhost%s\n", *addr)
	log.Fatal(http.ListenAndServe(*addr, mux))
}

func getAuthUser(r *http.Request) (string, bool) {
	cookie, err := r.Cookie("gogit_session")
	if err != nil {
		return "", false
	}
	sessionStore.mu.RLock()
	defer sessionStore.mu.RUnlock()
	username, exists := sessionStore.sessions[cookie.Value]
	return username, exists
}

func createSession(w http.ResponseWriter, r *http.Request, username string) {
	b := make([]byte, 16)
	rand.Read(b)
	sessionID := hex.EncodeToString(b)

	sessionStore.mu.Lock()
	sessionStore.sessions[sessionID] = username
	sessionStore.mu.Unlock()

	isSecure := r.TLS != nil || r.Header.Get("X-Forwarded-Proto") == "https"

	http.SetCookie(w, &http.Cookie{
		Name:     "gogit_session",
		Value:    sessionID,
		Path:     "/",
		HttpOnly: true,
		Secure:   isSecure,
		SameSite: http.SameSiteLaxMode,
	})
}