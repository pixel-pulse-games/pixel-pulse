package server

import (
	"bytes"
	"compress/gzip"
	"embed"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strings"

	"gogit/internal/auth"
)

//go:embed static/style.css
var staticCSS embed.FS

// handleStaticCSS serves the one embedded CSS file. Embedding keeps
// gogit.exe a single self-contained binary - no dependency on the
// static/ folder existing on disk next to wherever the binary is
// run from (main.go previously served this from disk via
// http.Dir("./internal/server/static"), which only worked if the
// binary happened to be run from the repo root).
func handleStaticCSS(w http.ResponseWriter, r *http.Request) {
	data, err := staticCSS.ReadFile("static/style.css")
	if err != nil {
		http.Error(w, "not found", http.StatusNotFound)
		return
	}
	w.Header().Set("Content-Type", "text/css; charset=utf-8")
	w.Write(data)
}

type Config struct {
	Addr      string
	ReposRoot string
	UserFile  string
}

type server struct {
	reposRoot string
	// userFile is reloaded fresh on every auth check rather than
	// cached as a *auth.Store - a cached pointer went stale the
	// moment a new user registered through cmd/gogit's own handlers,
	// since reassigning main.go's authStore variable doesn't update
	// a copy of that pointer already handed to this struct. Reading
	// a small flat file per request is cheap at this project's scale
	// and avoids that whole class of staleness bug.
	userFile string
}

// loadAuthStore reloads the user store from disk. See the userFile
// field comment for why this isn't cached.
func (s *server) loadAuthStore() *auth.Store {
	store, err := auth.LoadStore(s.userFile)
	if err != nil {
		log.Printf("warning: failed to load user store %q: %v (denying auth)", s.userFile, err)
		return &auth.Store{}
	}
	return store
}

// RegisterGitAndBrowseRoutes wires the git protocol routes (ref
// advertisement, upload-pack, receive-pack), the file browser
// (tree/blob), the commit log, and the embedded static CSS onto an
// existing mux - everything in this package except the repo list and
// account pages, which cmd/gogit provides its own versions of. This
// exists specifically so cmd/gogit's own web server (with its
// session-based login) and this package's git protocol
// implementation can share one mux and one auth store instead of
// running as two disconnected servers.
func RegisterGitAndBrowseRoutes(mux *http.ServeMux, reposRoot string, userFile string) {
	s := &server{reposRoot: reposRoot, userFile: userFile}

	mux.HandleFunc("GET /static/style.css", handleStaticCSS)
	mux.HandleFunc("GET /{owner}/{repo}/tree/{path...}", s.handleTree)
	mux.HandleFunc("GET /{owner}/{repo}/blob/{path...}", s.handleBlob)
	mux.HandleFunc("GET /{owner}/{repo}/commits", s.handleCommits)
	mux.HandleFunc("GET /{owner}/{repo}/commits/", s.handleCommits)
	mux.HandleFunc("GET /{owner}/{repo}/actions", s.handleActionsList)
	mux.HandleFunc("GET /{owner}/{repo}/actions/", s.handleActionsList)
	mux.HandleFunc("GET /{owner}/{repo}/actions/{run}", s.handleActionDetail)
	mux.HandleFunc("GET /{owner}/{repo}/info/refs", s.handleInfoRefs)
	mux.HandleFunc("POST /{owner}/{repo}/git-upload-pack", s.handleUploadPack)
	mux.HandleFunc("POST /{owner}/{repo}/git-receive-pack", s.handleReceivePack)
}

func New(cfg Config) *http.Server {
	s := &server{reposRoot: cfg.ReposRoot, userFile: cfg.UserFile}
	if s.loadAuthStore().Empty() {
		log.Printf("no users configured in %q - all pushes will be denied until a user is added", cfg.UserFile)
	}

	mux := http.NewServeMux()
	mux.HandleFunc("/healthz", handleHealthz)
	mux.HandleFunc("GET /{$}", s.handleUserIndex)
	mux.HandleFunc("GET /admin/users/new", s.handleNewUserForm)
	mux.HandleFunc("POST /admin/users/new", s.handleCreateUser)
	mux.HandleFunc("GET /{username}", s.handleUserRepos)
	mux.HandleFunc("GET /{username}/", s.handleUserRepos)
	mux.HandleFunc("GET /{owner}/{repo}/tree/{path...}", s.handleTree)
	mux.HandleFunc("GET /{owner}/{repo}/blob/{path...}", s.handleBlob)
	mux.HandleFunc("GET /{owner}/{repo}/commits", s.handleCommits)
	mux.HandleFunc("GET /{owner}/{repo}/commits/", s.handleCommits)
	mux.HandleFunc("GET /{owner}/{repo}/actions", s.handleActionsList)
	mux.HandleFunc("GET /{owner}/{repo}/actions/", s.handleActionsList)
	mux.HandleFunc("GET /{owner}/{repo}/actions/{run}", s.handleActionDetail)
	mux.HandleFunc("GET /{owner}/{repo}/info/refs", s.handleInfoRefs)
	mux.HandleFunc("POST /{owner}/{repo}/git-upload-pack", s.handleUploadPack)
	mux.HandleFunc("POST /{owner}/{repo}/git-receive-pack", s.handleReceivePack)

	return &http.Server{
		Addr:    cfg.Addr,
		Handler: logRequests(mux),
	}
}

var ownerNamePattern = regexp.MustCompile(`^[A-Za-z0-9_-]+$`)
var repoNamePattern = regexp.MustCompile(`^[A-Za-z0-9_-]+\.git$`)

// resolveRepoPath maps a URL's {owner}/{repo} segments to the repo's
// actual location on disk, data/{owner}/{repo}.git - the namespaced
// layout every repo lives under as of v0.0.9. Both segments are
// pattern-validated before being joined with reposRoot, and the
// resulting path is confirmed to still live under reposRoot (defense
// in depth against path traversal, same check this function already
// did before namespacing - just applied to two segments now instead
// of one).
func (s *server) resolveRepoPath(owner, repoName string) (string, bool) {
	if !ownerNamePattern.MatchString(owner) || !repoNamePattern.MatchString(repoName) {
		return "", false
	}

	full := filepath.Join(s.reposRoot, owner, repoName)

	absRoot, err := filepath.Abs(s.reposRoot)
	if err != nil {
		return "", false
	}
	absFull, err := filepath.Abs(full)
	if err != nil {
		return "", false
	}
	if absFull != absRoot && !strings.HasPrefix(absFull, absRoot+string(os.PathSeparator)) {
		return "", false
	}

	return full, true
}

// IsRepoPrivate reports whether a repo is marked private, stored as
// ordinary git config inside the bare repo itself
// (`git config gogit.private true`). Exported so cmd/gogit's own web
// UI handlers (repo list, etc.) can use the real check instead of a
// separate, weaker one.
func IsRepoPrivate(repoPath string) bool {
	return isRepoPrivate(repoPath)
}

func isRepoPrivate(repoPath string) bool {
	out, err := exec.Command("git", "--git-dir="+repoPath, "config", "--get", "--bool", "gogit.private").Output()
	if err != nil {
		return false
	}
	return strings.TrimSpace(string(out)) == "true"
}

func (s *server) requireAuthIfPrivate(w http.ResponseWriter, r *http.Request, repoPath string) bool {
	if !isRepoPrivate(repoPath) {
		return true
	}
	return s.requireAuth(w, r)
}

// RepoOwner returns the username stored as this repo's owner
// (`git config gogit.owner <username>`), or "" if unowned. Exported
// so cmd/gogit's web UI can display it.
func RepoOwner(repoPath string) string {
	out, err := exec.Command("git", "--git-dir="+repoPath, "config", "--get", "gogit.owner").Output()
	if err != nil {
		return ""
	}
	return strings.TrimSpace(string(out))
}

// RepoCollaborators returns every username granted push access to a
// repo beyond its owner, stored as a multi-valued git config key
// (`git config --add gogit.collaborator <username>`, one entry per
// collaborator). Exported for the same reason as RepoOwner.
func RepoCollaborators(repoPath string) []string {
	out, err := exec.Command("git", "--git-dir="+repoPath, "config", "--get-all", "gogit.collaborator").Output()
	if err != nil {
		return nil
	}
	lines := strings.Split(strings.TrimSpace(string(out)), "\n")
	var names []string
	for _, l := range lines {
		if l = strings.TrimSpace(l); l != "" {
			names = append(names, l)
		}
	}
	return names
}

// canPush reports whether username is allowed to push to repoPath.
//
// A repo with no owner set is unowned - anyone with valid
// credentials can push to it, same as every milestone before this
// one. This is a deliberate backward-compatibility default: repos
// created before ownership existed (or via -init-repo without
// -owner) don't suddenly become unpushable to their existing users.
// A repo WITH an owner set restricts pushes to that owner plus
// anyone explicitly listed as a collaborator.
func canPush(repoPath, username string) bool {
	owner := RepoOwner(repoPath)
	if owner == "" {
		return true
	}
	if username == owner {
		return true
	}
	for _, collaborator := range RepoCollaborators(repoPath) {
		if username == collaborator {
			return true
		}
	}
	return false
}

func (s *server) requireAuth(w http.ResponseWriter, r *http.Request) bool {
	_, ok := s.requireAuthUser(w, r)
	return ok
}

// requireAuthUser is requireAuth plus returning which user actually
// authenticated - needed for ownership checks (canPush), where it's
// not enough to know *someone* valid is pushing, but specifically
// *who*.
func (s *server) requireAuthUser(w http.ResponseWriter, r *http.Request) (string, bool) {
	store := s.loadAuthStore()
	if store.Empty() {
		w.Header().Set("WWW-Authenticate", `Basic realm="gogit"`)
		http.Error(w, "denied: no users configured on this server yet (bootstrap one with -create-user)", http.StatusUnauthorized)
		return "", false
	}

	username, password, ok := r.BasicAuth()
	if !ok || !store.Verify(username, password) {
		w.Header().Set("WWW-Authenticate", `Basic realm="gogit"`)
		http.Error(w, "invalid credentials", http.StatusUnauthorized)
		return "", false
	}

	return username, true
}

func (s *server) getAuthUser(r *http.Request) (string, bool) {
	store := s.loadAuthStore()
	if store.Empty() {
		return "", false
	}
	username, password, ok := r.BasicAuth()
	if !ok || !store.Verify(username, password) {
		return "", false
	}
	return username, true
}

func (s *server) handleInfoRefs(w http.ResponseWriter, r *http.Request) {
	service := r.URL.Query().Get("service")

	var gitCmd string
	switch service {
	case "git-upload-pack":
		gitCmd = "upload-pack"
	case "git-receive-pack":
		gitCmd = "receive-pack"
		username, ok := s.requireAuthUser(w, r)
		if !ok {
			return
		}
		repoPathForPushCheck, ok := s.resolveRepoPath(r.PathValue("owner"), r.PathValue("repo"))
		if ok && !canPush(repoPathForPushCheck, username) {
			http.Error(w, "you don't have push access to this repo", http.StatusForbidden)
			return
		}
	default:
		http.Error(w, "unsupported service", http.StatusForbidden)
		return
	}

	repoPath, ok := s.resolveRepoPath(r.PathValue("owner"), r.PathValue("repo"))
	if !ok {
		http.Error(w, "invalid repo name", http.StatusBadRequest)
		return
	}
	if _, err := os.Stat(repoPath); err != nil {
		http.Error(w, "repo not found", http.StatusNotFound)
		return
	}
	if gitCmd == "upload-pack" && !s.requireAuthIfPrivate(w, r, repoPath) {
		return
	}

	var out bytes.Buffer
	cmd := exec.Command("git", gitCmd, "--stateless-rpc", "--advertise-refs", repoPath)
	cmd.Stdout = &out
	cmd.Stderr = os.Stderr
	if err := cmd.Run(); err != nil {
		log.Printf("%s --advertise-refs failed: %v", gitCmd, err)
		http.Error(w, "internal error", http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", fmt.Sprintf("application/x-%s-advertisement", service))
	w.Header().Set("Cache-Control", "no-cache")
	w.WriteHeader(http.StatusOK)

	w.Write(pktLine(fmt.Sprintf("# service=%s\n", service)))
	w.Write(pktFlush())
	w.Write(out.Bytes())
}

func (s *server) handleUploadPack(w http.ResponseWriter, r *http.Request) {
	repoPath, ok := s.resolveRepoPath(r.PathValue("owner"), r.PathValue("repo"))
	if !ok {
		http.Error(w, "invalid repo name", http.StatusBadRequest)
		return
	}
	if _, err := os.Stat(repoPath); err != nil {
		http.Error(w, "repo not found", http.StatusNotFound)
		return
	}
	if !s.requireAuthIfPrivate(w, r, repoPath) {
		return
	}

	var reqBody io.Reader = r.Body
	if r.Header.Get("Content-Encoding") == "gzip" {
		gz, err := gzip.NewReader(r.Body)
		if err != nil {
			http.Error(w, "malformed gzip body", http.StatusBadRequest)
			return
		}
		defer gz.Close()
		reqBody = gz
	}

	cmd := exec.Command("git", "upload-pack", "--stateless-rpc", repoPath)
	cmd.Stdin = reqBody
	cmd.Stderr = os.Stderr

	stdout, err := cmd.StdoutPipe()
	if err != nil {
		log.Printf("upload-pack stdout pipe: %v", err)
		http.Error(w, "internal error", http.StatusInternalServerError)
		return
	}

	if err := cmd.Start(); err != nil {
		log.Printf("upload-pack start: %v", err)
		http.Error(w, "internal error", http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/x-git-upload-pack-result")
	w.Header().Set("Cache-Control", "no-cache")
	w.WriteHeader(http.StatusOK)

	if _, err := io.Copy(w, stdout); err != nil {
		log.Printf("streaming upload-pack output: %v", err)
	}

	if err := cmd.Wait(); err != nil {
		log.Printf("upload-pack exited with error: %v", err)
	}
}

func (s *server) handleReceivePack(w http.ResponseWriter, r *http.Request) {
	username, ok := s.requireAuthUser(w, r)
	if !ok {
		return
	}

	repoPath, ok := s.resolveRepoPath(r.PathValue("owner"), r.PathValue("repo"))
	if !ok {
		http.Error(w, "invalid repo name", http.StatusBadRequest)
		return
	}
	if _, err := os.Stat(repoPath); err != nil {
		http.Error(w, "repo not found", http.StatusNotFound)
		return
	}
	if !canPush(repoPath, username) {
		http.Error(w, "you don't have push access to this repo", http.StatusForbidden)
		return
	}

	var reqBody io.Reader = r.Body
	if r.Header.Get("Content-Encoding") == "gzip" {
		gz, err := gzip.NewReader(r.Body)
		if err != nil {
			http.Error(w, "malformed gzip body", http.StatusBadRequest)
			return
		}
		defer gz.Close()
		reqBody = gz
	}

	cmd := exec.Command("git", "receive-pack", "--stateless-rpc", repoPath)
	cmd.Stdin = reqBody
	cmd.Stderr = os.Stderr

	stdout, err := cmd.StdoutPipe()
	if err != nil {
		log.Printf("receive-pack stdout pipe: %v", err)
		http.Error(w, "internal error", http.StatusInternalServerError)
		return
	}

	if err := cmd.Start(); err != nil {
		log.Printf("receive-pack start: %v", err)
		http.Error(w, "internal error", http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/x-git-receive-pack-result")
	w.Header().Set("Cache-Control", "no-cache")
	w.WriteHeader(http.StatusOK)

	if _, err := io.Copy(w, stdout); err != nil {
		log.Printf("streaming receive-pack output: %v", err)
	}

	if err := cmd.Wait(); err != nil {
		log.Printf("receive-pack exited with error: %v", err)
	}
}

func pktLine(s string) []byte {
	length := len(s) + 4
	return []byte(fmt.Sprintf("%04x%s", length, s))
}

func pktFlush() []byte {
	return []byte("0000")
}

func handleHealthz(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "text/plain")
	w.WriteHeader(http.StatusOK)
	w.Write([]byte("ok\n"))
}

func logRequests(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		log.Printf("%s %s", r.Method, r.URL.RequestURI())
		next.ServeHTTP(w, r)
	})
}
