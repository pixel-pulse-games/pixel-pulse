package server

import (
	"embed"
	"fmt"
	"html/template"
	"log"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strings"

	"gogit/internal/auth"
)

// Embed HTML template files from internal/server/templates
//
//go:embed templates/*.html
var TemplateFS embed.FS

// pathSegmentPattern guards individual path segments used in file browser URLs.
var pathSegmentPattern = regexp.MustCompile(`^[a-zA-Z0-9_.\-]+$`)

func validatePathSegment(segment string) bool {
	if segment == "" || segment == "." || segment == ".." {
		return false
	}
	if strings.HasPrefix(segment, "-") {
		return false
	}
	return pathSegmentPattern.MatchString(segment)
}

var tmpl = template.Must(template.ParseFS(TemplateFS, "templates/*.html"))

type repoInfo struct {
	Name    string
	Owner   string
	Private bool
}

// userIndexData backs the homepage (/) - an index of every user who
// owns at least one repo, replacing what used to be one flat list of
// every repo on the server. Repos with no owner (pre-namespacing
// legacy repos that haven't been migrated) have nowhere coherent to
// live in a per-user index and don't appear here - see
// handleUserIndex's doc comment.
type userIndexData struct {
	Authed   bool
	Username string
	Users    []string
}

// handleUserIndex serves GET / - an index of users, each linking to
// their own repo list at /{username}. Every repo lives under
// data/{owner}/{repo}.git as of v0.0.9 (see resolveRepoPath), so this
// walks one level of owner directories rather than repos directly.
func (s *server) handleUserIndex(w http.ResponseWriter, r *http.Request) {
	if r.URL.Path != "/" {
		http.NotFound(w, r)
		return
	}

	username, authed := s.getAuthUser(r)

	var users []string
	entries, err := os.ReadDir(s.reposRoot)
	if err == nil {
		for _, entry := range entries {
			if !entry.IsDir() || strings.HasSuffix(entry.Name(), ".git") {
				// Skip anything that isn't an owner directory - in
				// particular, a *.git dir sitting directly under
				// reposRoot is a pre-namespacing repo that hasn't
				// been migrated yet (see -migrate-to-namespaced),
				// not a username.
				continue
			}
			// Only list users who actually have at least one repo
			// visible to this viewer, so an empty owner directory
			// (or one containing only private repos, viewed by a
			// stranger) doesn't show up as a dead end.
			if userHasVisibleRepo(filepath.Join(s.reposRoot, entry.Name()), authed) {
				users = append(users, entry.Name())
			}
		}
	}

	data := userIndexData{
		Authed:   authed,
		Username: username,
		Users:    users,
	}

	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	if err := tmpl.ExecuteTemplate(w, "user_index.html", data); err != nil {
		log.Printf("rendering user_index template: %v", err)
	}
}

func userHasVisibleRepo(userDir string, authed bool) bool {
	entries, err := os.ReadDir(userDir)
	if err != nil {
		return false
	}
	for _, entry := range entries {
		if !entry.IsDir() || !strings.HasSuffix(entry.Name(), ".git") {
			continue
		}
		if authed || !isRepoPrivate(filepath.Join(userDir, entry.Name())) {
			return true
		}
	}
	return false
}

type userRepoListData struct {
	Authed     bool
	Username   string
	ViewedUser string
	Repos      []repoInfo
}

// handleUserRepos serves GET /{username} - one user's repos, the
// per-user page the homepage's user index links into.
func (s *server) handleUserRepos(w http.ResponseWriter, r *http.Request) {
	viewedUser := r.PathValue("username")
	if !validatePathSegment(viewedUser) {
		http.Error(w, "invalid username", http.StatusBadRequest)
		return
	}

	username, authed := s.getAuthUser(r)

	userDir := filepath.Join(s.reposRoot, viewedUser)
	var repos []repoInfo
	entries, err := os.ReadDir(userDir)
	if err == nil {
		for _, entry := range entries {
			if !entry.IsDir() || !strings.HasSuffix(entry.Name(), ".git") {
				continue
			}
			name := strings.TrimSuffix(entry.Name(), ".git")
			repoPath := filepath.Join(userDir, entry.Name())
			private := isRepoPrivate(repoPath)

			if private && !authed {
				continue
			}

			repos = append(repos, repoInfo{
				Name:    name,
				Owner:   viewedUser,
				Private: private,
			})
		}
	}

	data := userRepoListData{
		Authed:     authed,
		Username:   username,
		ViewedUser: viewedUser,
		Repos:      repos,
	}

	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	if err := tmpl.ExecuteTemplate(w, "repo_list.html", data); err != nil {
		log.Printf("rendering repo_list template: %v", err)
	}
}

type treeEntry struct {
	Mode     string
	Type     string // "blob" or "tree"
	Hash     string
	Name     string
	LinkPath string // full path from the repo root, for building this entry's tree/blob URL
}

type treePageData struct {
	Authed      bool
	Username    string
	Owner       string
	RepoName    string
	Ref         string
	Subpath     string
	ParentPath  string // Subpath one level up, for the ".." row; "" once back at the root
	Breadcrumbs []breadcrumb
	Entries     []treeEntry
	IsBlob      bool
	BlobContent string
}

type breadcrumb struct {
	Name string
	Path string
}

func (s *server) handleTree(w http.ResponseWriter, r *http.Request) {
	s.handleTreeOrBlob(w, r, "tree")
}

func (s *server) handleBlob(w http.ResponseWriter, r *http.Request) {
	s.handleTreeOrBlob(w, r, "blob")
}

func (s *server) handleTreeOrBlob(w http.ResponseWriter, r *http.Request, defaultAction string) {
	parts := strings.Split(strings.Trim(r.URL.Path, "/"), "/")
	// owner + repo + action ("tree"/"blob") are required - the ref
	// segment past that is optional. Links like /{owner}/{repo}/tree/
	// (no ref) are exactly what the repo list and the tab bar
	// generate, meaning "show me the default branch" rather than a
	// specific ref.
	if len(parts) < 3 {
		http.NotFound(w, r)
		return
	}

	owner := parts[0]
	repoName := parts[1]
	action := parts[2]
	if action != "tree" && action != "blob" {
		action = defaultAction
	}

	if !validatePathSegment(owner) || !validatePathSegment(repoName) {
		http.Error(w, "invalid request", http.StatusBadRequest)
		return
	}

	repoPath := filepath.Join(s.reposRoot, owner, repoName+".git")
	if _, err := os.Stat(repoPath); os.IsNotExist(err) {
		http.NotFound(w, r)
		return
	}
	if isRepoPrivate(repoPath) {
		if _, authed := s.getAuthUser(r); !authed {
			w.Header().Set("WWW-Authenticate", `Basic realm="gogit"`)
			http.Error(w, "Unauthorized", http.StatusUnauthorized)
			return
		}
	}

	var ref string
	var subpathParts []string
	if len(parts) >= 4 {
		ref = parts[3]
		if !validatePathSegment(ref) {
			http.Error(w, "invalid request", http.StatusBadRequest)
			return
		}
		subpathParts = parts[4:]
	} else {
		resolved, err := defaultBranch(repoPath)
		if err != nil {
			http.Error(w, "repository has no commits yet", http.StatusNotFound)
			return
		}
		ref = resolved
	}

	for _, seg := range subpathParts {
		if !validatePathSegment(seg) {
			http.Error(w, "invalid path segment", http.StatusBadRequest)
			return
		}
	}
	subpath := strings.Join(subpathParts, "/")

	username, authed := s.getAuthUser(r)

	var crumbs []breadcrumb
	accum := ""
	for _, seg := range subpathParts {
		if accum == "" {
			accum = seg
		} else {
			accum = accum + "/" + seg
		}
		crumbs = append(crumbs, breadcrumb{Name: seg, Path: accum})
	}

	data := treePageData{
		Authed:      authed,
		Username:    username,
		Owner:       owner,
		RepoName:    repoName,
		Ref:         ref,
		Subpath:     subpath,
		ParentPath:  parentPath(subpath),
		Breadcrumbs: crumbs,
	}

	if action == "blob" {
		data.IsBlob = true
		content, err := gitShowBlob(repoPath, ref, subpath)
		if err != nil {
			http.Error(w, "file not found or binary file", http.StatusNotFound)
			return
		}
		data.BlobContent = content
	} else {
		entries, err := gitLsTree(repoPath, ref, subpath)
		if err != nil {
			http.Error(w, "tree not found", http.StatusNotFound)
			return
		}
		for i := range entries {
			if subpath == "" {
				entries[i].LinkPath = entries[i].Name
			} else {
				entries[i].LinkPath = subpath + "/" + entries[i].Name
			}
		}
		data.Entries = entries
	}

	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	if err := tmpl.ExecuteTemplate(w, "tree.html", data); err != nil {
		log.Printf("rendering tree template: %v", err)
	}
}

// defaultBranch resolves which branch /{repo}/tree/ (no explicit ref)
// should show - the repo's actual HEAD, same as what `git clone`
// would check out, rather than a hardcoded guess like "main" or
// "master" (this project's own repos were created under "master" by
// older git defaults, so hardcoding "main" would 404 on those).
func defaultBranch(repoPath string) (string, error) {
	cmd := exec.Command("git", "--git-dir="+repoPath, "symbolic-ref", "--short", "HEAD")
	out, err := cmd.Output()
	if err != nil {
		return "", fmt.Errorf("resolving default branch: %w", err)
	}
	branch := strings.TrimSpace(string(out))
	if branch == "" {
		return "", fmt.Errorf("empty HEAD")
	}
	return branch, nil
}

// parentPath returns subpath one directory level up - "" once back at
// the repo root, which the template uses to decide whether to show a
// ".." row at all.
func parentPath(subpath string) string {
	if subpath == "" {
		return ""
	}
	idx := strings.LastIndex(subpath, "/")
	if idx < 0 {
		return ""
	}
	return subpath[:idx]
}

func gitLsTree(repoPath, ref, subpath string) ([]treeEntry, error) {
	target := ref
	if subpath != "" {
		target = ref + ":" + subpath
	}

	cmd := exec.Command("git", "--git-dir="+repoPath, "ls-tree", target)
	out, err := cmd.Output()
	if err != nil {
		return nil, err
	}

	var entries []treeEntry
	lines := strings.Split(string(out), "\n")
	for _, line := range lines {
		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}
		tabParts := strings.SplitN(line, "\t", 2)
		if len(tabParts) < 2 {
			continue
		}
		metaParts := strings.Fields(tabParts[0])
		if len(metaParts) < 3 {
			continue
		}
		entries = append(entries, treeEntry{
			Mode: metaParts[0],
			Type: metaParts[1],
			Hash: metaParts[2],
			Name: tabParts[1],
		})
	}
	return entries, nil
}

func gitShowBlob(repoPath, ref, subpath string) (string, error) {
	target := ref + ":" + subpath
	cmd := exec.Command("git", "--git-dir="+repoPath, "show", target)
	out, err := cmd.Output()
	if err != nil {
		return "", err
	}
	return string(out), nil
}

type commitLogEntry struct {
	Hash      string
	ShortHash string
	Author    string
	Date      string
	Message   string
}

type commitsPageData struct {
	Authed   bool
	Username string
	Owner    string
	RepoName string
	Commits  []commitLogEntry
}

func (s *server) handleCommits(w http.ResponseWriter, r *http.Request) {
	parts := strings.Split(strings.Trim(r.URL.Path, "/"), "/")
	if len(parts) < 3 || parts[2] != "commits" {
		http.NotFound(w, r)
		return
	}

	owner := parts[0]
	repoName := parts[1]
	if !validatePathSegment(owner) || !validatePathSegment(repoName) {
		http.Error(w, "invalid repo name", http.StatusBadRequest)
		return
	}

	repoPath := filepath.Join(s.reposRoot, owner, repoName+".git")
	if isRepoPrivate(repoPath) {
		if _, authed := s.getAuthUser(r); !authed {
			w.Header().Set("WWW-Authenticate", `Basic realm="gogit"`)
			http.Error(w, "Unauthorized", http.StatusUnauthorized)
			return
		}
	}

	if _, err := os.Stat(repoPath); os.IsNotExist(err) {
		http.NotFound(w, r)
		return
	}

	username, authed := s.getAuthUser(r)

	commits, err := gitLog(repoPath)
	if err != nil {
		commits = []commitLogEntry{}
	}

	data := commitsPageData{
		Authed:   authed,
		Username: username,
		Owner:    owner,
		RepoName: repoName,
		Commits:  commits,
	}

	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	if err := tmpl.ExecuteTemplate(w, "commits.html", data); err != nil {
		log.Printf("rendering commits template: %v", err)
	}
}

func gitLog(repoPath string) ([]commitLogEntry, error) {
	format := "%H\x1f%an\x1f%ad\x1f%s"
	cmd := exec.Command("git", "--git-dir="+repoPath, "log", "--pretty=format:"+format, "--date=short")
	out, err := cmd.Output()
	if err != nil {
		return nil, err
	}

	var entries []commitLogEntry
	lines := strings.Split(string(out), "\n")
	for _, line := range lines {
		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}
		fields := strings.Split(line, "\x1f")
		if len(fields) < 4 {
			continue
		}
		hash := fields[0]
		shortHash := hash
		if len(hash) > 8 {
			shortHash = hash[:8]
		}
		entries = append(entries, commitLogEntry{
			Hash:      hash,
			ShortHash: shortHash,
			Author:    fields[1],
			Date:      fields[2],
			Message:   fields[3],
		})
	}
	return entries, nil
}

type newUserFormData struct {
	Authed   bool
	Username string
	Error    string
	Success  string
}

// handleNewUserForm handles GET /admin/users/new.
func (s *server) handleNewUserForm(w http.ResponseWriter, r *http.Request) {
	if !s.requireAuth(w, r) {
		return
	}
	username, _ := s.getAuthUser(r)
	data := newUserFormData{
		Authed:   true,
		Username: username,
	}

	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	if err := tmpl.ExecuteTemplate(w, "new_user.html", data); err != nil {
		log.Printf("rendering new user form: %v", err)
	}
}

// handleCreateUser handles POST /admin/users/new.
func (s *server) handleCreateUser(w http.ResponseWriter, r *http.Request) {
	if !s.requireAuth(w, r) {
		return
	}

	if err := r.ParseForm(); err != nil {
		http.Error(w, "malformed form", http.StatusBadRequest)
		return
	}
	username := strings.TrimSpace(r.FormValue("username"))
	password := r.FormValue("password")

	data := newUserFormData{}
	if username == "" || password == "" {
		data.Error = "username and password are both required"
	} else if err := auth.AddUser(s.userFile, username, password); err != nil {
		log.Printf("creating user %q: %v", username, err)
		data.Error = "failed to create user"
	} else {
		// No manual reload needed - loadAuthStore() always reads
		// fresh from disk, so this new user is usable immediately.
		data.Success = username
	}

	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	if err := tmpl.ExecuteTemplate(w, "new_user.html", data); err != nil {
		log.Printf("rendering new user form: %v", err)
	}
}
