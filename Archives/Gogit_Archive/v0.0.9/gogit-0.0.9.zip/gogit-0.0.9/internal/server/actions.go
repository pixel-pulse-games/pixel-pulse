package server

import (
	"log"
	"net/http"
	"path/filepath"
	"strings"
	"time"

	"gogit/internal/ci"
)

type actionRunView struct {
	ID         string
	Ref        string
	ShortSHA   string
	Status     string
	StartedAt  string
	FinishedAt string
}

type actionsListPageData struct {
	Authed   bool
	Username string
	Owner    string
	RepoName string
	Runs     []actionRunView
}

// handleActionsList serves GET /{owner}/{repo}/actions - a run
// history list, newest first, in the same "tab next to Code/Commits"
// style as the rest of the repo-scoped pages.
func (s *server) handleActionsList(w http.ResponseWriter, r *http.Request) {
	parts := strings.Split(strings.Trim(r.URL.Path, "/"), "/")
	if len(parts) < 3 || parts[2] != "actions" {
		http.NotFound(w, r)
		return
	}

	owner := parts[0]
	repoName := parts[1]
	if !validatePathSegment(owner) || !validatePathSegment(repoName) {
		http.Error(w, "invalid repo name", http.StatusBadRequest)
		return
	}

	repoPath := filepath.Join(s.reposRoot, owner, repoName+".git")
	if isRepoPrivate(repoPath) {
		if _, authed := s.getAuthUser(r); !authed {
			w.Header().Set("WWW-Authenticate", `Basic realm="gogit"`)
			http.Error(w, "Unauthorized", http.StatusUnauthorized)
			return
		}
	}

	username, authed := s.getAuthUser(r)

	runs, err := ci.ListRuns(repoPath)
	if err != nil {
		log.Printf("listing CI runs for %s/%s: %v", owner, repoName, err)
	}

	data := actionsListPageData{
		Authed:   authed,
		Username: username,
		Owner:    owner,
		RepoName: repoName,
	}
	for _, run := range runs {
		data.Runs = append(data.Runs, actionRunView{
			ID:         run.ID,
			Ref:        run.Ref,
			ShortSHA:   run.ShortSHA,
			Status:     string(run.Status),
			StartedAt:  formatRunTime(run.StartedAt),
			FinishedAt: formatRunTime(run.FinishedAt),
		})
	}

	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	if err := tmpl.ExecuteTemplate(w, "actions.html", data); err != nil {
		log.Printf("rendering actions template: %v", err)
	}
}

type actionDetailPageData struct {
	Authed   bool
	Username string
	Owner    string
	RepoName string
	Run      actionRunView
	Detail   string
	Log      string
	Found    bool
}

// handleActionDetail serves GET /{owner}/{repo}/actions/{id} - one
// run's full log, for debugging a failed workflow.
func (s *server) handleActionDetail(w http.ResponseWriter, r *http.Request) {
	parts := strings.Split(strings.Trim(r.URL.Path, "/"), "/")
	if len(parts) < 4 || parts[2] != "actions" {
		http.NotFound(w, r)
		return
	}

	owner := parts[0]
	repoName := parts[1]
	runID := parts[3]
	if !validatePathSegment(owner) || !validatePathSegment(repoName) {
		http.Error(w, "invalid repo name", http.StatusBadRequest)
		return
	}

	repoPath := filepath.Join(s.reposRoot, owner, repoName+".git")
	if isRepoPrivate(repoPath) {
		if _, authed := s.getAuthUser(r); !authed {
			w.Header().Set("WWW-Authenticate", `Basic realm="gogit"`)
			http.Error(w, "Unauthorized", http.StatusUnauthorized)
			return
		}
	}

	username, authed := s.getAuthUser(r)

	data := actionDetailPageData{
		Authed:   authed,
		Username: username,
		Owner:    owner,
		RepoName: repoName,
	}

	run, logText, err := ci.GetRun(repoPath, runID)
	if err != nil {
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		w.WriteHeader(http.StatusNotFound)
		if tErr := tmpl.ExecuteTemplate(w, "actions_run.html", data); tErr != nil {
			log.Printf("rendering actions_run template: %v", tErr)
		}
		return
	}

	data.Found = true
	data.Log = logText
	data.Detail = run.Detail
	data.Run = actionRunView{
		ID:         run.ID,
		Ref:        run.Ref,
		ShortSHA:   run.ShortSHA,
		Status:     string(run.Status),
		StartedAt:  formatRunTime(run.StartedAt),
		FinishedAt: formatRunTime(run.FinishedAt),
	}

	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	if err := tmpl.ExecuteTemplate(w, "actions_run.html", data); err != nil {
		log.Printf("rendering actions_run template: %v", err)
	}
}

func formatRunTime(t time.Time) string {
	if t.IsZero() {
		return ""
	}
	return t.Local().Format("2006-01-02 15:04:05")
}
