package main

import (
	"fmt"
	"log"
	"os"
	"os/exec"
	"path/filepath"
	"strings"

	"gogit/internal/ci"
)

// runInitRepo creates a new bare repo under reposRoot/{owner}/ and
// exits. owner is required as of v0.0.9: every repo now lives at a
// URL of the form /{owner}/{repo}, so there's no coherent address
// for a repo with no owner to create it under. (Repos created before
// this version, which may genuinely have no owner, are handled by
// -migrate-to-namespaced instead - see reposmigrate.go.)
func runInitRepo(reposRoot, name string, private bool, owner string) {
	if owner == "" {
		log.Fatal("-owner is required with -init-repo as of v0.0.9 - every repo now lives at /{owner}/{repo}. Use -migrate-to-namespaced instead if you're upgrading an existing pre-v0.0.9 install.")
	}

	if !strings.HasSuffix(name, ".git") {
		name += ".git"
	}
	ownerDir := filepath.Join(reposRoot, owner)
	if err := os.MkdirAll(ownerDir, 0755); err != nil {
		log.Fatalf("failed to create owner directory %s: %v", ownerDir, err)
	}
	path := filepath.Join(ownerDir, name)

	if _, err := os.Stat(path); err == nil {
		log.Fatalf("repo already exists: %s", path)
	}

	cmd := exec.Command("git", "init", "--bare", path)
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	if err := cmd.Run(); err != nil {
		log.Fatalf("failed to create repo: %v", err)
	}

	if private {
		cfgCmd := exec.Command("git", "--git-dir="+path, "config", "gogit.private", "true")
		if err := cfgCmd.Run(); err != nil {
			log.Fatalf("repo created, but failed to mark it private: %v", err)
		}
	}

	cfgCmd := exec.Command("git", "--git-dir="+path, "config", "gogit.owner", owner)
	if err := cfgCmd.Run(); err != nil {
		log.Fatalf("repo created, but failed to set owner: %v", err)
	}

	visibility := "public"
	if private {
		visibility = "private"
	}
	fmt.Printf("Created %s bare repo at %s (owned by %s)\n", visibility, path, owner)
	fmt.Printf("Clone URL: http://<host>/%s/%s\n", owner, name)

	// CI is on by default for every repo: install the post-receive
	// hook now, same as any other property a freshly-created repo
	// starts with (private, owner). If this fails, the repo still
	// exists and works for plain git/web use - CI just doesn't fire
	// until -install-ci-hook is run for it later - so this doesn't
	// call log.Fatalf.
	if err := installCIHook(path); err != nil {
		log.Printf("repo created, but failed to install CI hook: %v", err)
		log.Printf("push/pull still work; re-run with -install-ci-hook -repos %s -owner %s -repo-name %s to enable CI", reposRoot, owner, strings.TrimSuffix(name, ".git"))
	} else {
		fmt.Println("CI enabled: pushes will run .github/workflows/*.yml via act")
	}
}

// installCIHook resolves the currently-running gogit binary's own
// path and installs it into repoPath's post-receive hook - shared by
// both -init-repo (new repos, CI on by default) and -install-ci-hook
// (retrofitting a repo created before this feature, or one whose
// hook was deleted).
func installCIHook(repoPath string) error {
	bin, err := ci.ResolveGogitBin()
	if err != nil {
		return err
	}
	return ci.InstallHook(repoPath, bin)
}

// runInstallCIHook retrofits CI onto an existing repo.
func runInstallCIHook(reposRoot, owner, repoName string) {
	if !strings.HasSuffix(repoName, ".git") {
		repoName += ".git"
	}
	path := filepath.Join(reposRoot, owner, repoName)

	if _, err := os.Stat(path); err != nil {
		log.Fatalf("repo not found: %s", path)
	}
	if err := installCIHook(path); err != nil {
		log.Fatalf("failed to install CI hook: %v", err)
	}
	fmt.Printf("CI enabled on %s: pushes will run .github/workflows/*.yml via act\n", path)
}

// runAddCollaborator grants push access on an existing repo to an
// additional user, beyond its owner. No effect on unowned repos,
// since those already allow anyone with valid credentials to push -
// only meaningful once a repo actually has an owner restricting it.
func runAddCollaborator(reposRoot, owner, repoName, username string) {
	if !strings.HasSuffix(repoName, ".git") {
		repoName += ".git"
	}
	path := filepath.Join(reposRoot, owner, repoName)

	if _, err := os.Stat(path); err != nil {
		log.Fatalf("repo not found: %s", path)
	}

	cmd := exec.Command("git", "--git-dir="+path, "config", "--add", "gogit.collaborator", username)
	if err := cmd.Run(); err != nil {
		log.Fatalf("failed to add collaborator: %v", err)
	}
	fmt.Printf("%s can now push to %s\n", username, path)
}
