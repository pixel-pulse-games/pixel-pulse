package main

import (
	"fmt"
	"io"
	"log"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"time"

	"gogit/internal/server"
)

// unownedNamespace is where a migrated repo lands if it has no
// gogit.owner set - a real, pre-existing state for repos created
// before per-repo permissions existed (see canPush's doc comment).
// There's no username to put these under, so they get a clearly-
// labeled reserved bucket instead of silently staying unreachable.
const unownedNamespace = "_unowned"

// ownerNamePattern mirrors internal/server's own validation for the
// {owner} URL segment - a migrated repo's target directory name has
// to satisfy the same constraint the web server will later require
// to serve it at /{owner}/{repo}.
var ownerNamePattern = regexp.MustCompile(`^[A-Za-z0-9_-]+$`)

// runMigrateToNamespaced upgrades a pre-v0.0.9 reposRoot (repos sitting
// flat as data/{repo}.git) to the namespaced layout every repo lives
// under as of v0.0.9 (data/{owner}/{repo}.git), moving each repo
// under a directory named for its actual owner (gogit.owner git
// config - the same field -init-repo -owner and -add-collaborator
// already use). Repos with no owner move under a reserved
// "_unowned" namespace rather than being skipped, since they're a
// real, valid pre-existing state, not an error case.
//
// The entire reposRoot is backed up (full copy, not just the repos
// being touched) to a timestamped sibling directory before anything
// is moved, and the move itself is a directory rename (not a copy),
// safe to run again if it's interrupted partway - already-migrated
// repos (no longer sitting flat in reposRoot) are simply skipped on
// a second run.
func runMigrateToNamespaced(reposRoot string) {
	absRoot, err := filepath.Abs(reposRoot)
	if err != nil {
		log.Fatalf("resolving %s: %v", reposRoot, err)
	}

	entries, err := os.ReadDir(absRoot)
	if err != nil {
		log.Fatalf("reading %s: %v", absRoot, err)
	}

	var flatRepos []string
	for _, entry := range entries {
		if entry.IsDir() && strings.HasSuffix(entry.Name(), ".git") {
			flatRepos = append(flatRepos, entry.Name())
		}
	}

	if len(flatRepos) == 0 {
		fmt.Println("No pre-namespacing repos found directly under", absRoot, "- nothing to migrate.")
		return
	}

	backupDir := absRoot + "-backup-" + time.Now().UTC().Format("20060102-150405")
	fmt.Printf("Backing up %s to %s before making any changes...\n", absRoot, backupDir)
	if err := copyDir(absRoot, backupDir); err != nil {
		log.Fatalf("backup failed, aborting migration (nothing was moved): %v", err)
	}
	fmt.Println("Backup complete.")

	moved, skipped := 0, 0
	for _, name := range flatRepos {
		src := filepath.Join(absRoot, name)

		owner := server.RepoOwner(src)
		if owner == "" {
			owner = unownedNamespace
		} else if !ownerNamePattern.MatchString(owner) {
			log.Printf("warning: %s has an owner (%q) that isn't a safe directory name - moving to %s instead", name, owner, unownedNamespace)
			owner = unownedNamespace
		}

		targetDir := filepath.Join(absRoot, owner)
		if err := os.MkdirAll(targetDir, 0755); err != nil {
			log.Printf("skipping %s: couldn't create %s: %v", name, targetDir, err)
			skipped++
			continue
		}

		dst := filepath.Join(targetDir, name)
		if _, err := os.Stat(dst); err == nil {
			log.Printf("skipping %s: %s already exists - resolve manually", name, dst)
			skipped++
			continue
		}

		if err := os.Rename(src, dst); err != nil {
			log.Printf("skipping %s: move to %s failed: %v", name, dst, err)
			skipped++
			continue
		}

		fmt.Printf("moved %s -> %s/%s\n", name, owner, name)
		moved++
	}

	fmt.Printf("\nMigration complete: %d moved, %d skipped.\n", moved, skipped)
	fmt.Printf("Backup preserved at %s - safe to delete once you've verified the migrated repos.\n", backupDir)
	if skipped > 0 {
		fmt.Println("Some repos were skipped - see warnings above. They're untouched (still at their original flat path) and can be migrated by hand or by re-running this command after resolving the conflict.")
	}
}

// copyDir recursively copies src to dst, preserving the directory
// tree and regular file contents - a bare git repo is just files and
// directories, no symlinks to worry about. Implemented in pure Go
// rather than shelling out to `cp -a`: this needs to work identically
// on the Windows builds too, where there's no `cp` to shell out to.
func copyDir(src, dst string) error {
	return filepath.Walk(src, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}

		rel, err := filepath.Rel(src, path)
		if err != nil {
			return err
		}
		target := filepath.Join(dst, rel)

		if info.IsDir() {
			return os.MkdirAll(target, info.Mode())
		}

		return copyFile(path, target, info.Mode())
	})
}

func copyFile(src, dst string, mode os.FileMode) error {
	in, err := os.Open(src)
	if err != nil {
		return err
	}
	defer in.Close()

	if err := os.MkdirAll(filepath.Dir(dst), 0755); err != nil {
		return err
	}

	out, err := os.OpenFile(dst, os.O_WRONLY|os.O_CREATE|os.O_TRUNC, mode)
	if err != nil {
		return err
	}
	defer out.Close()

	_, err = io.Copy(out, in)
	return err
}
