package main

import (
	"crypto/rand"
	"encoding/hex"
	"flag"
	"fmt"
	"log"
	"net/http"
	"sync"

	"gogit/internal/auth"
	"gogit/internal/ci"
	"gogit/internal/server"
)

type SessionStore struct {
	mu       sync.RWMutex
	sessions map[string]string // sessionID -> username
}

var sessionStore = &SessionStore{
	sessions: make(map[string]string),
}

// authStore is the single source of truth for credentials, shared by
// this file's session-based login/register handlers AND
// internal/server's push/private-repo auth checks (via
// server.RegisterGitAndBrowseRoutes). Previously main.go had its own
// separate UserStore that stored passwords in plain text - that's
// gone; this is the same bcrypt-backed store internal/server always
// used.
var authStore *auth.Store
var userFilePath string

type PageData struct {
	Authed   bool
	Username string
	Error    string
	Success  string
	Repos    []RepoInfo
}

type RepoInfo struct {
	Name    string
	Owner   string
	Private bool
}

// UserIndexData backs the home page (/) - an index of users, each
// linking to their own repo list. Replaces PageData's old flat
// .Repos list now that every repo lives under a username namespace
// (data/{owner}/{repo}.git).
type UserIndexData struct {
	Authed   bool
	Username string
	Users    []string
}

// UserRepoListData backs GET /{username} - one user's repos.
type UserRepoListData struct {
	Authed     bool
	Username   string
	ViewedUser string
	Repos      []RepoInfo
}

func main() {
	PrintLogo()

	addr := flag.String("addr", ":8080", "HTTP service address")
	reposDir := flag.String("repos", "./data", "Directory containing git repos")
	userFile := flag.String("userfile", "./users.txt", "Path to user authentication store")
	createUser := flag.String("create-user", "", "CLI helper to create an initial user")
	password := flag.String("password", "", "Password for CLI user creation")
	initRepo := flag.String("init-repo", "", "create a new bare repo under -repos and exit, e.g. -init-repo myproject -owner alice")
	private := flag.Bool("private", false, "with -init-repo, mark the new repo private")
	owner := flag.String("owner", "", "with -init-repo (required as of v0.0.9), -add-collaborator, or -install-ci-hook: the repo's namespace, e.g. /alice/myproject")
	addCollaborator := flag.String("add-collaborator", "", "grant push access on -owner/-repo-name to this username, in addition to its owner")
	repoName := flag.String("repo-name", "", "repo name to use with -add-collaborator or -install-ci-hook")
	installCIHookFlag := flag.Bool("install-ci-hook", false, "install/reinstall the CI post-receive hook on -owner/-repo-name (retrofit onto a repo made before this feature, or restore a deleted hook)")
	migrateFlag := flag.Bool("migrate-to-namespaced", false, "one-time upgrade: move pre-v0.0.9 flat repos (data/{repo}.git) into the namespaced layout (data/{owner}/{repo}.git), backing up -repos first")
	ciRun := flag.Bool("ci-run", false, "internal: invoked by the post-receive hook itself, not meant to be run by hand")
	ciRepo := flag.String("ci-repo", "", "with -ci-run: git-dir of the repo that was pushed to (the hook passes its own $(pwd))")
	ciSHA := flag.String("ci-sha", "", "with -ci-run: the new commit SHA that was pushed")
	ciRef := flag.String("ci-ref", "", "with -ci-run: the ref that was pushed")
	flag.Parse()

	userFilePath = *userFile

	// -ci-run is how the post-receive hook (see internal/ci/hook.go)
	// calls back into this same binary - it's a CLI-helper mode, not
	// the HTTP server, and exits as soon as the one run is done.
	if *ciRun {
		if *ciRepo == "" || *ciSHA == "" {
			log.Fatal("-ci-run requires -ci-repo and -ci-sha")
		}
		cfg := ci.ConfigFromEnv()
		run, err := ci.RunWorkflow(cfg, *ciRepo, *ciRef, *ciSHA)
		if err != nil {
			// Only a bookkeeping failure (couldn't write status/log
			// to disk) reaches here - a workflow that ran and failed
			// is a normal *Run with Status == StatusFailed, not this
			// branch. Either way, a non-zero exit from a hook must
			// never fail the push itself: git already accepted the
			// pack before post-receive runs, so this is purely
			// informational for whoever's watching the terminal that
			// ran `git push`.
			log.Printf("gogit ci run failed to complete: %v", err)
			return
		}
		fmt.Printf("gogit ci: %s run %s finished with status %s\n", run.Ref, run.ID, run.Status)
		// Exit 0 regardless of run.Status (including Failed/Error):
		// a red build must never fail the push itself, since git has
		// already accepted the pack by the time post-receive runs.
		// The status is informational, visible via run.Status above
		// and on the /{repo}/actions web page - not via this
		// process's exit code.
		return
	}

	if *migrateFlag {
		runMigrateToNamespaced(*reposDir)
		return
	}

	if *installCIHookFlag {
		if *repoName == "" || *owner == "" {
			log.Fatal("-owner and -repo-name are both required when using -install-ci-hook")
		}
		runInstallCIHook(*reposDir, *owner, *repoName)
		return
	}

	if *initRepo != "" {
		runInitRepo(*reposDir, *initRepo, *private, *owner)
		return
	}

	if *addCollaborator != "" {
		if *repoName == "" || *owner == "" {
			log.Fatal("-owner and -repo-name are both required when using -add-collaborator")
		}
		runAddCollaborator(*reposDir, *owner, *repoName, *addCollaborator)
		return
	}

	if *createUser != "" {
		if *password == "" {
			log.Fatal("Password required when creating a user via CLI flag -password")
		}
		if err := auth.AddUser(userFilePath, *createUser, *password); err != nil {
			log.Fatalf("Failed to create user: %v", err)
		}
		fmt.Printf("User %q created successfully.\n", *createUser)
		return
	}

	store, err := auth.LoadStore(userFilePath)
	if err != nil {
		log.Fatalf("failed to load user store %q: %v", userFilePath, err)
	}
	authStore = store
	if authStore.Empty() {
		log.Printf("no users configured in %q - bootstrap one with -create-user before pushing or logging in", userFilePath)
	}

	mux := http.NewServeMux()

	// cmd/gogit's own routes: the session-based web UI (login,
	// register, repo list, admin) built on top of the shared
	// authStore above.
	mux.HandleFunc("/", handleHome(*reposDir))
	mux.HandleFunc("GET /login", handleLogin)
	mux.HandleFunc("POST /login", handleLogin)
	mux.HandleFunc("GET /register", handleRegister)
	mux.HandleFunc("POST /register", handleRegister)
	mux.HandleFunc("GET /logout", handleLogout)
	mux.HandleFunc("GET /admin/users/new", handleAdminNewUser)
	mux.HandleFunc("POST /admin/users/new", handleAdminNewUser)
	mux.HandleFunc("GET /{username}", handleUserRepos(*reposDir))
	mux.HandleFunc("GET /{username}/", handleUserRepos(*reposDir))
	mux.HandleFunc("GET /new-repo", handleNewRepoForm(*reposDir, *userFile))
	mux.HandleFunc("POST /new-repo", handleCreateRepo(*reposDir))

	// internal/server's routes: the actual git protocol (clone/push),
	// file browser, and commit log - previously wired up to nothing,
	// meaning `git clone` didn't work against this binary at all.
	// Restored here on the same mux and the same authStore, so a
	// private repo is gated consistently whether it's reached through
	// the browser or a `git` client.
	server.RegisterGitAndBrowseRoutes(mux, *reposDir, userFilePath)

	fmt.Printf("gogit server starting at http://localhost%s\n", *addr)
	log.Fatal(http.ListenAndServe(*addr, mux))
}

func getAuthUser(r *http.Request) (string, bool) {
	cookie, err := r.Cookie("gogit_session")
	if err != nil {
		return "", false
	}
	sessionStore.mu.RLock()
	defer sessionStore.mu.RUnlock()
	username, exists := sessionStore.sessions[cookie.Value]
	return username, exists
}

func createSession(w http.ResponseWriter, r *http.Request, username string) {
	b := make([]byte, 16)
	rand.Read(b)
	sessionID := hex.EncodeToString(b)

	sessionStore.mu.Lock()
	sessionStore.sessions[sessionID] = username
	sessionStore.mu.Unlock()

	isSecure := r.TLS != nil || r.Header.Get("X-Forwarded-Proto") == "https"

	http.SetCookie(w, &http.Cookie{
		Name:     "gogit_session",
		Value:    sessionID,
		Path:     "/",
		HttpOnly: true,
		Secure:   isSecure,
		SameSite: http.SameSiteLaxMode,
	})
}
