# Security Policy

## Reporting a Vulnerability

We welcome security audits from ethical researchers to keep gogit safe. 

If you discover a security flaw or exploit in gogit, please do NOT open a public issue. Instead, please use the official **Private Vulnerability Reporting** button on this repository's Security tab to submit your report safely and privately to the maintainer. 

Thank you for helping protect the ecosystem!
