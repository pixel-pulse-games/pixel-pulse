module gogit

go 1.22
