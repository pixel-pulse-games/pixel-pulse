// Package auth implements a minimal flat-file user store for HTTP
// Basic Auth and session-based login, used to gate pushes, private
// repos, and account creation.
//
// Tradeoff: flat file vs SQLite. Flat file was chosen for simplicity
// and zero extra dependencies - fine at the scale of "one server
// process, a handful of users." SQLite would give real concurrent
// write safety and query flexibility, worth revisiting if gogit ever
// needs many users or concurrent writes to the user store.
//
// Password hashing uses bcrypt (vendored at internal/vendored/bcrypt
// - see that directory's README for why it's vendored by hand rather
// than a normal module dependency, and how to switch to a real
// golang.org/x/crypto/bcrypt dependency once you have normal network
// access). This replaced an earlier salted-SHA-256 stopgap - bcrypt
// is the standard, correct choice for password storage.
package auth

import (
	"bufio"
	"fmt"
	"os"
	"strings"

	"gogit/internal/vendored/bcrypt"
)

// Store holds loaded username -> bcrypt hash entries.
type Store struct {
	users map[string]string // username -> bcrypt hash
}

// LoadStore reads a flat file of "username:bcrypthash" lines.
// A missing file is not an error - it just means no users are
// configured yet, which Verify treats as "deny everyone" (secure
// default: no users means nothing can authenticate, not everything
// can).
func LoadStore(path string) (*Store, error) {
	s := &Store{users: map[string]string{}}

	f, err := os.Open(path)
	if err != nil {
		if os.IsNotExist(err) {
			return s, nil
		}
		return nil, err
	}
	defer f.Close()

	scanner := bufio.NewScanner(f)
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		parts := strings.SplitN(line, ":", 2)
		if len(parts) != 2 {
			continue
		}
		s.users[parts[0]] = parts[1]
	}
	return s, scanner.Err()
}

// Verify reports whether username/password match a stored credential.
// bcrypt.CompareHashAndPassword is constant-time by construction, so
// no separate constant-time comparison is needed here (unlike the
// earlier SHA-256 version, which had to do that manually).
func (s *Store) Verify(username, password string) bool {
	hash, ok := s.users[username]
	if !ok {
		return false
	}
	return bcrypt.CompareHashAndPassword([]byte(hash), []byte(password)) == nil
}

// Empty reports whether no users are configured at all.
func (s *Store) Empty() bool {
	return len(s.users) == 0
}

// AddUser hashes password with bcrypt and appends a new line to the
// flat file store at path, creating it if needed. Returns an error
// if the username already exists - without this check, "adding" an
// existing username would silently overwrite their password, since
// LoadStore's map keeps only the last line for a given username.
func AddUser(path, username, password string) error {
	existing, err := LoadStore(path)
	if err != nil {
		return err
	}
	if _, taken := existing.users[username]; taken {
		return fmt.Errorf("user %q already exists", username)
	}

	hashBytes, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	if err != nil {
		return err
	}
	line := fmt.Sprintf("%s:%s\n", username, string(hashBytes))

	f, err := os.OpenFile(path, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0600)
	if err != nil {
		return err
	}
	defer f.Close()

	_, err = f.WriteString(line)
	return err
}