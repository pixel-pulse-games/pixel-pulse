package ci

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

// postReceiveScript is a real git post-receive hook
// (https://git-scm.com/docs/githooks#_post_receive) - git itself
// invokes this after `git receive-pack` finishes applying a push,
// feeding "<old-sha> <new-sha> <refname>" lines on stdin, one per
// updated ref. It calls back into the same gogit binary in a small
// CLI-helper mode (-ci-run) for each one.
//
// This is the standard git extension point, not something gogit's
// HTTP layer invents or has to parse pack data for - the same hook
// would fire on a push from any git client, or from `git push`
// against this repo from the server's own filesystem.
const postReceiveScript = `#!/bin/sh
# Installed by gogit (internal/ci.InstallHook). Runs each pushed ref
# through gogit's CI runner (act, talking to whatever container
# engine is on DOCKER_HOST - normally Podman). Safe to delete this
# file to turn CI off for this repo; re-run
#   gogit -install-ci-hook -repos <dir> -repo-name <name>
# to put it back.
GOGIT_BIN=%s
while read oldrev newrev refname; do
  "$GOGIT_BIN" -ci-run -ci-repo "$(pwd)" -ci-sha "$newrev" -ci-ref "$refname"
done
`

// shellSingleQuote quotes s for safe use as a single POSIX shell
// word, so an unusual install path (spaces, etc.) can't break the
// generated hook script.
func shellSingleQuote(s string) string {
	return "'" + strings.ReplaceAll(s, "'", `'\''`) + "'"
}

// InstallHook writes (or overwrites) repoPath's post-receive hook so
// pushes to it trigger gogit's CI runner. gogitBin is the absolute
// path to the gogit binary the hook should call back into - pass the
// currently-running binary's own path (see cmd/gogit's use of
// os.Executable) so the hook keeps working regardless of what
// directory git later runs it from.
func InstallHook(repoPath, gogitBin string) error {
	hooksDir := filepath.Join(repoPath, "hooks")
	if err := os.MkdirAll(hooksDir, 0755); err != nil {
		return fmt.Errorf("creating hooks dir: %w", err)
	}

	script := fmt.Sprintf(postReceiveScript, shellSingleQuote(gogitBin))
	hookPath := filepath.Join(hooksDir, "post-receive")
	if err := os.WriteFile(hookPath, []byte(script), 0755); err != nil {
		return fmt.Errorf("writing post-receive hook: %w", err)
	}
	return nil
}

// ResolveGogitBin returns the absolute, symlink-resolved path to the
// currently running gogit binary, for use as InstallHook's gogitBin
// argument.
func ResolveGogitBin() (string, error) {
	exe, err := os.Executable()
	if err != nil {
		return "", fmt.Errorf("resolving own binary path: %w", err)
	}
	resolved, err := filepath.EvalSymlinks(exe)
	if err != nil {
		// Fall back to the unresolved path rather than failing repo
		// creation outright over this - same "don't let a soft
		// failure block a harder-won operation" spirit as the rest
		// of this codebase's error handling.
		return exe, nil
	}
	return resolved, nil
}
