// Package ci is gogit's answer to "something like GitHub Actions."
//
// It does NOT reimplement a workflow engine or a container runtime -
// consistent with the rest of gogit (which shells out to the real
// `git` binary rather than reimplementing the git wire protocol from
// scratch), this package shells out to the real `act` binary
// (https://github.com/nektos/act), which already knows how to parse
// `.github/workflows/*.yml` and run them. `act` in turn talks to
// whatever container engine is listening on DOCKER_HOST - normally
// that's Podman's Docker-API-compatible socket
// (unix:///run/podman/podman.sock or the rootless per-user
// equivalent), not Docker itself. Neither `act` nor Podman's Go
// internals are vendored into this binary: both are full projects
// with their own large dependency trees (container runtime plumbing,
// Docker client bindings, etc.) that would break gogit's
// single-self-contained-binary approach if imported directly. They
// run as separate installed programs, same as `git` does.
//
// Trigger path: cmd/gogit installs a real git `post-receive` hook on
// every repo it creates (see hook.go). That hook is what git itself
// invokes after `git receive-pack` finishes processing a push - not
// something gogit's HTTP layer has to detect or parse pack data for.
// The hook calls back into the same gogit binary in a small
// CLI-helper mode (`-ci-run`), which is what this package's
// RunWorkflow does the actual work for.
package ci

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strings"
	"time"

	"gogit/internal/actbin"
)

// Config controls how workflows are actually executed. All fields
// have workable zero-value defaults, so a bare Config{} is fine for
// most setups - the values are only worth overriding on servers where
// `act` isn't on PATH, or where the container engine's socket isn't
// at the default location `act` already looks for.
//
// In practice these come from environment variables (GOGIT_ACT_PATH,
// GOGIT_CONTAINER_HOST) rather than command-line flags: the
// `-ci-run` invocation is launched by a shell hook script that git
// itself spawns, and environment variables are what naturally
// survives that hop without the hook script needing to know gogit's
// own flag names.
type Config struct {
	// ActPath, if set, is used as-is - no embedded-binary lookup, no
	// PATH search. This is the explicit opt-out: set GOGIT_ACT_PATH
	// to point at a manually installed act, e.g. on windows/arm where
	// there's no embedded binary to fall back to (see
	// internal/actbin's doc comment).
	ActPath string
	// BinarysDir is where the embedded act binary gets extracted to
	// on first use. Defaults to a "Binarys" folder next to the
	// currently running gogit executable - resolved fresh on every
	// run (see resolveActPath) rather than baked in, so it still
	// finds the right place if the binary itself gets moved later.
	BinarysDir string
	// ContainerHost, if set, is passed to `act` as DOCKER_HOST -
	// point this at a Podman socket
	// (e.g. unix:///run/podman/podman.sock, or
	// unix://$XDG_RUNTIME_DIR/podman/podman.sock for rootless) to run
	// workflows under Podman instead of Docker. If empty, `act` uses
	// its own normal detection and whatever DOCKER_HOST is already
	// set to in the environment.
	ContainerHost string
}

// ConfigFromEnv reads GOGIT_ACT_PATH, GOGIT_BINARYS_DIR, and
// GOGIT_CONTAINER_HOST from the environment. See Config's doc comment
// for why env vars rather than flags.
func ConfigFromEnv() Config {
	return Config{
		ActPath:       strings.TrimSpace(os.Getenv("GOGIT_ACT_PATH")),
		BinarysDir:    strings.TrimSpace(os.Getenv("GOGIT_BINARYS_DIR")),
		ContainerHost: strings.TrimSpace(os.Getenv("GOGIT_CONTAINER_HOST")),
	}
}

// resolveActPath decides which act binary a run should actually use,
// logging its choice since this runs once per CI run and the reason
// something is (or isn't) using the embedded copy is exactly the kind
// of thing worth having in the run's own log, not just guessed at
// after the fact. Order: explicit override, then the embedded binary
// extracted to BinarysDir, then a bare PATH lookup as a last resort
// (e.g. on windows/arm, which has no embedded binary at all).
func resolveActPath(cfg Config, logw io.Writer) string {
	if cfg.ActPath != "" {
		fmt.Fprintf(logw, "gogit: using GOGIT_ACT_PATH override: %s\n", cfg.ActPath)
		return cfg.ActPath
	}

	dir := cfg.BinarysDir
	if dir == "" {
		if exe, err := os.Executable(); err == nil {
			if resolved, err := filepath.EvalSymlinks(exe); err == nil {
				exe = resolved
			}
			dir = filepath.Join(filepath.Dir(exe), "Binarys")
		}
	}

	if dir != "" && actbin.Available() {
		if path, err := actbin.EnsureExtracted(dir); err == nil {
			fmt.Fprintf(logw, "gogit: using embedded act, extracted to %s\n", path)
			return path
		} else {
			fmt.Fprintf(logw, "gogit: couldn't extract embedded act to %s (%v), falling back to PATH\n", dir, err)
		}
	} else if !actbin.Available() {
		fmt.Fprintln(logw, "gogit: no embedded act binary for this platform, falling back to PATH")
	}

	return "act"
}

// Status is a run's lifecycle state.
type Status string

const (
	StatusRunning Status = "running"
	StatusSuccess Status = "success"
	StatusFailed  Status = "failed" // workflow ran, act exited non-zero
	StatusError   Status = "error"  // gogit couldn't even start the run
	StatusSkipped Status = "skipped" // no .github/workflows in the pushed tree
)

// Run is one execution's full record, as persisted to status.json.
type Run struct {
	ID         string    `json:"id"`
	Repo       string    `json:"repo"` // repo dir name, e.g. "myproject.git"
	Ref        string    `json:"ref"`
	SHA        string    `json:"sha"`
	ShortSHA   string    `json:"short_sha"`
	Status     Status    `json:"status"`
	StartedAt  time.Time `json:"started_at"`
	FinishedAt time.Time `json:"finished_at,omitempty"`
	ExitCode   int       `json:"exit_code"`
	Detail     string    `json:"detail,omitempty"` // human-readable note, e.g. why skipped/errored
}

func ciDir(repoPath string) string       { return filepath.Join(repoPath, "gogit-ci") }
func runsDir(repoPath string) string     { return filepath.Join(ciDir(repoPath), "runs") }
func runDir(repoPath, id string) string  { return filepath.Join(runsDir(repoPath), id) }
func statusPath(repoPath, id string) string { return filepath.Join(runDir(repoPath, id), "status.json") }
func logPath(repoPath, id string) string    { return filepath.Join(runDir(repoPath, id), "output.log") }
func indexPath(repoPath string) string      { return filepath.Join(ciDir(repoPath), "index.json") }

// maxIndexEntries bounds how many run IDs the index file (and
// therefore the "list runs" page) keeps track of. Older run
// directories on disk aren't deleted - only pruned from the fast
// index - so nothing is lost, it just stops being one click away.
const maxIndexEntries = 200

// newRunID produces a sortable, human-readable run identifier:
// timestamp first (so lexical sort == chronological sort) with the
// short SHA appended for easy visual matching to `git log`.
func newRunID(sha string) string {
	short := sha
	if len(short) > 8 {
		short = short[:8]
	}
	return time.Now().UTC().Format("20060102-150405") + "-" + short
}

// RunWorkflow is the entire CI run, start to finish: archive the
// pushed commit out to a temp checkout, look for
// .github/workflows/*.yml, hand off to `act`, and persist the
// result. It never returns an error for a workflow that ran and
// failed - that's a normal Run with Status == StatusFailed. An
// error return means gogit itself couldn't complete the bookkeeping
// (e.g. couldn't write to disk).
func RunWorkflow(cfg Config, repoPath, ref, sha string) (*Run, error) {
	id := newRunID(sha)
	short := sha
	if len(short) > 8 {
		short = short[:8]
	}

	run := &Run{
		ID:        id,
		Repo:      filepath.Base(repoPath),
		Ref:       ref,
		SHA:       sha,
		ShortSHA:  short,
		Status:    StatusRunning,
		StartedAt: time.Now().UTC(),
	}

	if err := os.MkdirAll(runDir(repoPath, id), 0755); err != nil {
		return nil, fmt.Errorf("creating run dir: %w", err)
	}
	if err := writeStatus(repoPath, run); err != nil {
		return nil, err
	}
	if err := appendIndex(repoPath, run); err != nil {
		return nil, err
	}

	logFile, err := os.Create(logPath(repoPath, id))
	if err != nil {
		return nil, fmt.Errorf("creating run log: %w", err)
	}
	defer logFile.Close()

	finish := func(status Status, exitCode int, detail string) (*Run, error) {
		run.Status = status
		run.ExitCode = exitCode
		run.Detail = detail
		run.FinishedAt = time.Now().UTC()
		if err := writeStatus(repoPath, run); err != nil {
			return run, err
		}
		return run, updateIndex(repoPath, run)
	}

	workDir, err := os.MkdirTemp("", "gogit-ci-")
	if err != nil {
		fmt.Fprintf(logFile, "gogit: failed to create temp checkout dir: %v\n", err)
		return finish(StatusError, -1, "failed to create temp checkout dir")
	}
	defer os.RemoveAll(workDir)

	if err := archiveCheckout(repoPath, sha, workDir); err != nil {
		fmt.Fprintf(logFile, "gogit: failed to check out %s: %v\n", short, err)
		return finish(StatusError, -1, "checkout failed")
	}

	if !hasWorkflows(workDir) {
		fmt.Fprintln(logFile, "gogit: no .github/workflows/*.yml in this commit - nothing to run")
		return finish(StatusSkipped, 0, "no .github/workflows in pushed tree")
	}

	actPath := resolveActPath(cfg, logFile)

	// "push" because this only ever runs from the post-receive hook,
	// i.e. always in response to a push. If gogit grows other
	// triggers (manual re-run, scheduled) later, the event name
	// becomes a parameter here instead of a constant.
	// act's own first run prompts interactively for a default image
	// size if it has no .actrc and hasn't been asked before - fine at
	// a terminal, but this always runs from a git hook with no TTY
	// attached, where that prompt just hangs waiting for input that
	// can never arrive. Pre-supplying -P mappings for the common
	// runs-on values (the same images "Medium" would have picked)
	// skips the prompt entirely rather than working around it.
	cmd := exec.Command(actPath,
		"push", "--rm",
		"-P", "ubuntu-latest=ghcr.io/catthehacker/ubuntu:act-latest",
		"-P", "ubuntu-24.04=ghcr.io/catthehacker/ubuntu:act-24.04",
		"-P", "ubuntu-22.04=ghcr.io/catthehacker/ubuntu:act-22.04",
		"-P", "ubuntu-20.04=ghcr.io/catthehacker/ubuntu:act-20.04",
	)
	cmd.Dir = workDir
	cmd.Stdout = logFile
	cmd.Stderr = logFile
	cmd.Env = os.Environ()
	if cfg.ContainerHost != "" {
		cmd.Env = append(cmd.Env, "DOCKER_HOST="+cfg.ContainerHost)
	}

	fmt.Fprintf(logFile, "gogit: running `%s push` for %s (%s) via %s\n", actPath, ref, short, containerHostLabel(cfg))
	fmt.Fprintln(logFile, strings.Repeat("-", 60))

	runErr := cmd.Run()
	if runErr == nil {
		return finish(StatusSuccess, 0, "")
	}

	if exitErr, ok := runErr.(*exec.ExitError); ok {
		return finish(StatusFailed, exitErr.ExitCode(), "")
	}

	// act itself couldn't be started at all - most likely missing
	// from PATH, which is a setup problem, not a workflow failure.
	fmt.Fprintf(logFile, "\ngogit: failed to start `%s`: %v\n", actPath, runErr)
	return finish(StatusError, -1, fmt.Sprintf("failed to start %s: %v", actPath, runErr))
}

func containerHostLabel(cfg Config) string {
	if cfg.ContainerHost != "" {
		return cfg.ContainerHost
	}
	return "act's default container engine detection"
}

// archiveCheckout materializes the given commit into destDir using
// `git archive | tar -x`, the same shelling-out-to-real-tools
// approach the rest of gogit uses. This deliberately avoids
// `git clone` + `git checkout`: destDir ends up with just the files
// as they existed at sha, no .git directory, which is all `act`
// needs to find and run workflow files.
func archiveCheckout(repoPath, sha, destDir string) error {
	archiveCmd := exec.Command("git", "--git-dir="+repoPath, "archive", sha)
	tarCmd := exec.Command("tar", "-x", "-C", destDir)

	pipe, err := archiveCmd.StdoutPipe()
	if err != nil {
		return err
	}
	tarCmd.Stdin = pipe

	var stderr bytes.Buffer
	archiveCmd.Stderr = &stderr
	tarCmd.Stderr = &stderr

	if err := tarCmd.Start(); err != nil {
		return fmt.Errorf("starting tar: %w", err)
	}
	if err := archiveCmd.Run(); err != nil {
		return fmt.Errorf("git archive: %w: %s", err, stderr.String())
	}
	if err := tarCmd.Wait(); err != nil {
		return fmt.Errorf("tar extract: %w: %s", err, stderr.String())
	}
	return nil
}

func hasWorkflows(workDir string) bool {
	matches, err := filepath.Glob(filepath.Join(workDir, ".github", "workflows", "*.yml"))
	if err == nil && len(matches) > 0 {
		return true
	}
	matches, err = filepath.Glob(filepath.Join(workDir, ".github", "workflows", "*.yaml"))
	return err == nil && len(matches) > 0
}

func writeStatus(repoPath string, run *Run) error {
	data, err := json.MarshalIndent(run, "", "  ")
	if err != nil {
		return fmt.Errorf("encoding run status: %w", err)
	}
	if err := os.MkdirAll(runDir(repoPath, run.ID), 0755); err != nil {
		return err
	}
	return os.WriteFile(statusPath(repoPath, run.ID), data, 0644)
}

// indexEntry is the trimmed-down record kept in index.json - just
// enough for the list view, so listing runs never has to open every
// run's status.json.
type indexEntry struct {
	ID         string    `json:"id"`
	Ref        string    `json:"ref"`
	ShortSHA   string    `json:"short_sha"`
	Status     Status    `json:"status"`
	StartedAt  time.Time `json:"started_at"`
	FinishedAt time.Time `json:"finished_at,omitempty"`
}

func loadIndex(repoPath string) ([]indexEntry, error) {
	data, err := os.ReadFile(indexPath(repoPath))
	if err != nil {
		if os.IsNotExist(err) {
			return nil, nil
		}
		return nil, err
	}
	var entries []indexEntry
	if err := json.Unmarshal(data, &entries); err != nil {
		// A corrupt index shouldn't take down the whole page - start
		// fresh rather than erroring, same spirit as loadAuthStore
		// denying-safe on a bad user file.
		return nil, nil
	}
	return entries, nil
}

func saveIndex(repoPath string, entries []indexEntry) error {
	sort.Slice(entries, func(i, j int) bool { return entries[i].ID > entries[j].ID })
	if len(entries) > maxIndexEntries {
		entries = entries[:maxIndexEntries]
	}
	if err := os.MkdirAll(ciDir(repoPath), 0755); err != nil {
		return err
	}
	data, err := json.MarshalIndent(entries, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(indexPath(repoPath), data, 0644)
}

func appendIndex(repoPath string, run *Run) error {
	entries, err := loadIndex(repoPath)
	if err != nil {
		return err
	}
	entries = append(entries, indexEntry{
		ID:        run.ID,
		Ref:       run.Ref,
		ShortSHA:  run.ShortSHA,
		Status:    run.Status,
		StartedAt: run.StartedAt,
	})
	return saveIndex(repoPath, entries)
}

func updateIndex(repoPath string, run *Run) error {
	entries, err := loadIndex(repoPath)
	if err != nil {
		return err
	}
	for i := range entries {
		if entries[i].ID == run.ID {
			entries[i].Status = run.Status
			entries[i].FinishedAt = run.FinishedAt
			break
		}
	}
	return saveIndex(repoPath, entries)
}

// ListRuns returns run summaries newest-first, for the /{repo}/actions
// list page.
func ListRuns(repoPath string) ([]Run, error) {
	entries, err := loadIndex(repoPath)
	if err != nil {
		return nil, err
	}
	runs := make([]Run, 0, len(entries))
	for _, e := range entries {
		runs = append(runs, Run{
			ID:         e.ID,
			Ref:        e.Ref,
			ShortSHA:   e.ShortSHA,
			Status:     e.Status,
			StartedAt:  e.StartedAt,
			FinishedAt: e.FinishedAt,
		})
	}
	return runs, nil
}

// maxLogBytes caps how much of a run's log gogit will read back for
// the web UI - large enough for any reasonable CI job, small enough
// that a runaway workflow can't make the log page itself unusable.
const maxLogBytes = 2 * 1024 * 1024 // 2 MiB

// GetRun loads one run's full status plus its log output (tail-
// truncated to maxLogBytes) for the /{repo}/actions/{id} detail page.
func GetRun(repoPath, id string) (*Run, string, error) {
	// id comes straight from a URL path segment; guard against path
	// traversal the same way resolveRepoPath guards repo names,
	// rather than trusting it's one of our own generated IDs.
	if id == "" || id != filepath.Base(id) || strings.Contains(id, "..") {
		return nil, "", fmt.Errorf("invalid run id")
	}

	data, err := os.ReadFile(statusPath(repoPath, id))
	if err != nil {
		return nil, "", err
	}
	var run Run
	if err := json.Unmarshal(data, &run); err != nil {
		return nil, "", fmt.Errorf("corrupt run status: %w", err)
	}

	logData, err := readTail(logPath(repoPath, id), maxLogBytes)
	if err != nil && !os.IsNotExist(err) {
		return &run, "", err
	}
	return &run, logData, nil
}

func readTail(path string, max int64) (string, error) {
	f, err := os.Open(path)
	if err != nil {
		return "", err
	}
	defer f.Close()

	info, err := f.Stat()
	if err != nil {
		return "", err
	}

	var prefix string
	if info.Size() > max {
		if _, err := f.Seek(-max, io.SeekEnd); err != nil {
			return "", err
		}
		prefix = fmt.Sprintf("... (log truncated, showing last %d bytes) ...\n\n", max)
	}

	data, err := io.ReadAll(f)
	if err != nil {
		return "", err
	}
	return prefix + string(data), nil
}
