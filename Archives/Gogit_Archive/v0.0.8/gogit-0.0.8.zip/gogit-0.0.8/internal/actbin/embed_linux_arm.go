//go:build linux && arm

// Embeds act's armv7 build. act also publishes an armv6 build for
// older/lower-power boards (e.g. Raspberry Pi Zero/1); gogit's own
// CI matrix only has one generic "linux/arm" target (GOARCH=arm, no
// GOARM pin), so armv7 was picked as the more common baseline for
// current 32-bit ARM Linux boards. GOGIT_ACT_PATH overrides this if
// a target device specifically needs the armv6 build instead.

package actbin

import _ "embed"

//go:embed binaries/linux_arm/act
var binary []byte

const binaryName = "act"
