//go:build windows && 386

package actbin

import _ "embed"

//go:embed binaries/windows_386/act.exe
var binary []byte

const binaryName = "act.exe"
