//go:build linux && 386

package actbin

import _ "embed"

//go:embed binaries/linux_386/act
var binary []byte

const binaryName = "act"
