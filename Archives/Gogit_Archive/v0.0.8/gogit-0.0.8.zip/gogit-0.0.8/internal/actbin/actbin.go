// Package actbin embeds a real `act` binary
// (https://github.com/nektos/act, MIT licensed - see act-LICENSE in
// this directory) for each platform gogit itself cross-compiles to
// (see .github/workflows/go.yml), and extracts the one matching the
// currently-running gogit binary to disk on first use.
//
// This closes the one remaining "extra install step" for CI:
// internal/ci already shells out to `act` rather than importing it as
// a library (see that package's doc comment for why), but until now
// that meant `act` had to be installed separately, same as Docker or
// Podman. It's a genuinely different situation from the container
// engine, though: `act` is a single static-ish Go binary with its own
// per-platform GitHub releases, small enough to embed - Docker/Podman
// are full container runtimes that need real OS-level support
// (namespaces, cgroups, and on Windows/macOS an actual Linux VM) and
// can't be embedded into another program at all. See internal/ci's
// doc comment for that half of the picture; this package only ever
// covers the `act` binary itself, never the engine it talks to.
//
// Each binaries/<goos>_<goarch>/act[.exe] file is a real download
// from nektos/act's own v0.2.89 GitHub release, verified against that
// release's own published checksums.txt before being committed here
// - not built from source in this repo, same as gogit doesn't vendor
// git itself.
//
// Known gap: windows/arm (32-bit ARM) has no embedded binary, because
// act's own releases don't publish one for that target - there is
// nothing to embed, not a choice gogit made. GOGIT_ACT_PATH still
// works as a manual override on that one platform (or any platform,
// to opt back out of the embedded copy entirely).
package actbin

import (
	"bytes"
	"fmt"
	"io"
	"os"
	"path/filepath"
)

// Available reports whether this build of gogit has an embedded act
// binary for the platform it's currently running as. False only for
// windows/arm (see package doc).
func Available() bool {
	return len(binary) > 0
}

// EnsureExtracted writes the embedded act binary into destDir if it
// isn't already there (or is a different size, e.g. after a gogit
// upgrade embeds a newer act release), and returns the full path to
// it. Callers should check Available first for a clearer error than
// whatever this returns when there's simply nothing embedded.
func EnsureExtracted(destDir string) (string, error) {
	if !Available() {
		return "", fmt.Errorf("no embedded act binary for this platform - set GOGIT_ACT_PATH to a manually installed act instead")
	}

	if err := os.MkdirAll(destDir, 0755); err != nil {
		return "", fmt.Errorf("creating %s: %w", destDir, err)
	}

	dest := filepath.Join(destDir, binaryName)

	if info, err := os.Stat(dest); err == nil && info.Size() == int64(len(binary)) {
		// Already extracted, and the size matches what's embedded in
		// this binary - skip rewriting it every single CI run.
		return dest, nil
	}

	// Write to a temp file in the same directory and rename into
	// place, so a run that starts mid-extraction never sees a
	// truncated binary - same reasoning as gogit's own atomic
	// index.json writes in internal/ci.
	tmp, err := os.CreateTemp(destDir, ".act-*.tmp")
	if err != nil {
		return "", fmt.Errorf("creating temp file in %s: %w", destDir, err)
	}
	tmpPath := tmp.Name()
	defer os.Remove(tmpPath) // no-op once the rename below succeeds

	if _, err := io.Copy(tmp, bytes.NewReader(binary)); err != nil {
		tmp.Close()
		return "", fmt.Errorf("writing embedded act binary: %w", err)
	}
	if err := tmp.Close(); err != nil {
		return "", fmt.Errorf("closing extracted act binary: %w", err)
	}
	if err := os.Chmod(tmpPath, 0755); err != nil {
		return "", fmt.Errorf("marking extracted act binary executable: %w", err)
	}
	if err := os.Rename(tmpPath, dest); err != nil {
		return "", fmt.Errorf("installing extracted act binary: %w", err)
	}

	return dest, nil
}
