//go:build darwin && arm64

package actbin

import _ "embed"

//go:embed binaries/darwin_arm64/act
var binary []byte

const binaryName = "act"
