//go:build windows && amd64

package actbin

import _ "embed"

//go:embed binaries/windows_amd64/act.exe
var binary []byte

const binaryName = "act.exe"
