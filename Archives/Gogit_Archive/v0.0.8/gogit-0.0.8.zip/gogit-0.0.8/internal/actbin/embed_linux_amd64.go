//go:build linux && amd64

package actbin

import _ "embed"

//go:embed binaries/linux_amd64/act
var binary []byte

const binaryName = "act"
