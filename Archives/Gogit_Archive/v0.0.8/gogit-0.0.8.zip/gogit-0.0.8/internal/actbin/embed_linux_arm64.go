//go:build linux && arm64

package actbin

import _ "embed"

//go:embed binaries/linux_arm64/act
var binary []byte

const binaryName = "act"
