//go:build darwin && amd64

package actbin

import _ "embed"

//go:embed binaries/darwin_amd64/act
var binary []byte

const binaryName = "act"
