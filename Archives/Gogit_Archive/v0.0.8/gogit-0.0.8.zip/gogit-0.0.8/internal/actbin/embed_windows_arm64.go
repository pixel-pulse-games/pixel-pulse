//go:build windows && arm64

package actbin

import _ "embed"

//go:embed binaries/windows_arm64/act.exe
var binary []byte

const binaryName = "act.exe"
