//go:build windows && arm

// No embedded binary for this target: act's own releases don't
// publish a windows/arm build (verified against v0.2.89's own
// checksums.txt - there's no asset for it, not an oversight here).
// Available() returns false and EnsureExtracted errors accordingly;
// use GOGIT_ACT_PATH on this one platform.

package actbin

var binary []byte
const binaryName = ""
