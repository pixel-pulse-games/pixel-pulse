package server

import (
	"embed"
	"fmt"
	"html/template"
	"log"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strings"

	"gogit/internal/auth"
)

// Embed HTML template files from internal/server/templates
//go:embed templates/*.html
var TemplateFS embed.FS

// pathSegmentPattern guards individual path segments used in file browser URLs.
var pathSegmentPattern = regexp.MustCompile(`^[a-zA-Z0-9_.\-]+$`)

func validatePathSegment(segment string) bool {
	if segment == "" || segment == "." || segment == ".." {
		return false
	}
	if strings.HasPrefix(segment, "-") {
		return false
	}
	return pathSegmentPattern.MatchString(segment)
}

var tmpl = template.Must(template.ParseFS(TemplateFS, "templates/*.html"))

type repoInfo struct {
	Name    string
	Private bool
}

type repoListData struct {
	Authed   bool
	Username string
	Repos    []repoInfo
}

// handleRepoList serves GET / (the repository dashboard).
func (s *server) handleRepoList(w http.ResponseWriter, r *http.Request) {
	if r.URL.Path != "/" {
		http.NotFound(w, r)
		return
	}

	username, authed := s.getAuthUser(r)

	entries, err := os.ReadDir(s.reposRoot)
	var repos []repoInfo
	if err == nil {
		for _, entry := range entries {
			if !entry.IsDir() || !strings.HasSuffix(entry.Name(), ".git") {
				continue
			}
			name := strings.TrimSuffix(entry.Name(), ".git")
			repoPath := filepath.Join(s.reposRoot, entry.Name())
			private := isRepoPrivate(repoPath)

			if private && !authed {
				continue
			}

			repos = append(repos, repoInfo{
				Name:    name,
				Private: private,
			})
		}
	}

	data := repoListData{
		Authed:   authed,
		Username: username,
		Repos:    repos,
	}

	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	if err := tmpl.ExecuteTemplate(w, "repo_list.html", data); err != nil {
		log.Printf("rendering repo_list template: %v", err)
	}
}

type treeEntry struct {
	Mode string
	Type string // "blob" or "tree"
	Hash string
	Name string
}

type treePageData struct {
	Authed      bool
	Username    string
	RepoName    string
	Ref         string
	Subpath     string
	Breadcrumbs []breadcrumb
	Entries     []treeEntry
	IsBlob      bool
	BlobContent string
}

type breadcrumb struct {
	Name string
	Path string
}

func (s *server) handleTree(w http.ResponseWriter, r *http.Request) {
	s.handleTreeOrBlob(w, r, "tree")
}

func (s *server) handleBlob(w http.ResponseWriter, r *http.Request) {
	s.handleTreeOrBlob(w, r, "blob")
}

func (s *server) handleTreeOrBlob(w http.ResponseWriter, r *http.Request, defaultAction string) {
	parts := strings.Split(strings.Trim(r.URL.Path, "/"), "/")
	// Only repo + action ("tree"/"blob") are strictly required - the
	// ref segment is optional. Links like /{repo}/tree/ (no ref) are
	// exactly what the repo list and the tab bar generate, meaning
	// "show me the default branch" rather than a specific ref; this
	// used to 404 because a ref was treated as mandatory.
	if len(parts) < 2 {
		http.NotFound(w, r)
		return
	}

	repoName := parts[0]
	action := parts[1]
	if action != "tree" && action != "blob" {
		action = defaultAction
	}

	if !validatePathSegment(repoName) {
		http.Error(w, "invalid request", http.StatusBadRequest)
		return
	}

	repoPath := filepath.Join(s.reposRoot, repoName+".git")
	if _, err := os.Stat(repoPath); os.IsNotExist(err) {
		http.NotFound(w, r)
		return
	}
	if isRepoPrivate(repoPath) {
		if _, authed := s.getAuthUser(r); !authed {
			w.Header().Set("WWW-Authenticate", `Basic realm="gogit"`)
			http.Error(w, "Unauthorized", http.StatusUnauthorized)
			return
		}
	}

	var ref string
	var subpathParts []string
	if len(parts) >= 3 {
		ref = parts[2]
		if !validatePathSegment(ref) {
			http.Error(w, "invalid request", http.StatusBadRequest)
			return
		}
		subpathParts = parts[3:]
	} else {
		resolved, err := defaultBranch(repoPath)
		if err != nil {
			http.Error(w, "repository has no commits yet", http.StatusNotFound)
			return
		}
		ref = resolved
	}

	for _, seg := range subpathParts {
		if !validatePathSegment(seg) {
			http.Error(w, "invalid path segment", http.StatusBadRequest)
			return
		}
	}
	subpath := strings.Join(subpathParts, "/")

	username, authed := s.getAuthUser(r)

	var crumbs []breadcrumb
	accum := ""
	for _, seg := range subpathParts {
		if accum == "" {
			accum = seg
		} else {
			accum = accum + "/" + seg
		}
		crumbs = append(crumbs, breadcrumb{Name: seg, Path: accum})
	}

	data := treePageData{
		Authed:      authed,
		Username:    username,
		RepoName:    repoName,
		Ref:         ref,
		Subpath:     subpath,
		Breadcrumbs: crumbs,
	}

	if action == "blob" {
		data.IsBlob = true
		content, err := gitShowBlob(repoPath, ref, subpath)
		if err != nil {
			http.Error(w, "file not found or binary file", http.StatusNotFound)
			return
		}
		data.BlobContent = content
	} else {
		entries, err := gitLsTree(repoPath, ref, subpath)
		if err != nil {
			http.Error(w, "tree not found", http.StatusNotFound)
			return
		}
		data.Entries = entries
	}

	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	if err := tmpl.ExecuteTemplate(w, "tree.html", data); err != nil {
		log.Printf("rendering tree template: %v", err)
	}
}

// defaultBranch resolves which branch /{repo}/tree/ (no explicit ref)
// should show - the repo's actual HEAD, same as what `git clone`
// would check out, rather than a hardcoded guess like "main" or
// "master" (this project's own repos were created under "master" by
// older git defaults, so hardcoding "main" would 404 on those).
func defaultBranch(repoPath string) (string, error) {
	cmd := exec.Command("git", "--git-dir="+repoPath, "symbolic-ref", "--short", "HEAD")
	out, err := cmd.Output()
	if err != nil {
		return "", fmt.Errorf("resolving default branch: %w", err)
	}
	branch := strings.TrimSpace(string(out))
	if branch == "" {
		return "", fmt.Errorf("empty HEAD")
	}
	return branch, nil
}

func gitLsTree(repoPath, ref, subpath string) ([]treeEntry, error) {
	target := ref
	if subpath != "" {
		target = ref + ":" + subpath
	}

	cmd := exec.Command("git", "--git-dir="+repoPath, "ls-tree", target)
	out, err := cmd.Output()
	if err != nil {
		return nil, err
	}

	var entries []treeEntry
	lines := strings.Split(string(out), "\n")
	for _, line := range lines {
		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}
		tabParts := strings.SplitN(line, "\t", 2)
		if len(tabParts) < 2 {
			continue
		}
		metaParts := strings.Fields(tabParts[0])
		if len(metaParts) < 3 {
			continue
		}
		entries = append(entries, treeEntry{
			Mode: metaParts[0],
			Type: metaParts[1],
			Hash: metaParts[2],
			Name: tabParts[1],
		})
	}
	return entries, nil
}

func gitShowBlob(repoPath, ref, subpath string) (string, error) {
	target := ref + ":" + subpath
	cmd := exec.Command("git", "--git-dir="+repoPath, "show", target)
	out, err := cmd.Output()
	if err != nil {
		return "", err
	}
	return string(out), nil
}

type commitLogEntry struct {
	Hash    string
	Author  string
	Date    string
	Message string
}

type commitsPageData struct {
	Authed   bool
	Username string
	RepoName string
	Commits  []commitLogEntry
}

func (s *server) handleCommits(w http.ResponseWriter, r *http.Request) {
	parts := strings.Split(strings.Trim(r.URL.Path, "/"), "/")
	if len(parts) < 2 || parts[1] != "commits" {
		http.NotFound(w, r)
		return
	}

	repoName := parts[0]
	if !validatePathSegment(repoName) {
		http.Error(w, "invalid repo name", http.StatusBadRequest)
		return
	}

	repoPath := filepath.Join(s.reposRoot, repoName+".git")
	if isRepoPrivate(repoPath) {
		if _, authed := s.getAuthUser(r); !authed {
			w.Header().Set("WWW-Authenticate", `Basic realm="gogit"`)
			http.Error(w, "Unauthorized", http.StatusUnauthorized)
			return
		}
	}

	if _, err := os.Stat(repoPath); os.IsNotExist(err) {
		http.NotFound(w, r)
		return
	}

	username, authed := s.getAuthUser(r)

	commits, err := gitLog(repoPath)
	if err != nil {
		commits = []commitLogEntry{}
	}

	data := commitsPageData{
		Authed:   authed,
		Username: username,
		RepoName: repoName,
		Commits:  commits,
	}

	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	if err := tmpl.ExecuteTemplate(w, "commits.html", data); err != nil {
		log.Printf("rendering commits template: %v", err)
	}
}

func gitLog(repoPath string) ([]commitLogEntry, error) {
	format := "%H\x1f%an\x1f%ad\x1f%s"
	cmd := exec.Command("git", "--git-dir="+repoPath, "log", "--pretty=format:"+format, "--date=short")
	out, err := cmd.Output()
	if err != nil {
		return nil, err
	}

	var entries []commitLogEntry
	lines := strings.Split(string(out), "\n")
	for _, line := range lines {
		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}
		fields := strings.Split(line, "\x1f")
		if len(fields) < 4 {
			continue
		}
		entries = append(entries, commitLogEntry{
			Hash:    fields[0],
			Author:  fields[1],
			Date:    fields[2],
			Message: fields[3],
		})
	}
	return entries, nil
}

type newUserFormData struct {
	Authed   bool
	Username string
	Error    string
	Success  string
}

// handleNewUserForm handles GET /admin/users/new.
func (s *server) handleNewUserForm(w http.ResponseWriter, r *http.Request) {
	if !s.requireAuth(w, r) {
		return
	}
	username, _ := s.getAuthUser(r)
	data := newUserFormData{
		Authed:   true,
		Username: username,
	}

	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	if err := tmpl.ExecuteTemplate(w, "new_user.html", data); err != nil {
		log.Printf("rendering new user form: %v", err)
	}
}

// handleCreateUser handles POST /admin/users/new.
func (s *server) handleCreateUser(w http.ResponseWriter, r *http.Request) {
	if !s.requireAuth(w, r) {
		return
	}

	if err := r.ParseForm(); err != nil {
		http.Error(w, "malformed form", http.StatusBadRequest)
		return
	}
	username := strings.TrimSpace(r.FormValue("username"))
	password := r.FormValue("password")

	data := newUserFormData{}
	if username == "" || password == "" {
		data.Error = "username and password are both required"
	} else if err := auth.AddUser(s.userFile, username, password); err != nil {
		log.Printf("creating user %q: %v", username, err)
		data.Error = "failed to create user"
	} else {
		// No manual reload needed - loadAuthStore() always reads
		// fresh from disk, so this new user is usable immediately.
		data.Success = username
	}

	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	if err := tmpl.ExecuteTemplate(w, "new_user.html", data); err != nil {
		log.Printf("rendering new user form: %v", err)
	}
}