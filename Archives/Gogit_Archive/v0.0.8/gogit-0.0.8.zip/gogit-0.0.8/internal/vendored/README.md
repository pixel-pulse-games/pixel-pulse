# internal/vendored

This directory contains `bcrypt` and its `blowfish` dependency,
copied directly from the Go project's `golang.org/x/crypto` repo
(https://github.com/golang/crypto), unmodified except for one import
path change (`blowfish` is imported from this vendored location
instead of `golang.org/x/crypto/blowfish`).

## Why vendored by hand instead of a normal `go get` dependency

Earlier development of this project happened in an environment that
could reach GitHub but not Go's module proxy
(`proxy.golang.org`), so `go get golang.org/x/crypto/bcrypt` wasn't
possible there. This directory is the workaround: the same real,
unmodified upstream source, just fetched via `git clone` from GitHub
and checked into this repo directly instead of pulled in as a module
dependency.

**If you have normal network access** (most environments do), the
better long-term fix is to remove this directory and add a real
module dependency instead:

```
go get golang.org/x/crypto/bcrypt
```

then change the import in `internal/auth/auth.go` from
`"gogit/internal/vendored/bcrypt"` back to
`"golang.org/x/crypto/bcrypt"`, and delete this `internal/vendored/`
directory. That gets you normal `go.sum` verification and version
tracking instead of a hand-copied snapshot.

## License

Upstream `golang.org/x/crypto` is BSD-3-Clause licensed. See `LICENSE`
in this directory for the full license text, copied from upstream.
