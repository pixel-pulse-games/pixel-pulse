<!-- 
  Thank you for contributing to gogit! 
  Please fill out this form completely. Pull Requests that are incomplete or 
  fail automated tests will be closed automatically.
-->
## 📋 Description
Provide a clear, brief summary of the changes you are proposing. What bug does this fix or what feature does this add?

## 🛠 Type of Change (Check all that apply)
- [ ] 🐛 Bug fix (non-breaking change which fixes an issue)
- [ ] ✨ New feature (non-breaking change which adds functionality)
- [ ] ⚡ Performance optimization / Go source cleanup
- [ ] 🤖 CI/CD Workflows

## 🔬 Testing Status
You must test your changes locally before submitting this request.
- [ ] I have built this code locally using `go build ./...` and it succeeded.
- [ ] I have verified the Windows binary compiles without errors (`GOOS=windows GOARCH=amd64 go build -o gogit.exe ./cmd/gogit`).
- [ ] I have run `go test ./...` and all tests pass.
- [ ] I have verified against a real `git` client where this PR touches server behavior (see PR description for the exact command(s) and expected result).

## 🚨 Security & Guardrail Checklist
- [ ] My code does not contain hardcoded API keys, passwords, or tokens.
- [ ] I have not modified `.github/workflows/go.yml` or the release/versioning process unless explicitly authorized.
- [ ] I understand this PR requires absolute review and sign-off from @m97493578-ops before it can merge.