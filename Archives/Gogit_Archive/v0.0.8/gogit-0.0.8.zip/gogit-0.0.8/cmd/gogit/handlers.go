package main

import (
	"html/template"
	"net/http"
	"os"
	"path/filepath"
	"strings"

	"gogit/internal/auth"
	"gogit/internal/server"
)

// Home / Repo List Handler
func handleHome(reposDir string) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/" {
			http.NotFound(w, r)
			return
		}

		username, authed := getAuthUser(r)

		var repos []RepoInfo
		entries, err := os.ReadDir(reposDir)
		if err == nil {
			for _, entry := range entries {
				// Must be a directory AND end in .git - previously
				// this was "IsDir() || HasSuffix(...)" (an OR),
				// which meant any directory at all showed up as a
				// "repo", .git or not.
				if !entry.IsDir() || !strings.HasSuffix(entry.Name(), ".git") {
					continue
				}
				name := strings.TrimSuffix(entry.Name(), ".git")

				// Real check: git config gogit.private inside the
				// bare repo itself (internal/server.IsRepoPrivate).
				// Previously this was
				// strings.Contains(name, "secret") ||
				// strings.HasPrefix(name, "private_") - a naming
				// convention, not access control, and trivially
				// defeated by naming a repo anything else.
				isPrivate := server.IsRepoPrivate(filepath.Join(reposDir, entry.Name()))

				if isPrivate && !authed {
					continue
				}

				repos = append(repos, RepoInfo{
					Name:    name,
					Private: isPrivate,
				})
			}
		}

		tmpl, err := template.ParseFS(server.TemplateFS, "templates/repo_list.html")
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}

		tmpl.Execute(w, PageData{
			Authed:   authed,
			Username: username,
			Repos:    repos,
		})
	}
}

// User Registration Handler.
//
// Open public signup - anyone reaching this server can create an
// account. gogit still has no per-repo permissions (any registered
// user can push to any repo), so this means anyone who can reach the
// server can register and immediately push to every repo on it,
// "private" or not. Kept this way on request; the risk was flagged
// before making this change.
func handleRegister(w http.ResponseWriter, r *http.Request) {
	_, authed := getAuthUser(r)

	data := PageData{Authed: authed}

	if r.Method == http.MethodPost {
		username := strings.TrimSpace(r.FormValue("username"))
		password := strings.TrimSpace(r.FormValue("password"))

		if username == "" || password == "" {
			data.Error = "Username and password are required."
		} else if err := auth.AddUser(userFilePath, username, password); err != nil {
			data.Error = "Username is already taken."
		} else {
			reloadAuthStore()
			createSession(w, r, username)
			http.Redirect(w, r, "/", http.StatusSeeOther)
			return
		}
	}

	tmpl, err := template.ParseFS(server.TemplateFS, "templates/register.html")
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	tmpl.Execute(w, data)
}

// Login Handler
func handleLogin(w http.ResponseWriter, r *http.Request) {
	data := PageData{}

	if r.Method == http.MethodPost {
		username := strings.TrimSpace(r.FormValue("username"))
		password := strings.TrimSpace(r.FormValue("password"))

		if authStore.Verify(username, password) {
			createSession(w, r, username)
			http.Redirect(w, r, "/", http.StatusSeeOther)
			return
		}
		data.Error = "Invalid username or password."
	}

	tmpl, err := template.ParseFS(server.TemplateFS, "templates/login.html")
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	tmpl.Execute(w, data)
}

// Admin Add User Handler - functionally the same as /register now
// that /register is also gated behind login; kept as a separate
// route since existing links/bookmarks may point at it.
func handleAdminNewUser(w http.ResponseWriter, r *http.Request) {
	username, authed := getAuthUser(r)
	if !authed {
		http.Redirect(w, r, "/login", http.StatusSeeOther)
		return
	}

	data := PageData{
		Authed:   true,
		Username: username,
	}

	if r.Method == http.MethodPost {
		newUser := strings.TrimSpace(r.FormValue("username"))
		newPass := strings.TrimSpace(r.FormValue("password"))

		if newUser == "" || newPass == "" {
			data.Error = "Username and password are required."
		} else if err := auth.AddUser(userFilePath, newUser, newPass); err != nil {
			data.Error = "User already exists."
		} else {
			reloadAuthStore()
			data.Success = newUser
		}
	}

	tmpl, err := template.ParseFS(server.TemplateFS, "templates/new_user.html")
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	tmpl.Execute(w, data)
}

// Logout Handler
func handleLogout(w http.ResponseWriter, r *http.Request) {
	cookie, err := r.Cookie("gogit_session")
	if err == nil {
		sessionStore.mu.Lock()
		delete(sessionStore.sessions, cookie.Value)
		sessionStore.mu.Unlock()
	}

	isSecure := r.TLS != nil || r.Header.Get("X-Forwarded-Proto") == "https"

	http.SetCookie(w, &http.Cookie{
		Name:     "gogit_session",
		Value:    "",
		Path:     "/",
		MaxAge:   -1,
		HttpOnly: true,
		Secure:   isSecure,
		SameSite: http.SameSiteLaxMode,
	})

	http.Redirect(w, r, "/", http.StatusSeeOther)
}

// reloadAuthStore re-reads the user file so a just-added user is
// usable immediately without restarting the server.
func reloadAuthStore() {
	if store, err := auth.LoadStore(userFilePath); err == nil {
		authStore = store
	}
}