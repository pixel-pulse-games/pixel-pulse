package main

import (
	"fmt"
	"log"
	"os"
	"os/exec"
	"path/filepath"
	"strings"

	"gogit/internal/ci"
)

// runInitRepo creates a new bare repo under reposRoot and exits.
// owner may be empty, meaning the repo starts unowned - any user
// with valid credentials can push to it (the same behavior every
// repo had before per-repo permissions existed). Setting an owner at
// creation is the normal way a new repo gets real push restrictions.
func runInitRepo(reposRoot, name string, private bool, owner string) {
	if !strings.HasSuffix(name, ".git") {
		name += ".git"
	}
	path := filepath.Join(reposRoot, name)

	if _, err := os.Stat(path); err == nil {
		log.Fatalf("repo already exists: %s", path)
	}

	cmd := exec.Command("git", "init", "--bare", path)
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	if err := cmd.Run(); err != nil {
		log.Fatalf("failed to create repo: %v", err)
	}

	if private {
		cfgCmd := exec.Command("git", "--git-dir="+path, "config", "gogit.private", "true")
		if err := cfgCmd.Run(); err != nil {
			log.Fatalf("repo created, but failed to mark it private: %v", err)
		}
	}

	if owner != "" {
		cfgCmd := exec.Command("git", "--git-dir="+path, "config", "gogit.owner", owner)
		if err := cfgCmd.Run(); err != nil {
			log.Fatalf("repo created, but failed to set owner: %v", err)
		}
	}

	visibility := "public"
	if private {
		visibility = "private"
	}
	ownerMsg := "unowned - anyone with valid credentials can push"
	if owner != "" {
		ownerMsg = "owned by " + owner
	}
	fmt.Printf("Created %s bare repo at %s (%s)\n", visibility, path, ownerMsg)

	// CI is on by default for every repo: install the post-receive
	// hook now, same as any other property a freshly-created repo
	// starts with (private, owner). If this fails, the repo still
	// exists and works for plain git/web use - CI just doesn't fire
	// until -install-ci-hook is run for it later - so this doesn't
	// call log.Fatalf.
	if err := installCIHook(path); err != nil {
		log.Printf("repo created, but failed to install CI hook: %v", err)
		log.Printf("push/pull still work; re-run with -install-ci-hook -repos %s -repo-name %s to enable CI", reposRoot, strings.TrimSuffix(name, ".git"))
	} else {
		fmt.Println("CI enabled: pushes will run .github/workflows/*.yml via act")
	}
}

// installCIHook resolves the currently-running gogit binary's own
// path and installs it into repoPath's post-receive hook - shared by
// both -init-repo (new repos, CI on by default) and -install-ci-hook
// (retrofitting a repo created before this feature, or one whose
// hook was deleted).
func installCIHook(repoPath string) error {
	bin, err := ci.ResolveGogitBin()
	if err != nil {
		return err
	}
	return ci.InstallHook(repoPath, bin)
}

// runInstallCIHook retrofits CI onto an existing repo.
func runInstallCIHook(reposRoot, repoName string) {
	if !strings.HasSuffix(repoName, ".git") {
		repoName += ".git"
	}
	path := filepath.Join(reposRoot, repoName)

	if _, err := os.Stat(path); err != nil {
		log.Fatalf("repo not found: %s", path)
	}
	if err := installCIHook(path); err != nil {
		log.Fatalf("failed to install CI hook: %v", err)
	}
	fmt.Printf("CI enabled on %s: pushes will run .github/workflows/*.yml via act\n", path)
}

// runAddCollaborator grants push access on an existing repo to an
// additional user, beyond its owner. No effect on unowned repos,
// since those already allow anyone with valid credentials to push -
// only meaningful once a repo actually has an owner restricting it.
func runAddCollaborator(reposRoot, repoName, username string) {
	if !strings.HasSuffix(repoName, ".git") {
		repoName += ".git"
	}
	path := filepath.Join(reposRoot, repoName)

	if _, err := os.Stat(path); err != nil {
		log.Fatalf("repo not found: %s", path)
	}

	cmd := exec.Command("git", "--git-dir="+path, "config", "--add", "gogit.collaborator", username)
	if err := cmd.Run(); err != nil {
		log.Fatalf("failed to add collaborator: %v", err)
	}
	fmt.Printf("%s can now push to %s\n", username, path)
}