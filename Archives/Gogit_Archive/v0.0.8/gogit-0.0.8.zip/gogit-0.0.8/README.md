# gogit

A custom Git server utility written in Go This software manages, routes, and processes version control data.

## Project Structure

* cmd/gogit/: Contains main.go, the entry point for running the server application.
* internal/: Contains private core packages and server routing logic.
* data/: Stores test repositories used during local development.

## The .disabled Folder Extension

The test folder is named testrepo.git.disabled to deliberately break its recognition as an active Git repository by the parent directory.

Why this is used:
* Prevents Submodule Tracking: Adding a raw .git folder structure inside another project forces Git to treat it as a broken submodule pointer.
* Bypasses Git Tracking: Appending .disabled stops Git from trying to process the inner objects, refs, and HEAD metadata files.
* Safe Local Testing: It allows the Go application to interact with a realistic repository directory mockup during development without corrupting the main repository setup.

## Getting Started

1. Initialize dependencies:
   go mod tidy

2. Build the application:
   go build -o gogit.exe ./cmd/gogit

3. Run the executable file to start the server locally.
