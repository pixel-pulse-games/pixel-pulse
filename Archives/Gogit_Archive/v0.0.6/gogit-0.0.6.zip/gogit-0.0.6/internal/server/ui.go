package server

// Milestone 7: repo list. Milestone 8: file browser (tree + blob
// view). Both read-only, both driven by shelling out to `git`
// (`ls-tree`, `show`) same as the protocol handlers - consistent with
// the project's Path A approach.

import (
	"embed"
	"html/template"
	"log"
	"net/http"
	"os"
	"os/exec"
	"regexp"
	"strings"
)

//go:embed static/*.css
var staticFS embed.FS

// pathSegmentPattern guards individual path segments used in file
// browser URLs. Not a filesystem path this time (these become
// arguments to `git ls-tree`/`git show`, not raw file paths), but
// still worth restricting: git object paths aren't filesystem paths,
// so a ".." component can't actually escape anything the way it could
// in milestone 5 - but a segment starting with "-" could be
// misinterpreted as a git command-line flag ("argument injection"),
// which is its own real category of bug. Rejecting anything that
// doesn't look like an ordinary path segment sidesteps that entirely.
var pathSegmentPattern = regexp.MustCompile(`^[A-Za-z0-9._ -]+$`)

func validateBrowsePath(path string) bool {
	if path == "" {
		return true // root
	}
	for _, seg := range strings.Split(path, "/") {
		if seg == "" || seg == "." || seg == ".." {
			return false
		}
		if strings.HasPrefix(seg, "-") {
			return false // could be read as a git flag
		}
		if !pathSegmentPattern.MatchString(seg) {
			return false
		}
	}
	return true
}

var repoListTmpl = template.Must(template.New("repos").Parse(`<!DOCTYPE html>
<html><head><title>gogit</title><link rel="stylesheet" href="/static/style.css"></head>
<body><div class="container">
<h1>gogit</h1>
<ul class="repo-list">
{{range .}}<li><a href="/{{.}}/tree/">{{.}}</a></li>{{else}}<li>No repos found.</li>{{end}}
</ul>
</div></body></html>`))

var treeTmpl = template.Must(template.New("tree").Parse(`<!DOCTYPE html>
<html><head><title>{{.Repo}} - gogit</title><link rel="stylesheet" href="/static/style.css"></head>
<body><div class="container">
<h1><a href="/">gogit</a> / {{.Repo}}</h1>
<div class="breadcrumb">/{{.Path}}</div>
<table class="file-tree">
{{if .Path}}<tr><td class="icon">..</td><td><a href="/{{.Repo}}/tree/{{.ParentPath}}">..</a></td></tr>{{end}}
{{range .Entries}}<tr><td class="icon">{{if eq .Type "tree"}}dir{{else}}file{{end}}</td><td><a href="/{{$.Repo}}/{{if eq .Type "tree"}}tree{{else}}blob{{end}}/{{.LinkPath}}">{{.Name}}</a></td></tr>{{end}}
</table>
</div></body></html>`))

var blobTmpl = template.Must(template.New("blob").Parse(`<!DOCTYPE html>
<html><head><title>{{.Path}} - {{.Repo}} - gogit</title><link rel="stylesheet" href="/static/style.css"></head>
<body><div class="container">
<h1><a href="/">gogit</a> / <a href="/{{.Repo}}/tree/">{{.Repo}}</a></h1>
<div class="breadcrumb">/{{.Path}}</div>
<pre class="file-content">{{.Content}}</pre>
</div></body></html>`))

// handleRepoList serves GET / - lists every bare repo (any directory
// ending in .git) found directly under reposRoot.
func (s *server) handleRepoList(w http.ResponseWriter, r *http.Request) {
	entries, err := os.ReadDir(s.reposRoot)
	if err != nil {
		log.Printf("reading reposRoot: %v", err)
		http.Error(w, "internal error", http.StatusInternalServerError)
		return
	}

	var repos []string
	for _, e := range entries {
		if e.IsDir() && strings.HasSuffix(e.Name(), ".git") {
			repos = append(repos, e.Name())
		}
	}

	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	if err := repoListTmpl.Execute(w, repos); err != nil {
		log.Printf("rendering repo list: %v", err)
	}
}

type treeEntry struct {
	Type     string // "tree" or "blob"
	Name     string
	LinkPath string
}

type treeViewData struct {
	Repo       string
	Path       string
	ParentPath string
	Entries    []treeEntry
}

// handleTree serves GET /{repo}/tree/{path...} - lists the contents
// of a directory at the given path (empty path = repo root) as of
// HEAD (the default branch). Shells out to `git ls-tree`.
func (s *server) handleTree(w http.ResponseWriter, r *http.Request) {
	repoPath, ok := s.resolveRepoPath(r.PathValue("repo"))
	if !ok {
		http.Error(w, "invalid repo name", http.StatusBadRequest)
		return
	}
	browsePath := strings.Trim(r.PathValue("path"), "/")
	if !validateBrowsePath(browsePath) {
		http.Error(w, "invalid path", http.StatusBadRequest)
		return
	}

	ref := "HEAD"
	if browsePath != "" {
		ref = "HEAD:" + browsePath
	}

	out, err := exec.Command("git", "--git-dir="+repoPath, "ls-tree", ref).Output()
	if err != nil {
		http.Error(w, "path not found", http.StatusNotFound)
		return
	}

	var entries []treeEntry
	for _, line := range strings.Split(strings.TrimRight(string(out), "\n"), "\n") {
		if line == "" {
			continue
		}
		// Format: "<mode> <type> <sha>\t<name>"
		tabIdx := strings.IndexByte(line, '\t')
		if tabIdx == -1 {
			continue
		}
		meta := strings.Fields(line[:tabIdx])
		name := line[tabIdx+1:]
		if len(meta) < 2 {
			continue
		}
		typ := meta[1] // "tree" or "blob"
		linkPath := name
		if browsePath != "" {
			linkPath = browsePath + "/" + name
		}
		entries = append(entries, treeEntry{Type: typ, Name: name, LinkPath: linkPath})
	}

	parent := ""
	if idx := strings.LastIndex(browsePath, "/"); idx != -1 {
		parent = browsePath[:idx]
	}

	data := treeViewData{
		Repo:       r.PathValue("repo"),
		Path:       browsePath,
		ParentPath: parent,
		Entries:    entries,
	}

	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	if err := treeTmpl.Execute(w, data); err != nil {
		log.Printf("rendering tree view: %v", err)
	}
}

type blobViewData struct {
	Repo    string
	Path    string
	Content string
}

// handleBlob serves GET /{repo}/blob/{path...} - shows a file's
// contents as of HEAD. Shells out to `git show`.
func (s *server) handleBlob(w http.ResponseWriter, r *http.Request) {
	repoPath, ok := s.resolveRepoPath(r.PathValue("repo"))
	if !ok {
		http.Error(w, "invalid repo name", http.StatusBadRequest)
		return
	}
	browsePath := strings.Trim(r.PathValue("path"), "/")
	if browsePath == "" || !validateBrowsePath(browsePath) {
		http.Error(w, "invalid path", http.StatusBadRequest)
		return
	}

	out, err := exec.Command("git", "--git-dir="+repoPath, "show", "HEAD:"+browsePath).Output()
	if err != nil {
		http.Error(w, "file not found", http.StatusNotFound)
		return
	}

	data := blobViewData{
		Repo:    r.PathValue("repo"),
		Path:    browsePath,
		Content: string(out),
	}

	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	if err := blobTmpl.Execute(w, data); err != nil {
		log.Printf("rendering blob view: %v", err)
	}
}

// handleStaticCSS serves the one embedded CSS file at an exact path
// (not a wildcard subtree) specifically to avoid ambiguity with the
// {repo} wildcard routes - see server.go's route registration for why
// a subtree route here caused a startup panic.
func handleStaticCSS(w http.ResponseWriter, r *http.Request) {
	data, err := staticFS.ReadFile("static/style.css")
	if err != nil {
		http.Error(w, "not found", http.StatusNotFound)
		return
	}
	w.Header().Set("Content-Type", "text/css; charset=utf-8")
	w.Write(data)
}