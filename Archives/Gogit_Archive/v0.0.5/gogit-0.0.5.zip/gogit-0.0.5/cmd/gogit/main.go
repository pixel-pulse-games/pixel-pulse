// Command gogit runs a minimal Git-over-HTTP server.
package main

import (
	"flag"
	"fmt"
	"log"
	"os"
	"os/exec"
	"path/filepath"
	"strings"

	"gogit/internal/auth"
	"gogit/internal/server"
)

func main() {
	PrintLogo()

	addr := flag.String("addr", ":8080", "address to listen on, e.g. :8080")
	reposRoot := flag.String("repos", "./data", "directory containing bare repos")
	userFile := flag.String("userfile", "./users.txt", "flat-file user store for push auth")

	// Minimal repo-creation command, per the project plan: "CLI
	// command is fine for now, no UI yet." A proper standalone CLI
	// (subcommands, gh-style) is a later idea, not this.
	initRepo := flag.String("init-repo", "", "create a new bare repo under -repos and exit, e.g. -init-repo myproject")

	// Minimal user-creation command for the flat-file auth store.
	createUser := flag.String("create-user", "", "username to add to -userfile and exit (use with -password)")
	password := flag.String("password", "", "password for -create-user")

	flag.Parse()

	if *initRepo != "" {
		runInitRepo(*reposRoot, *initRepo)
		return
	}

	if *createUser != "" {
		runCreateUser(*userFile, *createUser, *password)
		return
	}

	cfg := server.Config{
		Addr:      *addr,
		ReposRoot: *reposRoot,
		UserFile:  *userFile,
	}

	srv := server.New(cfg)

	log.Printf("gogit listening on %s (repos root: %s)", cfg.Addr, cfg.ReposRoot)
	if err := srv.ListenAndServe(); err != nil {
		log.Fatal(err)
	}
}

// runInitRepo creates a new bare repo under reposRoot and exits.
func runInitRepo(reposRoot, name string) {
	if !strings.HasSuffix(name, ".git") {
		name += ".git"
	}
	path := filepath.Join(reposRoot, name)

	if _, err := os.Stat(path); err == nil {
		log.Fatalf("repo already exists: %s", path)
	}

	cmd := exec.Command("git", "init", "--bare", path)
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	if err := cmd.Run(); err != nil {
		log.Fatalf("failed to create repo: %v", err)
	}
	fmt.Printf("Created bare repo at %s\n", path)
}

// runCreateUser adds a user to the flat-file auth store and exits.
func runCreateUser(userFile, username, password string) {
	if password == "" {
		log.Fatal("-password is required when using -create-user")
	}
	if err := auth.AddUser(userFile, username, password); err != nil {
		log.Fatalf("failed to add user: %v", err)
	}
	fmt.Printf("Added user %q to %s\n", username, userFile)
}