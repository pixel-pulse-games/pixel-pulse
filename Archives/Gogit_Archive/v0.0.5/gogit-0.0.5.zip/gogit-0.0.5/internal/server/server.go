// Package server contains the HTTP server for gogit.
//
// Milestone 2 added ref advertisement. Milestone 3 added clone/fetch.
// Milestone 4 added push. Milestone 5 adds multi-repo routing.
// Milestone 6 adds auth on push.
package server

import (
	"bytes"
	"compress/gzip"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strings"

	"gogit/internal/auth"
)

// Config holds the settings the server needs to start.
type Config struct {
	// Addr is the TCP address to listen on, e.g. ":8080".
	Addr string
	// ReposRoot is the directory holding all bare repos, one
	// subfolder per repo (e.g. reposRoot/myproject.git).
	ReposRoot string
	// UserFile is the flat-file user store path for push auth. A
	// missing file means no users are configured, which denies all
	// pushes (secure default) until at least one user is added.
	UserFile string
}

// server holds state that route handlers need access to.
type server struct {
	reposRoot string
	authStore *auth.Store
}

// New builds an *http.Server ready to run, wired up with our routes.
func New(cfg Config) *http.Server {
	store, err := auth.LoadStore(cfg.UserFile)
	if err != nil {
		log.Printf("warning: failed to load user store %q: %v (pushes will be denied)", cfg.UserFile, err)
		store = &auth.Store{}
	}
	if store.Empty() {
		log.Printf("no users configured in %q - all pushes will be denied until a user is added", cfg.UserFile)
	}

	s := &server{reposRoot: cfg.ReposRoot, authStore: store}

	mux := http.NewServeMux()
	mux.HandleFunc("/healthz", handleHealthz)
	// Go 1.22+ ServeMux wildcard routing: {repo} captures one path
	// segment (no slashes), read back via r.PathValue("repo"). This
	// replaces milestone 1-4's hardcoded /testrepo.git/... routes.
	mux.HandleFunc("GET /{repo}/info/refs", s.handleInfoRefs)
	mux.HandleFunc("POST /{repo}/git-upload-pack", s.handleUploadPack)
	mux.HandleFunc("POST /{repo}/git-receive-pack", s.handleReceivePack)

	return &http.Server{
		Addr:    cfg.Addr,
		Handler: logRequests(mux),
	}
}

// repoNamePattern is an allowlist for repo names taken from the URL:
// letters, digits, underscore, hyphen, ending in ".git". This is
// deliberately strict - a repo name is about to be joined onto a
// filesystem path, so anything not explicitly allowed is rejected
// rather than trying to blocklist dangerous characters.
var repoNamePattern = regexp.MustCompile(`^[A-Za-z0-9_-]+\.git$`)

// resolveRepoPath turns a URL path segment into a safe, validated
// path under reposRoot, or reports false if it isn't safe to use.
//
// Two independent checks, deliberately redundant with each other:
//  1. The name must match repoNamePattern - no "..", no slashes, no
//     surprises, full stop.
//  2. Even after that, we still verify the final resolved path is
//     actually inside reposRoot before using it. Belt and suspenders:
//     a bug in the regex shouldn't be the only thing standing between
//     a request and the filesystem outside the repos directory.
func (s *server) resolveRepoPath(repoName string) (string, bool) {
	if !repoNamePattern.MatchString(repoName) {
		return "", false
	}

	full := filepath.Join(s.reposRoot, repoName)

	absRoot, err := filepath.Abs(s.reposRoot)
	if err != nil {
		return "", false
	}
	absFull, err := filepath.Abs(full)
	if err != nil {
		return "", false
	}
	if absFull != absRoot && !strings.HasPrefix(absFull, absRoot+string(os.PathSeparator)) {
		return "", false
	}

	return full, true
}

// requirePushAuth checks HTTP Basic Auth credentials for push
// operations. Reads (clone/fetch) never call this - only the push
// paths (git-receive-pack and its ref advertisement) do, per the
// project plan: reads stay open, pushes require auth.
//
// Writes its own 401 response (with WWW-Authenticate, so a git client
// knows to prompt for credentials) and returns false if unauthorized.
func (s *server) requirePushAuth(w http.ResponseWriter, r *http.Request) bool {
	if s.authStore.Empty() {
		w.Header().Set("WWW-Authenticate", `Basic realm="gogit"`)
		http.Error(w, "push denied: no users configured on this server", http.StatusUnauthorized)
		return false
	}

	username, password, ok := r.BasicAuth()
	if !ok || !s.authStore.Verify(username, password) {
		w.Header().Set("WWW-Authenticate", `Basic realm="gogit"`)
		http.Error(w, "invalid credentials", http.StatusUnauthorized)
		return false
	}

	return true
}

// handleInfoRefs serves the ref advertisement a git client requests
// before it clones, fetches, or pushes:
// GET /{repo}/info/refs?service=git-upload-pack (clone/fetch)
// GET /{repo}/info/refs?service=git-receive-pack (push)
//
// Push's ref advertisement requires auth too - a client finds out
// it's unauthorized here, before it even tries to send data.
func (s *server) handleInfoRefs(w http.ResponseWriter, r *http.Request) {
	service := r.URL.Query().Get("service")

	var gitCmd string
	switch service {
	case "git-upload-pack":
		gitCmd = "upload-pack"
	case "git-receive-pack":
		gitCmd = "receive-pack"
		if !s.requirePushAuth(w, r) {
			return
		}
	default:
		http.Error(w, "unsupported service", http.StatusForbidden)
		return
	}

	repoPath, ok := s.resolveRepoPath(r.PathValue("repo"))
	if !ok {
		http.Error(w, "invalid repo name", http.StatusBadRequest)
		return
	}
	if _, err := os.Stat(repoPath); err != nil {
		http.Error(w, "repo not found", http.StatusNotFound)
		return
	}

	var out bytes.Buffer
	cmd := exec.Command("git", gitCmd, "--stateless-rpc", "--advertise-refs", repoPath)
	cmd.Stdout = &out
	cmd.Stderr = os.Stderr
	if err := cmd.Run(); err != nil {
		log.Printf("%s --advertise-refs failed: %v", gitCmd, err)
		http.Error(w, "internal error", http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", fmt.Sprintf("application/x-%s-advertisement", service))
	w.Header().Set("Cache-Control", "no-cache")
	w.WriteHeader(http.StatusOK)

	w.Write(pktLine(fmt.Sprintf("# service=%s\n", service)))
	w.Write(pktFlush())
	w.Write(out.Bytes())
}

// handleUploadPack serves the actual clone/fetch data transfer:
// POST /{repo}/git-upload-pack
//
// No auth required - reads stay open per the project plan.
func (s *server) handleUploadPack(w http.ResponseWriter, r *http.Request) {
	repoPath, ok := s.resolveRepoPath(r.PathValue("repo"))
	if !ok {
		http.Error(w, "invalid repo name", http.StatusBadRequest)
		return
	}
	if _, err := os.Stat(repoPath); err != nil {
		http.Error(w, "repo not found", http.StatusNotFound)
		return
	}

	var reqBody io.Reader = r.Body
	if r.Header.Get("Content-Encoding") == "gzip" {
		gz, err := gzip.NewReader(r.Body)
		if err != nil {
			http.Error(w, "malformed gzip body", http.StatusBadRequest)
			return
		}
		defer gz.Close()
		reqBody = gz
	}

	cmd := exec.Command("git", "upload-pack", "--stateless-rpc", repoPath)
	cmd.Stdin = reqBody
	cmd.Stderr = os.Stderr

	stdout, err := cmd.StdoutPipe()
	if err != nil {
		log.Printf("upload-pack stdout pipe: %v", err)
		http.Error(w, "internal error", http.StatusInternalServerError)
		return
	}

	if err := cmd.Start(); err != nil {
		log.Printf("upload-pack start: %v", err)
		http.Error(w, "internal error", http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/x-git-upload-pack-result")
	w.Header().Set("Cache-Control", "no-cache")
	w.WriteHeader(http.StatusOK)

	if _, err := io.Copy(w, stdout); err != nil {
		log.Printf("streaming upload-pack output: %v", err)
	}

	if err := cmd.Wait(); err != nil {
		log.Printf("upload-pack exited with error: %v", err)
	}
}

// handleReceivePack serves the actual push data transfer:
// POST /{repo}/git-receive-pack
//
// Requires auth - this is the one route so far that mutates a repo
// on disk, so it's the one gated behind requirePushAuth.
func (s *server) handleReceivePack(w http.ResponseWriter, r *http.Request) {
	if !s.requirePushAuth(w, r) {
		return
	}

	repoPath, ok := s.resolveRepoPath(r.PathValue("repo"))
	if !ok {
		http.Error(w, "invalid repo name", http.StatusBadRequest)
		return
	}
	if _, err := os.Stat(repoPath); err != nil {
		http.Error(w, "repo not found", http.StatusNotFound)
		return
	}

	var reqBody io.Reader = r.Body
	if r.Header.Get("Content-Encoding") == "gzip" {
		gz, err := gzip.NewReader(r.Body)
		if err != nil {
			http.Error(w, "malformed gzip body", http.StatusBadRequest)
			return
		}
		defer gz.Close()
		reqBody = gz
	}

	cmd := exec.Command("git", "receive-pack", "--stateless-rpc", repoPath)
	cmd.Stdin = reqBody
	cmd.Stderr = os.Stderr

	stdout, err := cmd.StdoutPipe()
	if err != nil {
		log.Printf("receive-pack stdout pipe: %v", err)
		http.Error(w, "internal error", http.StatusInternalServerError)
		return
	}

	if err := cmd.Start(); err != nil {
		log.Printf("receive-pack start: %v", err)
		http.Error(w, "internal error", http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/x-git-receive-pack-result")
	w.Header().Set("Cache-Control", "no-cache")
	w.WriteHeader(http.StatusOK)

	if _, err := io.Copy(w, stdout); err != nil {
		log.Printf("streaming receive-pack output: %v", err)
	}

	if err := cmd.Wait(); err != nil {
		log.Printf("receive-pack exited with error: %v", err)
	}
}

// pktLine encodes a single pkt-line: a 4-hex-digit length prefix
// (length includes the 4 prefix bytes themselves) followed by the
// data itself.
func pktLine(s string) []byte {
	length := len(s) + 4
	return []byte(fmt.Sprintf("%04x%s", length, s))
}

// pktFlush is the special zero-length pkt-line ("0000") that marks
// the end of a section.
func pktFlush() []byte {
	return []byte("0000")
}

// handleHealthz is a trivial endpoint so we can prove the server is
// alive with `curl` before any git-specific routes exist.
func handleHealthz(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "text/plain")
	w.WriteHeader(http.StatusOK)
	w.Write([]byte("ok\n"))
}

// logRequests is a small middleware that logs every incoming request.
func logRequests(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		log.Printf("%s %s", r.Method, r.URL.RequestURI())
		next.ServeHTTP(w, r)
	})
}