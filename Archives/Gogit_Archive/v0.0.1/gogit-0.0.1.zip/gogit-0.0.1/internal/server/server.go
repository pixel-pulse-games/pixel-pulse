// Package server contains the HTTP server for gogit.
//
// For now this just sets up routing and a health-check endpoint.
// Git protocol handlers (info/refs, upload-pack, receive-pack) get
// added in later milestones.
package server

import (
	"log"
	"net/http"
)

// Config holds the settings the server needs to start.
type Config struct {
	// Addr is the TCP address to listen on, e.g. ":8080".
	Addr string
	// ReposRoot is the directory that (eventually) holds all bare repos.
	ReposRoot string
}

// New builds an *http.Server ready to run, wired up with our routes.
func New(cfg Config) *http.Server {
	mux := http.NewServeMux()

	mux.HandleFunc("/healthz", handleHealthz)

	return &http.Server{
		Addr:    cfg.Addr,
		Handler: logRequests(mux),
	}
}

// handleHealthz is a trivial endpoint so we can prove the server is
// alive with `curl` before any git-specific routes exist.
func handleHealthz(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "text/plain")
	w.WriteHeader(http.StatusOK)
	w.Write([]byte("ok\n"))
}

// logRequests is a small middleware that logs every incoming request.
// Useful for seeing exactly what a real git client sends once we get
// to the protocol milestones.
func logRequests(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		log.Printf("%s %s", r.Method, r.URL.RequestURI())
		next.ServeHTTP(w, r)
	})
}
