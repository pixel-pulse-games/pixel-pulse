// Command gogit runs a minimal Git-over-HTTP server.
package main

import (
	"flag"
	"log"

	"gogit/internal/server"
)

func main() {
	addr := flag.String("addr", ":8080", "address to listen on, e.g. :8080")
	reposRoot := flag.String("repos", "./data", "directory containing bare repos")
	flag.Parse()

	cfg := server.Config{
		Addr:      *addr,
		ReposRoot: *reposRoot,
	}

	srv := server.New(cfg)

	log.Printf("gogit listening on %s (repos root: %s)", cfg.Addr, cfg.ReposRoot)
	if err := srv.ListenAndServe(); err != nil {
		log.Fatal(err)
	}
}
