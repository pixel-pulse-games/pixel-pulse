// Package server contains the HTTP server for gogit.
//
// Milestone 2 adds ref advertisement: GET .../info/refs?service=git-upload-pack.
// Clone/push (milestones 3-4) come next.
package server

import (
	"bytes"
	"fmt"
	"log"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
)

// Config holds the settings the server needs to start.
type Config struct {
	// Addr is the TCP address to listen on, e.g. ":8080".
	Addr string
	// ReposRoot is the directory that (eventually) holds all bare repos.
	ReposRoot string
}

// server holds state that route handlers need access to. Introduced
// in this milestone because handlers now need to know where repos
// live on disk, not just serve static responses.
type server struct {
	reposRoot string
}

// New builds an *http.Server ready to run, wired up with our routes.
func New(cfg Config) *http.Server {
	s := &server{reposRoot: cfg.ReposRoot}

	mux := http.NewServeMux()
	mux.HandleFunc("/healthz", handleHealthz)
	// Hardcoded to testrepo.git for now - multi-repo routing by URL
	// path is milestone 5.
	mux.HandleFunc("/testrepo.git/info/refs", s.handleInfoRefs)

	return &http.Server{
		Addr:    cfg.Addr,
		Handler: logRequests(mux),
	}
}

// handleInfoRefs serves the ref advertisement a git client requests
// before it clones or fetches: GET .../info/refs?service=git-upload-pack
//
// The response is: a pkt-line announcing the service, a flush-pkt,
// then git's own pkt-line-formatted list of refs, then another
// flush-pkt. We shell out to `git upload-pack --advertise-refs` to
// produce the ref list itself (correct pkt-line framing included) -
// our code only wraps it with the two framing lines git expects on
// top.
func (s *server) handleInfoRefs(w http.ResponseWriter, r *http.Request) {
	service := r.URL.Query().Get("service")
	if service != "git-upload-pack" {
		// Push (git-receive-pack) is milestone 4. Anything else we
		// don't understand yet.
		http.Error(w, "unsupported service", http.StatusForbidden)
		return
	}

	repoPath := filepath.Join(s.reposRoot, "testrepo.git")

	var out bytes.Buffer
	cmd := exec.Command("git", "upload-pack", "--stateless-rpc", "--advertise-refs", repoPath)
	cmd.Stdout = &out
	cmd.Stderr = os.Stderr
	if err := cmd.Run(); err != nil {
		log.Printf("upload-pack --advertise-refs failed: %v", err)
		http.Error(w, "internal error", http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/x-git-upload-pack-advertisement")
	w.Header().Set("Cache-Control", "no-cache")
	w.WriteHeader(http.StatusOK)

	w.Write(pktLine("# service=git-upload-pack\n"))
	w.Write(pktFlush())
	w.Write(out.Bytes())
}

// pktLine encodes a single pkt-line: a 4-hex-digit length prefix
// (length includes the 4 prefix bytes themselves) followed by the
// data itself.
func pktLine(s string) []byte {
	length := len(s) + 4
	return []byte(fmt.Sprintf("%04x%s", length, s))
}

// pktFlush is the special zero-length pkt-line ("0000") that marks
// the end of a section.
func pktFlush() []byte {
	return []byte("0000")
}

// handleHealthz is a trivial endpoint so we can prove the server is
// alive with `curl` before any git-specific routes exist.
func handleHealthz(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "text/plain")
	w.WriteHeader(http.StatusOK)
	w.Write([]byte("ok\n"))
}

// logRequests is a small middleware that logs every incoming request.
// Useful for seeing exactly what a real git client sends once we get
// to the protocol milestones.
func logRequests(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		log.Printf("%s %s", r.Method, r.URL.RequestURI())
		next.ServeHTTP(w, r)
	})
}