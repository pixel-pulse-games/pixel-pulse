package main

import (
	"html/template"
	"net/http"
	"os"
	"strings"
)

// Home / Repo List Handler
func handleHome(reposDir string) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/" {
			http.NotFound(w, r)
			return
		}

		username, authed := getAuthUser(r)

		// Scan repo folder
		var repos []RepoInfo
		entries, err := os.ReadDir(reposDir)
		if err == nil {
			for _, entry := range entries {
				if entry.IsDir() || strings.HasSuffix(entry.Name(), ".git") {
					name := strings.TrimSuffix(entry.Name(), ".git")

					// Basic private repo detection logic
					isPrivate := strings.Contains(name, "secret") || strings.HasPrefix(name, "private_")

					// If unauthenticated, hide private repos
					if isPrivate && !authed {
						continue
					}

					repos = append(repos, RepoInfo{
						Name:    name,
						Private: isPrivate,
					})
				}
			}
		}

		tmpl, err := template.ParseFiles("repo_list.html")
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}

		tmpl.Execute(w, PageData{
			Authed:   authed,
			Username: username,
			Repos:    repos,
		})
	}
}

// User Registration Handler
func handleRegister(w http.ResponseWriter, r *http.Request) {
	data := PageData{}

	if r.Method == http.MethodPost {
		username := strings.TrimSpace(r.FormValue("username"))
		password := strings.TrimSpace(r.FormValue("password"))

		if username == "" || password == "" {
			data.Error = "Username and password are required."
		} else {
			err := userStore.AddUser(username, password)
			if err != nil {
				data.Error = "Username is already taken."
			} else {
				// Automatically create session and log user in
				createSession(w, username)
				http.Redirect(w, r, "/", http.StatusSeeOther)
				return
			}
		}
	}

	tmpl, err := template.ParseFiles("register.html")
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	tmpl.Execute(w, data)
}

// Login Handler
func handleLogin(w http.ResponseWriter, r *http.Request) {
	data := PageData{}

	if r.Method == http.MethodPost {
		username := strings.TrimSpace(r.FormValue("username"))
		password := strings.TrimSpace(r.FormValue("password"))

		if userStore.Authenticate(username, password) {
			createSession(w, username)
			http.Redirect(w, r, "/", http.StatusSeeOther)
			return
		}
		data.Error = "Invalid username or password."
	}

	tmpl, err := template.ParseFiles("login.html")
	if err != nil {
		// Fallback simple inline template if standalone file doesn't exist yet
		tmpl = template.Must(template.New("login").Parse(`
			<!DOCTYPE html><html><head><title>Login</title><link rel="stylesheet" href="/static/style.css"></head>
			<body><div class="navbar"><a class="brand" href="/">gogit</a></div>
			<div class="container" style="max-width:400px; margin-top:2rem;">
			<h2>Sign In</h2>{{if .Error}}<p style="color:red">{{.Error}}</p>{{end}}
			<form method="POST"><p><label>Username<br><input type="text" name="username" required></label></p>
			<p><label>Password<br><input type="password" name="password" required></label></p>
			<p><button class="btn" type="submit">Sign In</button></p></form></div></body></html>`))
	}
	tmpl.Execute(w, data)
}

// Admin Add User Handler
func handleAdminNewUser(w http.ResponseWriter, r *http.Request) {
	username, authed := getAuthUser(r)
	if !authed {
		http.Redirect(w, r, "/login", http.StatusSeeOther)
		return
	}

	data := PageData{
		Authed:   true,
		Username: username,
	}

	if r.Method == http.MethodPost {
		newUser := strings.TrimSpace(r.FormValue("username"))
		newPass := strings.TrimSpace(r.FormValue("password"))

		if newUser == "" || newPass == "" {
			data.Error = "Username and password are required."
		} else {
			err := userStore.AddUser(newUser, newPass)
			if err != nil {
				data.Error = "User already exists."
			} else {
				data.Success = newUser
			}
		}
	}

	tmpl, err := template.ParseFiles("new_user.html")
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	tmpl.Execute(w, data)
}

// Logout Handler
func handleLogout(w http.ResponseWriter, r *http.Request) {
	cookie, err := r.Cookie("gogit_session")
	if err == nil {
		sessionStore.mu.Lock()
		delete(sessionStore.sessions, cookie.Value)
		sessionStore.mu.Unlock()
	}

	http.SetCookie(w, &http.Cookie{
		Name:   "gogit_session",
		Value:  "",
		Path:   "/",
		MaxAge: -1,
	})

	http.Redirect(w, r, "/", http.StatusSeeOther)
}