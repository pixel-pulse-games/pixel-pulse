package main

import (
	"crypto/rand"
	"encoding/hex"
	"flag"
	"fmt"
	"log"
	"net/http"
	"os"
	"sync"
)

// In-memory session store
type SessionStore struct {
	mu       sync.RWMutex
	sessions map[string]string // sessionID -> username
}

var sessionStore = &SessionStore{
	sessions: make(map[string]string),
}

// User credentials store
type UserStore struct {
	mu       sync.RWMutex
	filePath string
	users    map[string]string // username -> password
}

var userStore *UserStore

type PageData struct {
	Authed   bool
	Username string
	Error    string
	Success  string
	Repos    []RepoInfo
}

type RepoInfo struct {
	Name    string
	Private bool
}

func main() {
	addr := flag.String("addr", ":8080", "HTTP service address")
	reposDir := flag.String("repos", "./data", "Directory containing git repos")
	userFile := flag.String("userfile", "./users.txt", "Path to user authentication store")
	createUser := flag.String("create-user", "", "CLI helper to create an initial user")
	password := flag.String("password", "", "Password for CLI user creation")
	flag.Parse()

	// Initialize user store
	userStore = NewUserStore(*userFile)

	// CLI User Creation Handler
	if *createUser != "" {
		if *password == "" {
			log.Fatal("Password required when creating a user via CLI flag -password")
		}
		if err := userStore.AddUser(*createUser, *password); err != nil {
			log.Fatalf("Failed to create user: %v", err)
		}
		fmt.Printf("User '%s' created successfully.\n", *createUser)
		os.Exit(0)
	}

	// Static asset handler
	fs := http.FileServer(http.Dir("./static"))
	http.Handle("/static/", http.StripPrefix("/static/", fs))

	// Application routes
	http.HandleFunc("/", handleHome(*reposDir))
	http.HandleFunc("/login", handleLogin)
	http.HandleFunc("/register", handleRegister)
	http.HandleFunc("/logout", handleLogout)
	http.HandleFunc("/admin/users/new", handleAdminNewUser)

	fmt.Printf("gogit server starting at http://localhost%s\n", *addr)
	log.Fatal(http.ListenAndServe(*addr, nil))
}

// UserStore helper functions
func NewUserStore(path string) *UserStore {
	us := &UserStore{
		filePath: path,
		users:    make(map[string]string),
	}
	us.load()
	return us
}

func (us *UserStore) load() {
	us.mu.Lock()
	defer us.mu.Unlock()

	data, err := os.ReadFile(us.filePath)
	if err != nil {
		return
	}
	lines := splitLines(string(data))
	for _, line := range lines {
		if line == "" {
			continue
		}
		var u, p string
		fmt.Sscanf(line, "%s %s", &u, &p)
		if u != "" && p != "" {
			us.users[u] = p
		}
	}
}

func (us *UserStore) AddUser(username, password string) error {
	us.mu.Lock()
	defer us.mu.Unlock()

	if _, exists := us.users[username]; exists {
		return fmt.Errorf("user already exists")
	}

	us.users[username] = password
	f, err := os.OpenFile(us.filePath, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0600)
	if err != nil {
		return err
	}
	defer f.Close()

	_, err = f.WriteString(fmt.Sprintf("%s %s\n", username, password))
	return err
}

func (us *UserStore) Authenticate(username, password string) bool {
	us.mu.RLock()
	defer us.mu.RUnlock()
	storedPass, exists := us.users[username]
	return exists && storedPass == password
}

// Helper auth check
func getAuthUser(r *http.Request) (string, bool) {
	cookie, err := r.Cookie("gogit_session")
	if err != nil {
		return "", false
	}
	sessionStore.mu.RLock()
	defer sessionStore.mu.RUnlock()
	username, exists := sessionStore.sessions[cookie.Value]
	return username, exists
}

func createSession(w http.ResponseWriter, username string) {
	b := make([]byte, 16)
	rand.Read(b)
	sessionID := hex.EncodeToString(b)

	sessionStore.mu.Lock()
	sessionStore.sessions[sessionID] = username
	sessionStore.mu.Unlock()

	http.SetCookie(w, &http.Cookie{
		Name:     "gogit_session",
		Value:    sessionID,
		Path:     "/",
		HttpOnly: true,
		SameSite: http.SameSiteLaxMode,
	})
}

func splitLines(s string) []string {
	var lines []string
	var current string
	for _, r := range s {
		if r == '\n' || r == '\r' {
			if current != "" {
				lines = append(lines, current)
				current = ""
			}
		} else {
			current += string(r)
		}
	}
	if current != "" {
		lines = append(lines, current)
	}
	return lines
}