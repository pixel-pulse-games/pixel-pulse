#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "raylib.h"
#include "level_format.h"

#define MAX_LEVEL_LEN 500
#define CELL_SIZE 36
#define TIMELINE_TOP 90

static Color color_for_code(int code) {
    switch (code) {
        case LEVEL_SPIKE:      return (Color){220, 50, 50, 255};
        case LEVEL_BLOCK:      return (Color){70, 130, 255, 255};
        case LEVEL_WIN:        return (Color){60, 200, 90, 255};
        case LEVEL_SHIELD:     return (Color){80, 220, 255, 255};
        case LEVEL_SLOWMO:     return (Color){190, 120, 255, 255};
        case LEVEL_DOUBLEJUMP: return (Color){255, 170, 60, 255};
        default:               return (Color){55, 55, 55, 255};
    }
}

static const char *name_for_code(int code) {
    switch (code) {
        case LEVEL_SPIKE:      return "SPIKE";
        case LEVEL_BLOCK:      return "BLOCK";
        case LEVEL_WIN:        return "WIN";
        case LEVEL_SHIELD:     return "SHIELD";
        case LEVEL_SLOWMO:     return "SLOWMO";
        case LEVEL_DOUBLEJUMP: return "2X JUMP";
        default:               return "GAP";
    }
}

int main(int argc, char **argv) {
    const char *path = (argc > 1) ? argv[1] : "level.level";

    int data[MAX_LEVEL_LEN];
    int len = 0;

    int *loaded = NULL;
    int loaded_len = 0;
    if (level_load(path, &loaded, &loaded_len)) {
        len = (loaded_len > MAX_LEVEL_LEN) ? MAX_LEVEL_LEN : loaded_len;
        memcpy(data, loaded, sizeof(int) * len);
        free(loaded);
        printf("Loaded %d steps from %s\n", len, path);
    } else {
        len = 40;
        for (int i = 0; i < len; i++) {
            data[i] = LEVEL_GAP;
        }
        printf("Starting a new level (will save to %s)\n", path);
    }

    int screen_w = 1400;
    int screen_h = 320;
    InitWindow(screen_w, screen_h, "Cube Dash - Level Builder");
    SetTargetFPS(60);

    int scroll = 0;            // index of the leftmost visible cell
    int brush = LEVEL_SPIKE;   // obstacle currently painted by left-click
    float save_flash = 0.0f;   // seconds left to show the "Saved!" message

    while (!WindowShouldClose()) {

        // --- Brush selection ---
        if (IsKeyPressed(KEY_ONE))   brush = LEVEL_GAP;
        if (IsKeyPressed(KEY_TWO))   brush = LEVEL_SPIKE;
        if (IsKeyPressed(KEY_THREE)) brush = LEVEL_BLOCK;
        if (IsKeyPressed(KEY_FOUR))  brush = LEVEL_WIN;
        if (IsKeyPressed(KEY_FIVE))  brush = LEVEL_SHIELD;
        if (IsKeyPressed(KEY_SIX))   brush = LEVEL_SLOWMO;
        if (IsKeyPressed(KEY_SEVEN)) brush = LEVEL_DOUBLEJUMP;

        // --- Scrolling ---
        if (IsKeyDown(KEY_RIGHT)) scroll += 1;
        if (IsKeyDown(KEY_LEFT))  scroll -= 1;
        float wheel = GetMouseWheelMove();
        if (wheel != 0) scroll -= (int)(wheel * 3);
        if (scroll < 0) scroll = 0;
        if (scroll > len - 1 && len > 0) scroll = len - 1;
        if (len == 0) scroll = 0;

        // --- Grow / shrink the level ---
        if (IsKeyPressed(KEY_EQUAL) || IsKeyPressed(KEY_KP_ADD)) {
            for (int i = 0; i < 10 && len < MAX_LEVEL_LEN; i++) {
                data[len++] = LEVEL_GAP;
            }
        }
        if (IsKeyPressed(KEY_MINUS) || IsKeyPressed(KEY_KP_SUBTRACT)) {
            for (int i = 0; i < 10 && len > 10; i++) {
                len--;
            }
        }

        // --- Clear ---
        if (IsKeyPressed(KEY_C)) {
            for (int i = 0; i < len; i++) {
                data[i] = LEVEL_GAP;
            }
        }

        // --- Paint (left click = brush, right click = erase to gap) ---
        if (IsMouseButtonDown(MOUSE_LEFT_BUTTON) || IsMouseButtonDown(MOUSE_RIGHT_BUTTON)) {
            int mx = GetMouseX();
            int my = GetMouseY();
            if (my >= TIMELINE_TOP && my < TIMELINE_TOP + CELL_SIZE) {
                int col = mx / CELL_SIZE;
                int idx = scroll + col;
                if (idx >= 0 && idx < len) {
                    data[idx] = IsMouseButtonDown(MOUSE_RIGHT_BUTTON) ? LEVEL_GAP : brush;
                }
            }
        }

        // --- Save ---
        if (IsKeyPressed(KEY_S)) {
            if (level_save(path, data, len)) {
                save_flash = 2.0f;
                printf("Saved %d steps to %s\n", len, path);
            } else {
                fprintf(stderr, "Failed to save to %s\n", path);
            }
        }
        if (save_flash > 0) {
            save_flash -= GetFrameTime();
        }

        // --- Draw ---
        BeginDrawing();
        ClearBackground((Color){18, 18, 18, 255});

        DrawText("Level Builder", 20, 15, 28, WHITE);
        DrawText(TextFormat("File: %s   Length: %d steps", path, len), 20, 50, 18, LIGHTGRAY);
        DrawText(TextFormat("Brush: %s", name_for_code(brush)), screen_w - 220, 15, 22, color_for_code(brush));

        DrawText(
            "1 gap 2 spike 3 block 4 win 5 shield 6 slowmo 7 2xjump | click: paint  right-click: erase | scroll: wheel/arrows | +/-: grow/shrink | C: clear | S: save",
            20, screen_h - 26, 15, GRAY
        );

        int visible_cols = screen_w / CELL_SIZE;
        for (int col = 0; col < visible_cols; col++) {
            int idx = scroll + col;
            int x = col * CELL_SIZE;
            if (idx < len) {
                DrawRectangle(x, TIMELINE_TOP, CELL_SIZE - 2, CELL_SIZE, color_for_code(data[idx]));
                if (idx % 10 == 0) {
                    DrawText(TextFormat("%d", idx), x, TIMELINE_TOP - 20, 14, GRAY);
                }
            } else {
                DrawRectangleLines(x, TIMELINE_TOP, CELL_SIZE - 2, CELL_SIZE, (Color){45, 45, 45, 255});
            }
        }
        DrawRectangleLines(0, TIMELINE_TOP, screen_w, CELL_SIZE, (Color){90, 90, 90, 255});

        if (save_flash > 0) {
            DrawText("Saved!", screen_w / 2 - 40, TIMELINE_TOP + CELL_SIZE + 20, 24, GREEN);
        }

        EndDrawing();
    }

    CloseWindow();
    return 0;
}
