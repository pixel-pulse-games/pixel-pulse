#include "obstacles.h"
#include "level.h"

void update_spikes(GameState *gs, float bs) {
    float speed = gs->base_scroll_speed * gs->speed_multiplier;

    for (int i = 0; i < MAX_OBSTACLES; i++) {
        if (gs->spikes[i].active) {
            gs->spikes[i].position.x -= speed;

            float sw = bs * gs->spikes[i].texture.width / gs->spikes[i].texture.height;
            float hw = sw * 0.6f;
            gs->spikes[i].hitbox = (Rectangle){
                gs->spikes[i].position.x + (sw - hw) / 2,
                gs->spikes[i].position.y - bs,
                hw,
                bs
            };

            if (gs->spikes[i].position.x < -200) {
                gs->spikes[i].active = 0;
            }
        }
    }
}

void update_blocks(GameState *gs) {
    float speed = gs->base_scroll_speed * gs->speed_multiplier;

    for (int i = 0; i < MAX_OBSTACLES; i++) {
        if (gs->blocks[i].active) {
            gs->blocks[i].position.x -= speed;
            if (gs->blocks[i].position.x < -200) {
                gs->blocks[i].active = 0;
            }
        }
    }
}

void update_win_trigger(GameState *gs) {
    float speed = gs->base_scroll_speed * gs->speed_multiplier;

    if (gs->win_trigger.active) {
        gs->win_trigger.position.x -= speed;
        gs->win_trigger.hitbox = (Rectangle){
            gs->win_trigger.position.x,
            gs->win_trigger.position.y - gs->player.size,
            gs->player.size * 0.5f,
            gs->player.size
        };
    }
}

void update_pickups(GameState *gs, float bs) {
    float speed = gs->base_scroll_speed * gs->speed_multiplier;

    for (int i = 0; i < MAX_PICKUPS; i++) {
        if (gs->pickups[i].active) {
            gs->pickups[i].position.x -= speed;
            gs->pickups[i].hitbox = (Rectangle){
                gs->pickups[i].position.x - bs * 0.3f,
                gs->pickups[i].position.y - bs * 0.3f,
                bs * 0.6f,
                bs * 0.6f
            };
            if (gs->pickups[i].position.x < -200) {
                gs->pickups[i].active = 0;
            }
        }
    }
}

void check_collisions(GameState *gs) {
    for (int i = 0; i < MAX_OBSTACLES; i++) {
        if (gs->spikes[i].active && CheckCollisionRecs(gs->player.hitbox, gs->spikes[i].hitbox)) {
            if (gs->has_shield) {
                // Shield absorbs the hit: destroy the spike, no game over.
                gs->has_shield = 0;
                gs->spikes[i].active = 0;
                gs->shake_timer = 10;
                gs->shake_magnitude = 6.0f;
            } else {
                gs->game_over = 1;
                gs->app_state = APP_GAME_OVER;
                gs->shake_timer = 20;
                gs->shake_magnitude = 14.0f;
            }
        }
    }

    if (gs->win_trigger.active && CheckCollisionRecs(gs->player.hitbox, gs->win_trigger.hitbox)) {
        gs->you_win = 1;
        gs->app_state = APP_WIN;
        gs->percent = 100;
    }
}

void check_pickup_collisions(GameState *gs) {
    for (int i = 0; i < MAX_PICKUPS; i++) {
        if (gs->pickups[i].active && CheckCollisionRecs(gs->player.hitbox, gs->pickups[i].hitbox)) {
            switch (gs->pickups[i].type) {
                case LEVEL_SHIELD:
                    gs->has_shield = 1;
                    break;
                case LEVEL_SLOWMO:
                    gs->slowmo_timer = 360; // ~3 seconds at 120 FPS
                    break;
                case LEVEL_DOUBLEJUMP:
                    gs->has_double_jump = 1;
                    break;
                default:
                    break;
            }
            gs->pickups[i].active = 0;
        }
    }
}

static int spawn_pickup(GameState *gs, int type) {
    for (int i = 0; i < MAX_PICKUPS; i++) {
        if (!gs->pickups[i].active) {
            gs->pickups[i].type = type;
            gs->pickups[i].position.x = gs->screen_width;
            gs->pickups[i].position.y = gs->ground.position.y - gs->player.size * 1.1f;
            gs->pickups[i].active = 1;
            return 1;
        }
    }
    return 0;
}

void spawn_next_obstacle(GameState *gs) {
    int kind = level_data[gs->level_data_indexer];

    if (kind == LEVEL_SPIKE) {
        for (int i = 0; i < MAX_OBSTACLES; i++) {
            if (!gs->spikes[i].active) {
                gs->spikes[i].texture = gs->spike_tex;
                gs->spikes[i].rect = (Rectangle){0, 0, gs->spike_tex.width, gs->spike_tex.height};
                gs->spikes[i].position.x = gs->screen_width;
                gs->spikes[i].position.y = gs->ground.position.y;
                gs->spikes[i].active = 1;
                break;
            }
        }
        gs->obstacle_timer = (int)((float)gs->player.size * 0.9f * gs->spike_tex.width / gs->spike_tex.height / gs->base_scroll_speed + 0.5f);

    } else if (kind == LEVEL_BLOCK) {
        for (int i = 0; i < MAX_OBSTACLES; i++) {
            if (!gs->blocks[i].active) {
                gs->blocks[i].texture = gs->block_tex;
                gs->blocks[i].rect = (Rectangle){0, 0, gs->block_tex.width, gs->block_tex.height};
                gs->blocks[i].position.x = gs->screen_width;
                gs->blocks[i].position.y = gs->ground.position.y;
                gs->blocks[i].active = 1;
                break;
            }
        }
        gs->obstacle_timer = (int)((float)gs->player.size * 0.9f / gs->base_scroll_speed + 0.5f);

    } else if (kind == LEVEL_WIN) {
        gs->win_trigger.position.x = gs->screen_width;
        gs->win_trigger.position.y = gs->ground.position.y;
        gs->win_trigger.active = 1;
        gs->obstacle_timer = 120;

    } else if (kind == LEVEL_SHIELD || kind == LEVEL_SLOWMO || kind == LEVEL_DOUBLEJUMP) {
        spawn_pickup(gs, kind);
        gs->obstacle_timer = 90;

    } else {
        gs->obstacle_timer = 120;
    }

    gs->level_data_indexer = (gs->level_data_indexer + 1) % level_data_len;
}
