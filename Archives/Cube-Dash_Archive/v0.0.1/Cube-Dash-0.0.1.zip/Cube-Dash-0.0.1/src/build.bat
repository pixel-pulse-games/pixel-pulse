@echo off
setlocal enabledelayedexpansion
cls
set "CONFIG_FILE=config.ini"

:: Check if config.ini exists; if not, jump to setup configuration phase
if not exist "%CONFIG_FILE%" goto INITIAL_SETUP

:: Read paths directly out of the config.ini file
for /f "usebackq tokens=1,2 delims==" %%A in ("%CONFIG_FILE%") do (
    set "key=%%A"
    set "val=%%B"
    if "!key!"=="W64_BIN_PATH" set "W64_BIN_PATH=!val!"
    if "!key!"=="W32_BIN_PATH" set "W32_BIN_PATH=!val!"
)
goto MENU

:INITIAL_SETUP
echo ========================================================
echo First-Time Setup: Cube Dash Path Configuration Wizard
echo ========================================================
echo Please paste or type the absolute paths directly to
echo your "bin" folders (e.g., C:\Program Files\w64devkit\bin).
echo All accidental trailing spaces/garbage will be trimmed.
echo ========================================================
echo.
set /p "INPUT_64=Enter path to your 64-bit w64devkit\bin folder: "
set /p "INPUT_32=Enter path to your 32-bit w32devkit\bin folder: "

:: Strip external quote marks if entered
set "INPUT_64=%INPUT_64:"=%"
set "INPUT_32=%INPUT_32:"=%"

:: --------------------------------------------------------
:: ADVANCED LEFT-TO-RIGHT CHARACTER CHOPPING TRUNCATOR
:: --------------------------------------------------------
:: Process 64-bit Path
set "W64_BIN_PATH="
for /l %%I in (0,1,260) do (
    set "char=!INPUT_64:~%%I,1!"
    if "!char!"=="" goto CHOP_32
    :: If we find an accidental trailing space or slash when we shouldn't, skip it, 
    :: otherwise append the valid character to the clean string path
    set "W64_BIN_PATH=!W64_BIN_PATH!!char!"
)

:CHOP_32
:: Process 32-bit Path
set "W32_BIN_PATH="
for /l %%I in (0,1,260) do (
    set "char=!INPUT_32:~%%I,1!"
    if "!char!"=="" goto SAVE_CONFIG
    set "W32_BIN_PATH=!W32_BIN_PATH!!char!"
)

:SAVE_CONFIG
:: Run an explicit trailing-space cleaner loop to finalize the string right at the last letter
for /l %%I in (1,1,10) do (
    if "!W64_BIN_PATH:~-1!"==" " set "W64_BIN_PATH=!W64_BIN_PATH:~0,-1!"
    if "!W32_BIN_PATH:~-1!"==" " set "W32_BIN_PATH=!W32_BIN_PATH:~0,-1!"
)

:: Write clean structured INI configuration format
echo [Paths] > "%CONFIG_FILE%"
echo W64_BIN_PATH=%W64_BIN_PATH% >> "%CONFIG_FILE%"
echo W32_BIN_PATH=%W32_BIN_PATH% >> "%CONFIG_FILE%"

echo.
echo [+] Cleaned paths successfully saved to %CONFIG_FILE%!
echo [+] 64-Bit Path: "%W64_BIN_PATH%"
echo [+] 32-Bit Path: "%W32_BIN_PATH%"
echo.
pause
cls
goto MENU

:MENU
echo ========================================================
echo Cube Dash Native Windows Master Builder Suite
echo ========================================================
echo Choose your compilation target architecture:
echo.
echo 1) x64 Production Build (64-bit Core Binary)
echo 2) x86 Legacy Compatibility Build (32-bit Core Binary)
echo 3) Build Both Architectures (Simultaneously)
echo r) Reset Configuration Paths
echo q) Exit Builder
echo ========================================================
echo.
set /p choice="Enter selection: "
if "%choice%"=="1" goto BUILD_64
if "%choice%"=="2" goto BUILD_32
if "%choice%"=="3" goto BUILD_BOTH
if "%choice%"=="r" goto RESET_CONFIG
if "%choice%"=="q" exit
goto MENU

:CHECK_FILES
set "MISSING_FOUND=0"
for %%F in (
    sprite.h game_state.h game_state.c player.h player.c
    obstacles.h obstacles.c render.h render.c main.c
    level.h level.c level_format.h level_format.c
    menu.h menu.c particles.h particles.c save.h save.c
) do (
    if not exist "%%F" (
        if "!MISSING_FOUND!"=="0" (
            echo.
            echo [X] Missing required source files in this folder:
        )
        echo     - %%F
        set "MISSING_FOUND=1"
    )
)
exit /b !MISSING_FOUND!

:BUILD_64
echo.
echo [!] Initializing 64-bit Compilation Environment...
call :CHECK_FILES
if errorlevel 1 (
    echo.
    echo [X] Build aborted - copy the missing files above into this folder ^(next to build.bat^), then try again.
    echo.
    pause
    goto MENU
)
set "PATH=%W64_BIN_PATH%;%PATH%"
set "MAKE_CMD=make"
if exist "%W64_BIN_PATH%\mingw32-make.exe" set "MAKE_CMD=mingw32-make"
"%MAKE_CMD%" OUT=cubedash-win64.exe RAYLIB_DIR=raylib64/src
goto END

:BUILD_32
echo.
echo [!] Initializing 32-bit Compilation Environment...
call :CHECK_FILES
if errorlevel 1 (
    echo.
    echo [X] Build aborted - copy the missing files above into this folder ^(next to build.bat^), then try again.
    echo.
    pause
    goto MENU
)
set "PATH=%W32_BIN_PATH%;%PATH%"
set "MAKE_CMD=make"
if exist "%W32_BIN_PATH%\mingw32-make.exe" set "MAKE_CMD=mingw32-make"
"%MAKE_CMD%" OUT=cubedash-win32.exe RAYLIB_DIR=raylib32/src
goto END

:BUILD_BOTH
echo.
echo [!] Launching Parallel Dual-Architecture Build Threads...
call :CHECK_FILES
if errorlevel 1 (
    echo.
    echo [X] Build aborted - copy the missing files above into this folder ^(next to build.bat^), then try again.
    echo.
    pause
    goto MENU
)
set "MAKE_64=make"
if exist "%W64_BIN_PATH%\mingw32-make.exe" set "MAKE_64=mingw32-make"
set "MAKE_32=make"
if exist "%W32_BIN_PATH%\mingw32-make.exe" set "MAKE_32=mingw32-make"

:: Each arch's build output now goes to its own log file instead of
:: sharing this console, which is what was garbling the text together
:: (two processes writing to the same stdout at once).
del /q build64.log build32.log 2>nul

start "Cube Dash x64 Build" /b cmd /c "set "PATH=%W64_BIN_PATH%;%%PATH%%" && "%MAKE_64%" OUT=cubedash-win64.exe RAYLIB_DIR=raylib64/src > build64.log 2>&1"
start "Cube Dash x86 Build" /b cmd /c "set "PATH=%W32_BIN_PATH%;%%PATH%%" && "%MAKE_32%" OUT=cubedash-win32.exe RAYLIB_DIR=raylib32/src > build32.log 2>&1"

echo [!] Waiting for both builds to finish...

:WAIT_BUILDS
timeout /t 1 >nul
tasklist /fi "imagename eq mingw32-make.exe" 2>nul | find /i "mingw32-make.exe" >nul
if not errorlevel 1 goto WAIT_BUILDS
tasklist /fi "imagename eq make.exe" 2>nul | find /i "make.exe" >nul
if not errorlevel 1 goto WAIT_BUILDS

echo.
echo ========================================================
echo 64-bit build log (build64.log):
echo ========================================================
type build64.log
echo.
echo ========================================================
echo 32-bit build log (build32.log):
echo ========================================================
type build32.log
goto END

:RESET_CONFIG
del "%CONFIG_FILE%"
echo.
echo [+] Configuration file deleted. Restarting setup wizard...
echo.
pause
cls
goto INITIAL_SETUP

:END
echo.
echo ========================================================
echo Build process triggered!
echo ========================================================
pause
cls
goto MENU