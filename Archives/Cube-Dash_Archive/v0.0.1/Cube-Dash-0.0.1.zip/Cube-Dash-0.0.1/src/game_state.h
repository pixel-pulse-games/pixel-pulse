#ifndef GAME_STATE_H
#define GAME_STATE_H

#include "raylib.h"
#include "sprite.h"

#define MAX_OBSTACLES 20
#define MAX_PICKUPS   20

typedef enum {
    APP_MENU,
    APP_PLAYING,
    APP_GAME_OVER,
    APP_WIN
} AppState;

typedef enum {
    DIFF_EASY,
    DIFF_NORMAL,
    DIFF_HARD,
    DIFF_COUNT
} Difficulty;

// A collectible power-up on the timeline (shield / slow-mo / double jump).
typedef struct {
    Vector2 position;
    Rectangle hitbox;
    int type;   // LEVEL_SHIELD / LEVEL_SLOWMO / LEVEL_DOUBLEJUMP
    int active;
} Pickup;

typedef struct {
    int screen_width;
    int screen_height;
    float floor_y;
    int ground_texture_offset;
    int jump_height;
    float player_rotation_rate;
    float y_speed;
    float y_velocity;

    // Difficulty / speed
    Difficulty difficulty;
    float base_scroll_speed;  // pixels/frame for obstacles at 1x speed
    float speed_multiplier;   // temporary slow-mo multiplier (1.0 = normal)

    int level_data_indexer;
    int obstacle_timer;

    AppState app_state;
    int game_over;
    int you_win;
    int game_started;
    int result_saved;         // guards the one-time best-score save + burst

    // Meta-progression
    int attempts;
    int percent;              // 0-100 progress through the current level
    int best_percent;         // best recorded for the current level

    // Power-ups
    int has_shield;
    int slowmo_timer;         // frames of slow-mo remaining
    int has_double_jump;

    // Feedback
    int shake_timer;          // frames of screen shake remaining
    float shake_magnitude;
    float shake_offset_x;
    float shake_offset_y;

    struct Sprite player;
    struct Sprite background;
    struct Sprite ground;
    struct Sprite vignette;
    struct Sprite win_trigger;
    struct Sprite blocks[MAX_OBSTACLES];
    struct Sprite spikes[MAX_OBSTACLES];
    Pickup pickups[MAX_PICKUPS];

    Texture2D spike_tex;
    Texture2D block_tex;
} GameState;

// Loads textures, opens the window, and sets starting values.
void game_init(GameState *gs);

// Resets state for a new run of the current level.
void game_reset(GameState *gs);

// Applies speed/gravity/jump tuning for a difficulty level.
void game_set_difficulty(GameState *gs, Difficulty d);

#endif
