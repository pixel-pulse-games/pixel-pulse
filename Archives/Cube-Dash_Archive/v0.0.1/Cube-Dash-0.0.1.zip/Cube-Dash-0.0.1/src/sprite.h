#ifndef SPRITE_H
#define SPRITE_H

#include "raylib.h"

struct Sprite {
    Texture2D texture;
    Vector2 position;
    Rectangle rect;
    Rectangle hitbox;
    float rotation;
    float size;
    int active;
};

#endif
