#ifndef LEVEL_H
#define LEVEL_H

#include "level_format.h"

// The currently active level's obstacle sequence and its length.
// obstacles.c reads these the same way it used to read the old
// hardcoded level_data[] array.
extern const int *level_data;
extern int level_data_len;

// Loads level_data/level_data_len from a .level file at `path`.
// If path is NULL, or the file can't be loaded, falls back to the
// original built-in level so the game always has something to run.
void level_use(const char *path);

#endif
