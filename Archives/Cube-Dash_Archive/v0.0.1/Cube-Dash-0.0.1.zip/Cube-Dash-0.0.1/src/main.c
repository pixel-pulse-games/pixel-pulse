#include <stddef.h>
#include "raylib.h"
#include "game_state.h"
#include "player.h"
#include "obstacles.h"
#include "render.h"
#include "level.h"
#include "menu.h"
#include "particles.h"
#include "save.h"

int main(void) {
    GameState gs = {0};
    game_init(&gs);

    MenuState menu;
    menu_init(&menu);

    ParticleSystem particles;
    particles_init(&particles);

    const char *current_level_path = menu_levels[0].path;

    while (!WindowShouldClose()) {

        if (gs.app_state == APP_MENU) {
            if (menu_update_and_draw(&menu, &gs)) {
                current_level_path = menu_levels[menu.selected_level].path;
                level_use(current_level_path);
                game_set_difficulty(&gs, (Difficulty)menu.selected_difficulty);
                gs.best_percent = save_get_best_percent(current_level_path);
                game_reset(&gs);
            }
            continue;
        }

        // --- Slow-mo timer ---
        if (gs.slowmo_timer > 0) {
            gs.slowmo_timer--;
            gs.speed_multiplier = 0.5f;
        } else {
            gs.speed_multiplier = 1.0f;
        }

        // --- Screen shake ---
        if (gs.shake_timer > 0) {
            gs.shake_timer--;
            gs.shake_offset_x = (float)GetRandomValue(-(int)gs.shake_magnitude, (int)gs.shake_magnitude);
            gs.shake_offset_y = (float)GetRandomValue(-(int)gs.shake_magnitude, (int)gs.shake_magnitude);
        } else {
            gs.shake_offset_x = 0;
            gs.shake_offset_y = 0;
        }

        particles_update(&particles, GetFrameTime());

        if (!gs.game_started && IsKeyPressed(KEY_SPACE)) {
            gs.game_started = 1;
        }

        if (gs.app_state == APP_PLAYING) {
            scroll_world(&gs);

            float bs = gs.player.size * 0.9f;
            float current_floor_y = compute_landing_floor(&gs, bs);

            update_player_physics(&gs, current_floor_y);

            if (gs.game_started) {
                gs.obstacle_timer -= 1;

                update_spikes(&gs, bs);
                update_blocks(&gs);
                update_win_trigger(&gs);
                update_pickups(&gs, bs);
                check_pickup_collisions(&gs);
                check_collisions(&gs);

                if (gs.obstacle_timer <= 0) {
                    spawn_next_obstacle(&gs);
                }

                handle_jump_input(&gs, current_floor_y);

                if (level_data_len > 0) {
                    gs.percent = (int)(100.0f * gs.level_data_indexer / level_data_len);
                }
            }
        }

        // One-shot handling the moment a run ends: save best score + fire particles.
        if ((gs.app_state == APP_GAME_OVER || gs.app_state == APP_WIN) && !gs.result_saved) {
            if (gs.percent > gs.best_percent) {
                gs.best_percent = gs.percent;
            }
            save_set_best_percent(current_level_path, gs.percent);

            if (gs.app_state == APP_WIN) {
                particles_burst(&particles, gs.player.position, 60, GREEN);
            } else {
                particles_burst(&particles, gs.player.position, 50, RED);
            }
            gs.result_saved = 1;
        }

        if ((gs.app_state == APP_GAME_OVER || gs.app_state == APP_WIN)) {
            if (IsKeyPressed(KEY_R)) {
                game_reset(&gs);
            }
            if (IsKeyPressed(KEY_M)) {
                gs.app_state = APP_MENU;
            }
        }

        render_game(&gs, &particles);
    }

    CloseWindow();
    return 0;
}
