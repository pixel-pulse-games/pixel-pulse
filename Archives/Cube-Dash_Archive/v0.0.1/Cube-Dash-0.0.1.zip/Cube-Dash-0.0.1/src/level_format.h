#ifndef LEVEL_FORMAT_H
#define LEVEL_FORMAT_H

// Obstacle codes shared between the game and the level builder.
// These match the meaning of the original level_data values.
#define LEVEL_GAP        0
#define LEVEL_SPIKE      1
#define LEVEL_BLOCK      2
#define LEVEL_WIN        3
#define LEVEL_SHIELD     4   // absorbs one hit
#define LEVEL_SLOWMO     5   // temporarily slows the level down
#define LEVEL_DOUBLEJUMP 6   // grants one extra mid-air jump

// .level file format:
//   - Lines starting with '#' are comments and ignored.
//   - All whitespace (spaces, tabs, newlines) is ignored.
//   - Every other character must be one of: . S B W H M J
//       .  = gap (nothing spawns)
//       S  = spike
//       B  = block
//       W  = win trigger (finish line)
//       H  = shield pickup   (absorbs one hit)
//       M  = slow-mo pickup  (temporarily slows the level)
//       J  = double-jump pickup (one extra mid-air jump)
//
// Example:
//   # My first level
//   ....S..SS...SSS....SSSS..BB..B.B..BBB..SS..BBBB.....W

// Loads a .level file into a heap-allocated array of obstacle codes.
// On success, *out_data is malloc'd (caller must free it) and *out_len is
// set to the number of steps read. Returns 1 on success, 0 on failure
// (missing file, invalid character, out of memory).
int level_load(const char *path, int **out_data, int *out_len);

// Writes an array of obstacle codes out as a .level file.
// Returns 1 on success, 0 on failure (e.g. couldn't open the file).
int level_save(const char *path, const int *data, int len);

// Converts a single obstacle code to its file character.
char level_code_to_char(int code);

// Converts a file character back to an obstacle code, or -1 if invalid.
int level_char_to_code(char c);

#endif
