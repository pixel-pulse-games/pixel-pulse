#include "menu.h"
#include "raylib.h"

const LevelEntry menu_levels[MENU_LEVEL_COUNT] = {
    {"Level 1 - Warm Up",   "levels/level1.level"},
    {"Level 2 - Rhythm",    "levels/level2.level"},
    {"Level 3 - Overdrive", "levels/level3.level"},
};

static const char *difficulty_name(int d) {
    switch (d) {
        case 0:  return "EASY";
        case 2:  return "HARD";
        default: return "NORMAL";
    }
}

void menu_init(MenuState *ms) {
    ms->selected_level = 0;
    ms->selected_difficulty = 1; // normal
}

int menu_update_and_draw(MenuState *ms, GameState *gs) {
    if (IsKeyPressed(KEY_DOWN)) {
        ms->selected_level = (ms->selected_level + 1) % MENU_LEVEL_COUNT;
    }
    if (IsKeyPressed(KEY_UP)) {
        ms->selected_level = (ms->selected_level - 1 + MENU_LEVEL_COUNT) % MENU_LEVEL_COUNT;
    }
    if (IsKeyPressed(KEY_RIGHT)) {
        ms->selected_difficulty = (ms->selected_difficulty + 1) % 3;
    }
    if (IsKeyPressed(KEY_LEFT)) {
        ms->selected_difficulty = (ms->selected_difficulty - 1 + 3) % 3;
    }

    int start = IsKeyPressed(KEY_SPACE) || IsKeyPressed(KEY_ENTER);

    BeginDrawing();
    ClearBackground((Color){15, 15, 20, 255});

    DrawText("CUBE DASH", gs->screen_width / 2 - 220, 100, 80, WHITE);
    DrawText("Select a level", gs->screen_width / 2 - 140, 220, 32, LIGHTGRAY);

    for (int i = 0; i < MENU_LEVEL_COUNT; i++) {
        Color c = (i == ms->selected_level) ? YELLOW : GRAY;
        int y = 300 + i * 60;
        if (i == ms->selected_level) {
            DrawText(">", gs->screen_width / 2 - 240, y, 34, YELLOW);
        }
        DrawText(menu_levels[i].display_name, gs->screen_width / 2 - 200, y, 34, c);
    }

    DrawText(
        TextFormat("Difficulty:   <  %s  >", difficulty_name(ms->selected_difficulty)),
        gs->screen_width / 2 - 180, 300 + MENU_LEVEL_COUNT * 60 + 40, 30, SKYBLUE
    );

    DrawText(
        "UP/DOWN: choose level    LEFT/RIGHT: difficulty    SPACE/ENTER: start",
        gs->screen_width / 2 - 340, gs->screen_height - 60, 20, GRAY
    );

    EndDrawing();

    return start;
}
