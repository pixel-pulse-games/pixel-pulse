#include "particles.h"
#include <math.h>

void particles_init(ParticleSystem *ps) {
    for (int i = 0; i < MAX_PARTICLES; i++) {
        ps->particles[i].active = 0;
    }
}

void particles_burst(ParticleSystem *ps, Vector2 origin, int count, Color color) {
    int spawned = 0;

    for (int i = 0; i < MAX_PARTICLES && spawned < count; i++) {
        if (!ps->particles[i].active) {
            float angle = (float)GetRandomValue(0, 359) * 3.14159265f / 180.0f;
            float speed = (float)GetRandomValue(80, 260);

            ps->particles[i].position = origin;
            ps->particles[i].velocity = (Vector2){cosf(angle) * speed, sinf(angle) * speed};
            ps->particles[i].max_life = 0.5f + (float)GetRandomValue(0, 50) / 100.0f;
            ps->particles[i].life = ps->particles[i].max_life;
            ps->particles[i].color = color;
            ps->particles[i].active = 1;
            spawned++;
        }
    }
}

void particles_update(ParticleSystem *ps, float dt) {
    for (int i = 0; i < MAX_PARTICLES; i++) {
        if (ps->particles[i].active) {
            ps->particles[i].position.x += ps->particles[i].velocity.x * dt;
            ps->particles[i].position.y += ps->particles[i].velocity.y * dt;
            ps->particles[i].velocity.y += 400.0f * dt; // light gravity on debris
            ps->particles[i].life -= dt;
            if (ps->particles[i].life <= 0) {
                ps->particles[i].active = 0;
            }
        }
    }
}

void particles_draw(ParticleSystem *ps, float offset_x, float offset_y) {
    for (int i = 0; i < MAX_PARTICLES; i++) {
        if (ps->particles[i].active) {
            float t = ps->particles[i].life / ps->particles[i].max_life;
            Color c = ps->particles[i].color;
            c.a = (unsigned char)(255 * t);
            DrawCircle(
                (int)(ps->particles[i].position.x + offset_x),
                (int)(ps->particles[i].position.y + offset_y),
                4.0f * t + 1.0f,
                c
            );
        }
    }
}
