#include "render.h"
#include "level_format.h"

static Color pickup_color(int type) {
    switch (type) {
        case LEVEL_SHIELD:     return (Color){80, 220, 255, 255};
        case LEVEL_SLOWMO:     return (Color){190, 120, 255, 255};
        case LEVEL_DOUBLEJUMP: return (Color){255, 170, 60, 255};
        default:               return WHITE;
    }
}

static const char *pickup_label(int type) {
    switch (type) {
        case LEVEL_SHIELD:     return "H";
        case LEVEL_SLOWMO:     return "M";
        case LEVEL_DOUBLEJUMP: return "J";
        default:               return "?";
    }
}

static void draw_hud(GameState *gs) {
    // Progress bar across the top.
    int bar_x = 40, bar_y = 30, bar_w = gs->screen_width - 80, bar_h = 18;
    DrawRectangle(bar_x, bar_y, bar_w, bar_h, (Color){40, 40, 40, 200});
    DrawRectangle(bar_x, bar_y, (int)(bar_w * (gs->percent / 100.0f)), bar_h, (Color){80, 220, 120, 255});
    DrawRectangleLines(bar_x, bar_y, bar_w, bar_h, WHITE);
    DrawText(TextFormat("%d%%", gs->percent), bar_x + bar_w / 2 - 20, bar_y + bar_h + 4, 24, WHITE);

    DrawText(TextFormat("Best: %d%%", gs->best_percent), bar_x, bar_y + bar_h + 34, 20, LIGHTGRAY);
    DrawText(TextFormat("Attempt %d", gs->attempts), gs->screen_width - 220, bar_y + bar_h + 34, 20, LIGHTGRAY);

    // Active power-up indicators, top-right.
    int icon_x = gs->screen_width - 60;
    int icon_y = 90;
    if (gs->has_shield) {
        DrawCircle(icon_x, icon_y, 20, pickup_color(LEVEL_SHIELD));
        DrawText("SHIELD", icon_x - 70, icon_y + 24, 16, pickup_color(LEVEL_SHIELD));
        icon_y += 70;
    }
    if (gs->has_double_jump) {
        DrawCircle(icon_x, icon_y, 20, pickup_color(LEVEL_DOUBLEJUMP));
        DrawText("2X JUMP", icon_x - 76, icon_y + 24, 16, pickup_color(LEVEL_DOUBLEJUMP));
        icon_y += 70;
    }
    if (gs->slowmo_timer > 0) {
        DrawCircle(icon_x, icon_y, 20, pickup_color(LEVEL_SLOWMO));
        DrawText("SLOW-MO", icon_x - 78, icon_y + 24, 16, pickup_color(LEVEL_SLOWMO));
    }
}

void render_game(GameState *gs, ParticleSystem *ps) {
    float ox = gs->shake_offset_x;
    float oy = gs->shake_offset_y;

    BeginDrawing();
    ClearBackground(WHITE);

    DrawTexture(gs->background.texture, gs->background.position.x + ox, oy, WHITE);
    if (gs->background.position.x < 0) {
        DrawTexture(gs->background.texture, gs->background.position.x + gs->screen_width + ox, oy, WHITE);
    }

    if (gs->ground.position.x < -gs->screen_width) {
        gs->ground.position.x = 0;
    }
    if (gs->ground.position.x < 0) {
        DrawTexture(gs->ground.texture, gs->ground.position.x + gs->screen_width + ox, gs->ground.position.y + oy, WHITE);
    }
    DrawTexture(gs->ground.texture, gs->ground.position.x + ox, gs->ground.position.y + oy, WHITE);

    for (int i = 0; i < MAX_OBSTACLES; i++) {
        if (gs->blocks[i].active) {
            DrawTexturePro(
                gs->blocks[i].texture,
                gs->blocks[i].rect,
                (Rectangle){
                    gs->blocks[i].position.x + ox,
                    gs->blocks[i].position.y - gs->player.size * 0.9f + oy,
                    gs->player.size * 0.9f,
                    gs->player.size * 0.9f
                },
                (Vector2){0, 0}, 0, WHITE
            );
        }
    }

    for (int i = 0; i < MAX_OBSTACLES; i++) {
        if (gs->spikes[i].active) {
            DrawTexturePro(
                gs->spikes[i].texture,
                gs->spikes[i].rect,
                (Rectangle){
                    gs->spikes[i].position.x + ox,
                    gs->spikes[i].position.y - gs->player.size * 0.9f + oy,
                    gs->player.size * 0.9f * gs->spikes[i].texture.width / gs->spikes[i].texture.height,
                    gs->player.size * 0.9f
                },
                (Vector2){0, 0}, 0, WHITE
            );
        }
    }

    for (int i = 0; i < MAX_PICKUPS; i++) {
        if (gs->pickups[i].active) {
            float px = gs->pickups[i].position.x + ox;
            float py = gs->pickups[i].position.y + oy;
            float r = gs->player.size * 0.3f;
            DrawCircle((int)px, (int)py, r, pickup_color(gs->pickups[i].type));
            DrawText(pickup_label(gs->pickups[i].type), (int)(px - 6), (int)(py - 12), 24, (Color){20, 20, 20, 255});
        }
    }

    DrawTexturePro(
        gs->player.texture,
        gs->player.rect,
        (Rectangle){gs->player.position.x + ox, gs->player.position.y + oy, gs->player.size, gs->player.size},
        (Vector2){gs->player.size / 2, gs->player.size / 2},
        gs->player.rotation, WHITE
    );
    if (gs->has_shield) {
        DrawCircleLines((int)(gs->player.position.x + ox), (int)(gs->player.position.y + oy), gs->player.size * 0.7f, pickup_color(LEVEL_SHIELD));
    }

    DrawTexture(gs->vignette.texture, 0, 0, WHITE);

    particles_draw(ps, ox, oy);

    draw_hud(gs);

    if (!gs->game_started) {
        DrawText("Press Space to Start", gs->screen_width / 2 - 200, gs->screen_height / 2 - 30, 60, WHITE);
    }
    if (gs->game_over) {
        DrawText("GAME OVER", gs->screen_width / 2 - 220, gs->screen_height / 2 - 80, 120, RED);
        DrawText(TextFormat("Reached %d%%   (Best: %d%%)", gs->percent, gs->best_percent),
                  gs->screen_width / 2 - 220, gs->screen_height / 2 + 40, 34, WHITE);
        DrawText("R: retry        M: menu", gs->screen_width / 2 - 180, gs->screen_height / 2 + 90, 30, LIGHTGRAY);
    }
    if (gs->you_win) {
        DrawText("YOU WIN!", gs->screen_width / 2 - 180, gs->screen_height / 2 - 80, 120, GREEN);
        DrawText(TextFormat("100%%   (Best: %d%%)", gs->best_percent),
                  gs->screen_width / 2 - 150, gs->screen_height / 2 + 40, 34, WHITE);
        DrawText("R: play again        M: menu", gs->screen_width / 2 - 220, gs->screen_height / 2 + 90, 30, LIGHTGRAY);
    }

    EndDrawing();
}
