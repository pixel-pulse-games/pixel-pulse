#ifndef RENDER_H
#define RENDER_H

#include "game_state.h"
#include "particles.h"

// Draws the whole frame: background, ground, obstacles, pickups, player,
// HUD, screen shake, particles, and game-over/win overlays.
void render_game(GameState *gs, ParticleSystem *ps);

#endif
