#include "player.h"

void scroll_world(GameState *gs) {
    float speed = gs->base_scroll_speed * gs->speed_multiplier;

    // 0.486 preserves the original 7:14.4 background-to-ground parallax ratio.
    gs->background.position.x -= speed * 0.486f;
    gs->ground.position.x -= speed;
    gs->ground.position.y = gs->floor_y + gs->ground_texture_offset;

    if (gs->background.position.x < -gs->screen_width) {
        gs->background.position.x = 0;
    }
}

float compute_landing_floor(GameState *gs, float bs) {
    float current_floor_y = gs->floor_y;

    for (int i = 0; i < MAX_OBSTACLES; i++) {
        if (gs->blocks[i].active) {
            float block_land_y = gs->blocks[i].position.y - bs - gs->player.size / 2;
            if (gs->player.position.x + gs->player.size / 2 > gs->blocks[i].position.x &&
                gs->player.position.x - gs->player.size / 2 < gs->blocks[i].position.x + bs &&
                gs->player.position.y <= gs->blocks[i].position.y) {
                if (block_land_y < current_floor_y) {
                    current_floor_y = block_land_y;
                }
            }
        }
    }

    return current_floor_y;
}

void update_player_physics(GameState *gs, float current_floor_y) {
    if (gs->player.position.y <= current_floor_y) {
        gs->y_speed += gs->y_velocity;
        gs->player.position.y += gs->y_speed;
        gs->player.rotation += gs->player_rotation_rate;
    } else {
        gs->player.rotation = (int)(gs->player.rotation / 90) * 90;
    }

    gs->player.hitbox = (Rectangle){
        gs->player.position.x - gs->player.size / 2,
        gs->player.position.y - gs->player.size / 2,
        gs->player.size,
        gs->player.size
    };
}

void handle_jump_input(GameState *gs, float current_floor_y) {
    int grounded = gs->player.position.y > current_floor_y;

    if (IsKeyDown(KEY_SPACE) && grounded) {
        gs->player.position.y -= 1;
        gs->y_speed = -gs->jump_height;
        gs->player.position.y += gs->y_speed;
    } else if (IsKeyPressed(KEY_SPACE) && !grounded && gs->has_double_jump) {
        // Consumes the charge: one extra jump per pickup.
        gs->y_speed = -gs->jump_height * 0.85f;
        gs->has_double_jump = 0;
    }
}
