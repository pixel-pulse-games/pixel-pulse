#include "level_format.h"
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

char level_code_to_char(int code) {
    switch (code) {
        case LEVEL_GAP:        return '.';
        case LEVEL_SPIKE:      return 'S';
        case LEVEL_BLOCK:      return 'B';
        case LEVEL_WIN:        return 'W';
        case LEVEL_SHIELD:     return 'H';
        case LEVEL_SLOWMO:     return 'M';
        case LEVEL_DOUBLEJUMP: return 'J';
        default:               return '?';
    }
}

int level_char_to_code(char c) {
    switch (c) {
        case '.': return LEVEL_GAP;
        case 'S': return LEVEL_SPIKE;
        case 'B': return LEVEL_BLOCK;
        case 'W': return LEVEL_WIN;
        case 'H': return LEVEL_SHIELD;
        case 'M': return LEVEL_SLOWMO;
        case 'J': return LEVEL_DOUBLEJUMP;
        default:  return -1;
    }
}

int level_load(const char *path, int **out_data, int *out_len) {
    FILE *f = fopen(path, "r");
    if (!f) {
        return 0;
    }

    int capacity = 256;
    int len = 0;
    int *data = malloc(sizeof(int) * capacity);
    if (!data) {
        fclose(f);
        return 0;
    }

    int c;
    while ((c = fgetc(f)) != EOF) {
        if (c == '#') {
            // Skip the rest of the comment line.
            while ((c = fgetc(f)) != EOF && c != '\n') { }
            continue;
        }
        if (isspace(c)) {
            continue;
        }

        int code = level_char_to_code((char)c);
        if (code < 0) {
            fprintf(stderr, "level_load: invalid character '%c' in %s\n", c, path);
            free(data);
            fclose(f);
            return 0;
        }

        if (len >= capacity) {
            capacity *= 2;
            int *bigger = realloc(data, sizeof(int) * capacity);
            if (!bigger) {
                free(data);
                fclose(f);
                return 0;
            }
            data = bigger;
        }
        data[len++] = code;
    }

    fclose(f);

    *out_data = data;
    *out_len = len;
    return 1;
}

int level_save(const char *path, const int *data, int len) {
    FILE *f = fopen(path, "w");
    if (!f) {
        return 0;
    }

    fprintf(f, "# Level file\n");
    fprintf(f, "# . = gap   S = spike   B = block   W = win\n");

    for (int i = 0; i < len; i++) {
        fputc(level_code_to_char(data[i]), f);
    }
    fputc('\n', f);

    fclose(f);
    return 1;
}
