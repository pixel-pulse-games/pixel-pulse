#ifndef PARTICLES_H
#define PARTICLES_H

#include "raylib.h"

#define MAX_PARTICLES 128

typedef struct {
    Vector2 position;
    Vector2 velocity;
    float life;      // seconds remaining
    float max_life;
    Color color;
    int active;
} Particle;

typedef struct {
    Particle particles[MAX_PARTICLES];
} ParticleSystem;

void particles_init(ParticleSystem *ps);

// Spawns up to `count` particles at `origin` in a random burst pattern.
void particles_burst(ParticleSystem *ps, Vector2 origin, int count, Color color);

void particles_update(ParticleSystem *ps, float dt);
void particles_draw(ParticleSystem *ps, float offset_x, float offset_y);

#endif
