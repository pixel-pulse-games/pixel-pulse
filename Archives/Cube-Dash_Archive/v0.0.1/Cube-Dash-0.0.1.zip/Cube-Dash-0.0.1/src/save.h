#ifndef SAVE_H
#define SAVE_H

// Returns the best completion percent (0-100) previously recorded for a
// level file, or 0 if none is on record yet.
int save_get_best_percent(const char *level_path);

// Records a new best percent for a level file if it beats the existing
// record. Writes to disk immediately.
void save_set_best_percent(const char *level_path, int percent);

#endif
