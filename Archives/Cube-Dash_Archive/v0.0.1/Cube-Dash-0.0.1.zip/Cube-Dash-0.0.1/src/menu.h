#ifndef MENU_H
#define MENU_H

#include "game_state.h"

typedef struct {
    const char *display_name;
    const char *path;
} LevelEntry;

// The shipped levels. Add more entries here (and matching .level files
// under levels/) if you want more options in the menu.
#define MENU_LEVEL_COUNT 3
extern const LevelEntry menu_levels[MENU_LEVEL_COUNT];

typedef struct {
    int selected_level;
    int selected_difficulty; // 0 = easy, 1 = normal, 2 = hard
} MenuState;

void menu_init(MenuState *ms);

// Handles input and draws the menu screen (its own BeginDrawing/EndDrawing).
// Returns 1 the frame the player chooses to start a level.
int menu_update_and_draw(MenuState *ms, GameState *gs);

#endif
