#include "level.h"
#include <stdio.h>
#include <stdlib.h>

// The original built-in level, kept as a safe fallback.
static const int default_level[] = {
    0, 0, 0, 0, 1, 0, 0, 1, 1, 0,
    0, 1, 1, 1, 0, 0, 1, 1, 1, 1,
    0, 0, 2, 2, 0, 0, 2, 0, 2, 0,
    0, 2, 2, 2, 1, 1, 0, 0, 2, 2,
    2, 2, 1, 1, 1, 1, 1, 0, 3
};
static const int default_level_len = sizeof(default_level) / sizeof(default_level[0]);

static int *loaded_data = NULL; // heap buffer from the last successful file load, if any

const int *level_data = NULL;
int level_data_len = 0;

void level_use(const char *path) {
    if (loaded_data) {
        free(loaded_data);
        loaded_data = NULL;
    }

    if (path != NULL) {
        int *data;
        int len;
        if (level_load(path, &data, &len) && len > 0) {
            loaded_data = data;
            level_data = data;
            level_data_len = len;
            printf("Loaded level '%s' (%d steps)\n", path, len);
            return;
        }
        fprintf(stderr, "Could not load level '%s' — using the built-in level instead.\n", path);
    }

    level_data = default_level;
    level_data_len = default_level_len;
}
