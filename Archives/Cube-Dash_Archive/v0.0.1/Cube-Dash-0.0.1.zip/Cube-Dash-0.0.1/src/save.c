#include "save.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define SAVE_FILE "savedata.txt"
#define MAX_ENTRIES 64
#define MAX_PATH_LEN 256

typedef struct {
    char path[MAX_PATH_LEN];
    int percent;
} SaveEntry;

static int load_entries(SaveEntry *entries) {
    FILE *f = fopen(SAVE_FILE, "r");
    if (!f) {
        return 0;
    }

    int count = 0;
    char line[MAX_PATH_LEN + 16];

    while (count < MAX_ENTRIES && fgets(line, sizeof(line), f)) {
        char *eq = strchr(line, '=');
        if (!eq) {
            continue;
        }
        *eq = '\0';

        strncpy(entries[count].path, line, MAX_PATH_LEN - 1);
        entries[count].path[MAX_PATH_LEN - 1] = '\0';
        entries[count].percent = atoi(eq + 1);
        count++;
    }

    fclose(f);
    return count;
}

static void write_entries(SaveEntry *entries, int count) {
    FILE *f = fopen(SAVE_FILE, "w");
    if (!f) {
        return;
    }
    for (int i = 0; i < count; i++) {
        fprintf(f, "%s=%d\n", entries[i].path, entries[i].percent);
    }
    fclose(f);
}

int save_get_best_percent(const char *level_path) {
    SaveEntry entries[MAX_ENTRIES];
    int count = load_entries(entries);

    for (int i = 0; i < count; i++) {
        if (strcmp(entries[i].path, level_path) == 0) {
            return entries[i].percent;
        }
    }
    return 0;
}

void save_set_best_percent(const char *level_path, int percent) {
    SaveEntry entries[MAX_ENTRIES];
    int count = load_entries(entries);

    for (int i = 0; i < count; i++) {
        if (strcmp(entries[i].path, level_path) == 0) {
            if (percent > entries[i].percent) {
                entries[i].percent = percent;
                write_entries(entries, count);
            }
            return;
        }
    }

    if (count < MAX_ENTRIES) {
        strncpy(entries[count].path, level_path, MAX_PATH_LEN - 1);
        entries[count].path[MAX_PATH_LEN - 1] = '\0';
        entries[count].percent = percent;
        count++;
        write_entries(entries, count);
    }
}
