#ifndef OBSTACLES_H
#define OBSTACLES_H

#include "game_state.h"

void update_spikes(GameState *gs, float bs);
void update_blocks(GameState *gs);
void update_win_trigger(GameState *gs);
void update_pickups(GameState *gs, float bs);

// Sets game_over / you_win if the player hits a spike / reaches the win trigger.
// A held shield absorbs one spike hit instead of ending the run.
void check_collisions(GameState *gs);

// Applies shield/slow-mo/double-jump when the player touches a pickup.
void check_pickup_collisions(GameState *gs);

// Reads the next entry in level_data and spawns the matching obstacle/pickup.
void spawn_next_obstacle(GameState *gs);

#endif
