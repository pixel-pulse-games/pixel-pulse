#include "game_state.h"

void game_set_difficulty(GameState *gs, Difficulty d) {
    gs->difficulty = d;
    switch (d) {
        case DIFF_EASY:
            gs->base_scroll_speed = 11.0f;
            gs->y_velocity = 0.4f;
            gs->jump_height = 17;
            break;
        case DIFF_HARD:
            gs->base_scroll_speed = 18.0f;
            gs->y_velocity = 0.6f;
            gs->jump_height = 15;
            break;
        case DIFF_NORMAL:
        default:
            gs->base_scroll_speed = 14.4f;
            gs->y_velocity = 0.5f;
            gs->jump_height = 16;
            break;
    }
}

void game_init(GameState *gs) {
    gs->screen_width = 1920;
    gs->screen_height = 1080;
    gs->floor_y = gs->screen_height * 0.60f;
    gs->ground_texture_offset = 80;
    gs->player_rotation_rate = 3.0f;
    gs->y_speed = 1;

    gs->speed_multiplier = 1.0f;
    game_set_difficulty(gs, DIFF_NORMAL);

    gs->level_data_indexer = 0;
    gs->obstacle_timer = 120;

    gs->app_state = APP_MENU;
    gs->game_over = 0;
    gs->you_win = 0;
    gs->game_started = 0;
    gs->result_saved = 0;

    gs->attempts = 0;
    gs->percent = 0;
    gs->best_percent = 0;

    gs->has_shield = 0;
    gs->slowmo_timer = 0;
    gs->has_double_jump = 0;

    gs->shake_timer = 0;
    gs->shake_magnitude = 0;
    gs->shake_offset_x = 0;
    gs->shake_offset_y = 0;

    for (int i = 0; i < MAX_OBSTACLES; i++) {
        gs->blocks[i] = (struct Sprite){0};
        gs->spikes[i] = (struct Sprite){0};
    }
    for (int i = 0; i < MAX_PICKUPS; i++) {
        gs->pickups[i] = (Pickup){0};
    }

    InitWindow(gs->screen_width, gs->screen_height, "Cube Dash");

    gs->player.texture = LoadTexture("assets/sprites/player.png");
    gs->player.position = (Vector2){gs->screen_width / 5, 10};
    gs->player.rect = (Rectangle){0, 0, gs->player.texture.width, gs->player.texture.height};
    gs->player.rotation = 225.0f;
    gs->player.size = gs->screen_height / 7;

    gs->background.texture = LoadTexture("assets/sprites/background.png");
    gs->background.position = (Vector2){0, 0};

    gs->ground.texture = LoadTexture("assets/sprites/ground.png");
    gs->ground.position = (Vector2){0, gs->floor_y + gs->ground_texture_offset};

    gs->vignette.texture = LoadTexture("assets/sprites/vignette_texture.png");
    gs->vignette.position = (Vector2){0, 0};

    gs->spike_tex = LoadTexture("assets/sprites/spike.png");
    gs->block_tex = LoadTexture("assets/sprites/block.png");

    gs->win_trigger.active = 0;

    SetTargetFPS(120);
}

void game_reset(GameState *gs) {
    gs->game_over = 0;
    gs->you_win = 0;
    gs->game_started = 0;
    gs->app_state = APP_PLAYING;
    gs->result_saved = 0;

    gs->attempts += 1;
    gs->percent = 0;

    gs->has_shield = 0;
    gs->slowmo_timer = 0;
    gs->has_double_jump = 0;
    gs->speed_multiplier = 1.0f;
    gs->shake_timer = 0;
    gs->shake_offset_x = 0;
    gs->shake_offset_y = 0;

    gs->player.position = (Vector2){gs->screen_width / 5, 10};
    gs->player.rotation = 225.0f;
    gs->y_speed = 1;
    gs->level_data_indexer = 0;
    gs->obstacle_timer = 120;
    gs->background.position.x = 0;
    gs->ground.position.x = 0;
    gs->win_trigger.active = 0;

    for (int i = 0; i < MAX_OBSTACLES; i++) {
        gs->spikes[i].active = 0;
        gs->blocks[i].active = 0;
    }
    for (int i = 0; i < MAX_PICKUPS; i++) {
        gs->pickups[i].active = 0;
    }
}
