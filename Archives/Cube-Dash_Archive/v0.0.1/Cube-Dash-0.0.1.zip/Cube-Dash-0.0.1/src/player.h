#ifndef PLAYER_H
#define PLAYER_H

#include "game_state.h"

// Scrolls the background/ground for one frame.
void scroll_world(GameState *gs);

// Checks whether any active block is under the player and returns the
// effective floor height (either the ground or the top of a block).
float compute_landing_floor(GameState *gs, float bs);

// Applies gravity/falling or snaps rotation when grounded, updates hitbox.
void update_player_physics(GameState *gs, float current_floor_y);

// Reads jump input and applies the jump impulse.
void handle_jump_input(GameState *gs, float current_floor_y);

#endif
