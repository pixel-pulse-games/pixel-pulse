---
layout: default
title: Cube Dash
---

# CUBE DASH

***

> [!WARNING]
> **SYSTEM ALERT:** Still very early alpha — expect bugs and missing features.

**Cube Dash** is an intense, ultra-responsive rhythm platformer heavily inspired by *Geometry Dash*. Players control a high-velocity cube that must jump, slide, and navigate through a hazardous grid of spikes and blocks synced to the underlying engine metrics. Built completely from scratch in native C, the game cuts out all engine bloat to deliver frame-perfect physics and microsecond-level input precision.

[Downloads](Download.md)

***

### 🎮 Gameplay & Engine Features

* **Fun Mechanics:** Classic fast-paced arcade platforming featuring automated forward velocity, frame-perfect jump scaling, and rigid collision matrices.
* **Hardware-Accelerated Resizing:** Full native support for stretching and resizing the window using letterboxed 16:9 virtual render textures to eliminate sprite distortion.
* **Modular Engine Systems:** Clean separation of concerns with a codebase cleanly split into independent source files (`player.c`, `obstacles.c`, `particles.c`, `render.c`).
* **Independent Physics Ticker:** Jump forces and gravity loops calculated completely independent of monitor refresh rates to ensure a fair challenge on any display.

***

### 🛠️ Compiling and Running the Source

To compile the entire file array and boot up the game window locally inside **w64devkit**, execute your automated workspace compilation script:

```bash
./build.bat
```

***

### 📜 Source Licensing
All logic modules and layout parameters engineered under this project stream are protected under the **PolyForm Noncommercial License 1.0.0**. Educational forks, private tinkering, and code audits are fully permitted. Commercial exploitation or monetization of this engine is strictly prohibited.