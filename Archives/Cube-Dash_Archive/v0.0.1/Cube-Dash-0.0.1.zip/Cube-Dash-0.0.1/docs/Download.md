---
layout: default
title: Download Cube Dash Alpha
---

[Home](index.md)

# CUBE DASH DOWNLOADS
### Active Project Binary Streams & Release Manifests

***

> [!WARNING]
> **DEVELOPMENT ALERT:** Still very early alpha — expect bugs, unexpected crashes, and missing game states. 

All compiled binary builds distributed below are completely self-contained, portable, and require zero installation software packages. Simply extract the archive and run the executable profile.

***

### 🚀 Latest Stable Stream Builds

#### 📥 [Download Windows 64-bit Binary (.zip)](https://github.com/Cube-Dash/Cube-Dash.github.io/releases/latest/download/cubedashwin64.zip){: .btn .btn-purple }
* **Version:** `v0.0.1-alpha`
* **Architecture:** `x86_64-w64-mingw32` (Native Windows 64-bit Execution)
* **Build Engine:** Compiled via `w64devkit` x64 toolchain.

#### 📥 [Download Windows 32-bit Binary (.zip)](https://github.com/Cube-Dash/Cube-Dash.github.io/releases/latest/download/cubedashwin32.zip){: .btn }
* **Version:** `v0.0.1-alpha`
* **Architecture:** `i686-w64-mingw32` (Legacy Windows 32-bit Execution)
* **Build Engine:** Backwards-compatible build for older x86 systems.

***

### 📋 Compiled System Changelog

#### Core Upgrades in `v0.0.3-alpha`:
* **Aspect-Locked Window Resizing:** Integrated hardware-accelerated letterboxing routines to allow infinite manual window stretching without scaling distortion.
* **Architecture Architecture Segmentation:** Successfully migrated single-file dependencies into isolated tracking layers (`player.c`, `obstacles.c`, `particles.c`, `render.c`).
* **Physics Ticker Hardening:** Grounded jumping velocities and gravity multipliers against variable monitor refresh delays.

***

### ⚙️ System Requirements & Build Verification

* **OS Infrastructure:** Windows 7 / 8 / 10 / 11 (32-bit or 64-bit systems architecture).
* **Graphics Layer:** Hardware supporting OpenGL 3.3 or higher.
* **Local Compilation Alternative:** If you prefer compiling the engine manually rather than grabbing the pre-built `.zip` binary above, clone the repository matrix and execute the core automated build script locally inside your command toolchain:

```bash
./build.bat
```

***
`[STATION STORAGE]: BINARY SOURCE POINTING TO RELEASES BACKEND MATRIX`
